﻿namespace ApartYönetimSistemi
{


    partial class ApartYonetimSistemiDataSet
    {
    }
}
