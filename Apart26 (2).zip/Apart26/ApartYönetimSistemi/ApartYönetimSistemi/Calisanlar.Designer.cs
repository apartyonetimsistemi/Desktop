﻿namespace ApartYönetimSistemi
{
    partial class Calisanlar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Calisanlar));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.yazOkuluKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çalışanKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.panel21 = new System.Windows.Forms.Panel();
            this.calisAra = new System.Windows.Forms.PictureBox();
            this.ara = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.apartYonetimSistemiDataSet = new ApartYönetimSistemi.ApartYonetimSistemiDataSet();
            this.apartYonetimSistemiDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.apartYonetimSistemiDataSet2 = new ApartYönetimSistemi.ApartYonetimSistemiDataSet2();
            this.calisanlarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.calisanlarTableAdapter = new ApartYönetimSistemi.ApartYonetimSistemiDataSet2TableAdapters.CalisanlarTableAdapter();
            this.apartYonetimSistemiDataSet3 = new ApartYönetimSistemi.ApartYonetimSistemiDataSet3();
            this.calisanbilgileriBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.calisanbilgileriTableAdapter = new ApartYönetimSistemi.ApartYonetimSistemiDataSet3TableAdapters.calisanbilgileriTableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ıDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BaslangicSaati = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BitisSaati = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SaatlikUcret = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IzinGunleri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soyadiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adresDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefon2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dogumYeriDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dogumTarihiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tCNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goreviDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.baslangicTarihiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.calismaIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.calisanbilgileriBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.apartYonetimSistemiDataSet6 = new ApartYönetimSistemi.ApartYonetimSistemiDataSet6();
            this.apartYonetimSistemiDataSet4 = new ApartYönetimSistemi.ApartYonetimSistemiDataSet4();
            this.calisanbilgileriBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.calisanbilgileriTableAdapter1 = new ApartYönetimSistemi.ApartYonetimSistemiDataSet4TableAdapters.calisanbilgileriTableAdapter();
            this.apartYonetimSistemiDataSet5 = new ApartYönetimSistemi.ApartYonetimSistemiDataSet5();
            this.calisanbilgileriBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.calisanbilgileriTableAdapter2 = new ApartYönetimSistemi.ApartYonetimSistemiDataSet5TableAdapters.calisanbilgileriTableAdapter();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.calisanbilgileriTableAdapter3 = new ApartYönetimSistemi.ApartYonetimSistemiDataSet6TableAdapters.calisanbilgileriTableAdapter();
            this.apartAdi = new System.Windows.Forms.Label();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1.SuspendLayout();
            this.panel21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.calisAra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.calisanlarBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.calisanbilgileriBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.calisanbilgileriBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.calisanbilgileriBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.calisanbilgileriBindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.BlueViolet;
            this.toolStrip1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton5,
            this.toolStripSplitButton1,
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton6,
            this.toolStripButton7});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1331, 47);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.ForeColor = System.Drawing.Color.White;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(123, 44);
            this.toolStripButton5.Text = "Ana Sayfa";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yazOkuluKaydıToolStripMenuItem,
            this.normalKayıtToolStripMenuItem,
            this.çalışanKaydıToolStripMenuItem});
            this.toolStripSplitButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(133, 44);
            this.toolStripSplitButton1.Text = "Yeni Kayıt";
            // 
            // yazOkuluKaydıToolStripMenuItem
            // 
            this.yazOkuluKaydıToolStripMenuItem.Name = "yazOkuluKaydıToolStripMenuItem";
            this.yazOkuluKaydıToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.yazOkuluKaydıToolStripMenuItem.Text = "Yaz Okulu Kaydı";
            this.yazOkuluKaydıToolStripMenuItem.Click += new System.EventHandler(this.yazOkuluKaydıToolStripMenuItem_Click);
            // 
            // normalKayıtToolStripMenuItem
            // 
            this.normalKayıtToolStripMenuItem.Name = "normalKayıtToolStripMenuItem";
            this.normalKayıtToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.normalKayıtToolStripMenuItem.Text = "Normal Kayıt";
            // 
            // çalışanKaydıToolStripMenuItem
            // 
            this.çalışanKaydıToolStripMenuItem.Name = "çalışanKaydıToolStripMenuItem";
            this.çalışanKaydıToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.çalışanKaydıToolStripMenuItem.Text = "Çalışan Kaydı";
            this.çalışanKaydıToolStripMenuItem.Click += new System.EventHandler(this.çalışanKaydıToolStripMenuItem_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.ForeColor = System.Drawing.Color.White;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(131, 44);
            this.toolStripButton2.Text = "Kayıt Silme";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(122, 44);
            this.toolStripButton1.Text = "Çalışanlar";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.ForeColor = System.Drawing.Color.White;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(131, 44);
            this.toolStripButton3.Text = "Gelir-Gider";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.ForeColor = System.Drawing.Color.White;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(177, 44);
            this.toolStripButton4.Text = "Çamaşır Makinesi";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.ForeColor = System.Drawing.Color.White;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(128, 44);
            this.toolStripButton6.Text = "Kişi Arama";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel21.Controls.Add(this.calisAra);
            this.panel21.Controls.Add(this.ara);
            this.panel21.Controls.Add(this.label37);
            this.panel21.Location = new System.Drawing.Point(342, 142);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(357, 37);
            this.panel21.TabIndex = 31;
            this.panel21.Paint += new System.Windows.Forms.PaintEventHandler(this.panel21_Paint);
            // 
            // calisAra
            // 
            this.calisAra.Image = ((System.Drawing.Image)(resources.GetObject("calisAra.Image")));
            this.calisAra.Location = new System.Drawing.Point(127, 6);
            this.calisAra.Name = "calisAra";
            this.calisAra.Size = new System.Drawing.Size(28, 24);
            this.calisAra.TabIndex = 20;
            this.calisAra.TabStop = false;
            // 
            // ara
            // 
            this.ara.Location = new System.Drawing.Point(158, 8);
            this.ara.Margin = new System.Windows.Forms.Padding(0);
            this.ara.Name = "ara";
            this.ara.Size = new System.Drawing.Size(186, 20);
            this.ara.TabIndex = 18;
            this.ara.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(15, 9);
            this.label37.Margin = new System.Windows.Forms.Padding(0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(101, 20);
            this.label37.TabIndex = 19;
            this.label37.Text = "Çalışan Ara";
            // 
            // label38
            // 
            this.label38.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Monotype Corsiva", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label38.ForeColor = System.Drawing.Color.SteelBlue;
            this.label38.Location = new System.Drawing.Point(1472, 48);
            this.label38.Margin = new System.Windows.Forms.Padding(20);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(215, 18);
            this.label38.TabIndex = 83;
            this.label38.Text = "Hoşgeldiniz Neslihan Demirtaş";
            // 
            // label40
            // 
            this.label40.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label40.Font = new System.Drawing.Font("Monotype Corsiva", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label40.ForeColor = System.Drawing.Color.SteelBlue;
            this.label40.Location = new System.Drawing.Point(1463, 0);
            this.label40.Margin = new System.Windows.Forms.Padding(20);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(224, 43);
            this.label40.TabIndex = 82;
            this.label40.Text = "ARYA APART";
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.DarkOrchid;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(742, 142);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(246, 43);
            this.btnSave.TabIndex = 85;
            this.btnSave.Text = "Çalışan Kaydı";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.button1_Click);
            // 
            // apartYonetimSistemiDataSet
            // 
            this.apartYonetimSistemiDataSet.DataSetName = "ApartYonetimSistemiDataSet";
            this.apartYonetimSistemiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // apartYonetimSistemiDataSetBindingSource
            // 
            this.apartYonetimSistemiDataSetBindingSource.DataSource = this.apartYonetimSistemiDataSet;
            this.apartYonetimSistemiDataSetBindingSource.Position = 0;
            // 
            // apartYonetimSistemiDataSet2
            // 
            this.apartYonetimSistemiDataSet2.DataSetName = "ApartYonetimSistemiDataSet2";
            this.apartYonetimSistemiDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // calisanlarBindingSource
            // 
            this.calisanlarBindingSource.DataMember = "Calisanlar";
            this.calisanlarBindingSource.DataSource = this.apartYonetimSistemiDataSet2;
            // 
            // calisanlarTableAdapter
            // 
            this.calisanlarTableAdapter.ClearBeforeFill = true;
            // 
            // apartYonetimSistemiDataSet3
            // 
            this.apartYonetimSistemiDataSet3.DataSetName = "ApartYonetimSistemiDataSet3";
            this.apartYonetimSistemiDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // calisanbilgileriBindingSource
            // 
            this.calisanbilgileriBindingSource.DataMember = "calisanbilgileri";
            this.calisanbilgileriBindingSource.DataSource = this.apartYonetimSistemiDataSet3;
            // 
            // calisanbilgileriTableAdapter
            // 
            this.calisanbilgileriTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.DarkOrchid;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.DarkOrchid;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ıDDataGridViewTextBoxColumn,
            this.adiDataGridViewTextBoxColumn,
            this.BaslangicSaati,
            this.BitisSaati,
            this.SaatlikUcret,
            this.IzinGunleri,
            this.soyadiDataGridViewTextBoxColumn,
            this.telefonDataGridViewTextBoxColumn,
            this.adresDataGridViewTextBoxColumn,
            this.telefon2DataGridViewTextBoxColumn,
            this.dogumYeriDataGridViewTextBoxColumn,
            this.dogumTarihiDataGridViewTextBoxColumn,
            this.tCNoDataGridViewTextBoxColumn,
            this.goreviDataGridViewTextBoxColumn,
            this.baslangicTarihiDataGridViewTextBoxColumn,
            this.calismaIDDataGridViewTextBoxColumn});
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.dataGridView1.DataSource = this.calisanbilgileriBindingSource3;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.DarkOrchid;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft JhengHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.DarkOrchid;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.Location = new System.Drawing.Point(126, 209);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.BlueViolet;
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.DarkOrchid;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.RowTemplate.Height = 50;
            this.dataGridView1.Size = new System.Drawing.Size(1078, 219);
            this.dataGridView1.TabIndex = 87;
            // 
            // ıDDataGridViewTextBoxColumn
            // 
            this.ıDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.ıDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.ıDDataGridViewTextBoxColumn.Name = "ıDDataGridViewTextBoxColumn";
            this.ıDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // adiDataGridViewTextBoxColumn
            // 
            this.adiDataGridViewTextBoxColumn.DataPropertyName = "Adi";
            this.adiDataGridViewTextBoxColumn.HeaderText = "Adi";
            this.adiDataGridViewTextBoxColumn.Name = "adiDataGridViewTextBoxColumn";
            // 
            // BaslangicSaati
            // 
            this.BaslangicSaati.DataPropertyName = "BaslangicSaati";
            this.BaslangicSaati.HeaderText = "BaslangicSaati";
            this.BaslangicSaati.Name = "BaslangicSaati";
            // 
            // BitisSaati
            // 
            this.BitisSaati.DataPropertyName = "BitisSaati";
            this.BitisSaati.HeaderText = "BitisSaati";
            this.BitisSaati.Name = "BitisSaati";
            // 
            // SaatlikUcret
            // 
            this.SaatlikUcret.DataPropertyName = "SaatlikUcret";
            this.SaatlikUcret.HeaderText = "SaatlikUcret";
            this.SaatlikUcret.Name = "SaatlikUcret";
            // 
            // IzinGunleri
            // 
            this.IzinGunleri.DataPropertyName = "IzinGunleri";
            this.IzinGunleri.HeaderText = "IzinGunleri";
            this.IzinGunleri.Name = "IzinGunleri";
            // 
            // soyadiDataGridViewTextBoxColumn
            // 
            this.soyadiDataGridViewTextBoxColumn.DataPropertyName = "Soyadi";
            this.soyadiDataGridViewTextBoxColumn.HeaderText = "Soyadi";
            this.soyadiDataGridViewTextBoxColumn.Name = "soyadiDataGridViewTextBoxColumn";
            // 
            // telefonDataGridViewTextBoxColumn
            // 
            this.telefonDataGridViewTextBoxColumn.DataPropertyName = "Telefon";
            this.telefonDataGridViewTextBoxColumn.HeaderText = "Telefon";
            this.telefonDataGridViewTextBoxColumn.Name = "telefonDataGridViewTextBoxColumn";
            // 
            // adresDataGridViewTextBoxColumn
            // 
            this.adresDataGridViewTextBoxColumn.DataPropertyName = "Adres";
            this.adresDataGridViewTextBoxColumn.HeaderText = "Adres";
            this.adresDataGridViewTextBoxColumn.Name = "adresDataGridViewTextBoxColumn";
            // 
            // telefon2DataGridViewTextBoxColumn
            // 
            this.telefon2DataGridViewTextBoxColumn.DataPropertyName = "Telefon2";
            this.telefon2DataGridViewTextBoxColumn.HeaderText = "Telefon2";
            this.telefon2DataGridViewTextBoxColumn.Name = "telefon2DataGridViewTextBoxColumn";
            // 
            // dogumYeriDataGridViewTextBoxColumn
            // 
            this.dogumYeriDataGridViewTextBoxColumn.DataPropertyName = "DogumYeri";
            this.dogumYeriDataGridViewTextBoxColumn.HeaderText = "DogumYeri";
            this.dogumYeriDataGridViewTextBoxColumn.Name = "dogumYeriDataGridViewTextBoxColumn";
            // 
            // dogumTarihiDataGridViewTextBoxColumn
            // 
            this.dogumTarihiDataGridViewTextBoxColumn.DataPropertyName = "DogumTarihi";
            this.dogumTarihiDataGridViewTextBoxColumn.HeaderText = "DogumTarihi";
            this.dogumTarihiDataGridViewTextBoxColumn.Name = "dogumTarihiDataGridViewTextBoxColumn";
            // 
            // tCNoDataGridViewTextBoxColumn
            // 
            this.tCNoDataGridViewTextBoxColumn.DataPropertyName = "TCNo";
            this.tCNoDataGridViewTextBoxColumn.HeaderText = "TCNo";
            this.tCNoDataGridViewTextBoxColumn.Name = "tCNoDataGridViewTextBoxColumn";
            // 
            // goreviDataGridViewTextBoxColumn
            // 
            this.goreviDataGridViewTextBoxColumn.DataPropertyName = "Gorevi";
            this.goreviDataGridViewTextBoxColumn.HeaderText = "Gorevi";
            this.goreviDataGridViewTextBoxColumn.Name = "goreviDataGridViewTextBoxColumn";
            // 
            // baslangicTarihiDataGridViewTextBoxColumn
            // 
            this.baslangicTarihiDataGridViewTextBoxColumn.DataPropertyName = "BaslangicTarihi";
            this.baslangicTarihiDataGridViewTextBoxColumn.HeaderText = "BaslangicTarihi";
            this.baslangicTarihiDataGridViewTextBoxColumn.Name = "baslangicTarihiDataGridViewTextBoxColumn";
            // 
            // calismaIDDataGridViewTextBoxColumn
            // 
            this.calismaIDDataGridViewTextBoxColumn.DataPropertyName = "CalismaID";
            this.calismaIDDataGridViewTextBoxColumn.HeaderText = "CalismaID";
            this.calismaIDDataGridViewTextBoxColumn.Name = "calismaIDDataGridViewTextBoxColumn";
            // 
            // calisanbilgileriBindingSource3
            // 
            this.calisanbilgileriBindingSource3.DataMember = "calisanbilgileri";
            this.calisanbilgileriBindingSource3.DataSource = this.apartYonetimSistemiDataSet6;
            // 
            // apartYonetimSistemiDataSet6
            // 
            this.apartYonetimSistemiDataSet6.DataSetName = "ApartYonetimSistemiDataSet6";
            this.apartYonetimSistemiDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // apartYonetimSistemiDataSet4
            // 
            this.apartYonetimSistemiDataSet4.DataSetName = "ApartYonetimSistemiDataSet4";
            this.apartYonetimSistemiDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // calisanbilgileriBindingSource1
            // 
            this.calisanbilgileriBindingSource1.DataMember = "calisanbilgileri";
            this.calisanbilgileriBindingSource1.DataSource = this.apartYonetimSistemiDataSet4;
            // 
            // calisanbilgileriTableAdapter1
            // 
            this.calisanbilgileriTableAdapter1.ClearBeforeFill = true;
            // 
            // apartYonetimSistemiDataSet5
            // 
            this.apartYonetimSistemiDataSet5.DataSetName = "ApartYonetimSistemiDataSet5";
            this.apartYonetimSistemiDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // calisanbilgileriBindingSource2
            // 
            this.calisanbilgileriBindingSource2.DataMember = "calisanbilgileri";
            this.calisanbilgileriBindingSource2.DataSource = this.apartYonetimSistemiDataSet5;
            // 
            // calisanbilgileriTableAdapter2
            // 
            this.calisanbilgileriTableAdapter2.ClearBeforeFill = true;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Indigo;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(614, 494);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(110, 30);
            this.button3.TabIndex = 89;
            this.button3.Text = "Sil";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Indigo;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(730, 494);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(104, 30);
            this.button4.TabIndex = 90;
            this.button4.Text = "Güncelle";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // calisanbilgileriTableAdapter3
            // 
            this.calisanbilgileriTableAdapter3.ClearBeforeFill = true;
            // 
            // apartAdi
            // 
            this.apartAdi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.apartAdi.AutoSize = true;
            this.apartAdi.BackColor = System.Drawing.Color.BlueViolet;
            this.apartAdi.Font = new System.Drawing.Font("Monotype Corsiva", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.apartAdi.ForeColor = System.Drawing.Color.White;
            this.apartAdi.Location = new System.Drawing.Point(1135, 0);
            this.apartAdi.Margin = new System.Windows.Forms.Padding(20);
            this.apartAdi.Name = "apartAdi";
            this.apartAdi.Size = new System.Drawing.Size(184, 36);
            this.apartAdi.TabIndex = 91;
            this.apartAdi.Text = "ARYA APART";
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.ForeColor = System.Drawing.Color.White;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(182, 44);
            this.toolStripButton7.Text = "Oda ve Daire Kayıt";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // Calisanlar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1331, 733);
            this.Controls.Add(this.apartAdi);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.panel21);
            this.Controls.Add(this.toolStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Calisanlar";
            this.Text = "calisanlar";
            this.Load += new System.EventHandler(this.Calisanlar_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.calisAra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.calisanlarBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.calisanbilgileriBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.calisanbilgileriBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.calisanbilgileriBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.calisanbilgileriBindingSource2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem yazOkuluKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.PictureBox calisAra;
        private System.Windows.Forms.TextBox ara;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ToolStripMenuItem çalışanKaydıToolStripMenuItem;
        private System.Windows.Forms.Button btnSave;
        private ApartYonetimSistemiDataSet apartYonetimSistemiDataSet;
        private System.Windows.Forms.BindingSource apartYonetimSistemiDataSetBindingSource;
        private ApartYonetimSistemiDataSet2 apartYonetimSistemiDataSet2;
        private System.Windows.Forms.BindingSource calisanlarBindingSource;
        private ApartYonetimSistemiDataSet2TableAdapters.CalisanlarTableAdapter calisanlarTableAdapter;
        private ApartYonetimSistemiDataSet3 apartYonetimSistemiDataSet3;
        private System.Windows.Forms.BindingSource calisanbilgileriBindingSource;
        private ApartYonetimSistemiDataSet3TableAdapters.calisanbilgileriTableAdapter calisanbilgileriTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private ApartYonetimSistemiDataSet4 apartYonetimSistemiDataSet4;
        private System.Windows.Forms.BindingSource calisanbilgileriBindingSource1;
        private ApartYonetimSistemiDataSet4TableAdapters.calisanbilgileriTableAdapter calisanbilgileriTableAdapter1;
        private ApartYonetimSistemiDataSet5 apartYonetimSistemiDataSet5;
        private System.Windows.Forms.BindingSource calisanbilgileriBindingSource2;
        private ApartYonetimSistemiDataSet5TableAdapters.calisanbilgileriTableAdapter calisanbilgileriTableAdapter2;
        private ApartYonetimSistemiDataSet6 apartYonetimSistemiDataSet6;
        private System.Windows.Forms.BindingSource calisanbilgileriBindingSource3;
        private ApartYonetimSistemiDataSet6TableAdapters.calisanbilgileriTableAdapter calisanbilgileriTableAdapter3;
        private System.Windows.Forms.DataGridViewTextBoxColumn ıDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn BaslangicSaati;
        private System.Windows.Forms.DataGridViewTextBoxColumn BitisSaati;
        private System.Windows.Forms.DataGridViewTextBoxColumn SaatlikUcret;
        private System.Windows.Forms.DataGridViewTextBoxColumn IzinGunleri;
        private System.Windows.Forms.DataGridViewTextBoxColumn soyadiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefon2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dogumYeriDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dogumTarihiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tCNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn goreviDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn baslangicTarihiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn calismaIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.Label apartAdi;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
    }
}