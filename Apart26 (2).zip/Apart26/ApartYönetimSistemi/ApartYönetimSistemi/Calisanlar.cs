﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class Calisanlar : Form
    {
        SqlConnection cnn = database.getConnection();        
        SqlCommand cmd;
        DataTable dt;
        SqlDataAdapter adpt;
        public Calisanlar()
        {
            InitializeComponent();
        }
        public string apartid { get; set; }
        public void getapart()

        {

            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Apartlar where ID  = '" + apartid + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                  apartAdi.Text = dr4[1] as string;

                }
                dr4.NextResult();
                dr4.Close();

            }
        }
        public void DisplayData()
        {
            try
            {
                cnn.Open();
                adpt = new SqlDataAdapter("select * from calisanbilgileri", cnn);
                dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch { MessageBox.Show("Hata"); }
        }
        private void Calisanlar_Load(object sender, EventArgs e)
        {
            getapart();
            DisplayData();


            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
        }
       

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.apartid = apartid;
            this.Hide();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.apartid = apartid;
            this.Hide();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.apartid = apartid;
            this.Hide();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.apartid = apartid;
            this.Hide();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.apartid = apartid;
            this.Hide();
            camasirmakinesi.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.id = apartid;
            this.Hide();
            anasayfa.Show();
        }

   
        private void button1_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisan = new CalisanKaydi();
            calisan.apartid = apartid;
            this.Hide();
            calisan.Show();
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.calisanbilgileriTableAdapter3.FillBy(this.apartYonetimSistemiDataSet6.calisanbilgileri);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
        int id ;
     

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                

        }
        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (id != 0)
                {
                    SqlConnection cnn = database.getConnection();
                    SqlCommand cmd = new SqlCommand("UPDATE Calisanlar SET Durum=@Durum WHERE ID=@ID ", cnn);
                    cnn.Open();
                    cmd.Parameters.AddWithValue("@ID", id);
                    cmd.Parameters.AddWithValue("@Durum", 1);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Silme Başarılı");
                    cnn.Close();
                    DisplayData();
                    id = 0;
                }
                else
                {
                    MessageBox.Show("Seçim yapmadınız");
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.apartid = apartid;
            this.Hide();
            kisiarama.Show();
        }

      
        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.apartid = apartid;
            this.Hide();
            calisanlistesi.Show();
        }
        public void CalisanAra(string calisanadi)
        {
            try
            {
                cnn.Open();
                string sorgu = "select * from calisanbilgileri where Adi like '%" + calisanadi + "%' or Soyadi like '%" + calisanadi + "%' ";
                adpt = new SqlDataAdapter(sorgu, cnn);
                dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch { MessageBox.Show("Hata"); }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            CalisanAra(ara.Text);
        }

        private void panel21_Paint(object sender, PaintEventArgs e)
        {

        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            OdaEkleme odaekleme = new OdaEkleme();
            odaekleme.apartid = apartid;
            this.Hide();
            odaekleme.Show();
        }
    }
}
