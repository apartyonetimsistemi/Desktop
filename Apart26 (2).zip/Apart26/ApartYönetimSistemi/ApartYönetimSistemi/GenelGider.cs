﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class GenelGider : Form
    {
        public GenelGider()
        {
            InitializeComponent();
        }
        string secilenay;
        string secilenyıl;
        private void GenelGider_Load(object sender, EventArgs e)
        {
            getapart();
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
        }
        public string apartid { get; set; }
        public void getapart()

        {

            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Apartlar where ID  = '" + apartid + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    apartAdi.Text = dr4[1] as string;

                }
                dr4.NextResult();
                dr4.Close();

            }
        }
        private void ay_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                secilenay = ay.SelectedItem.ToString();
                secilenyıl = yıl.SelectedItem.ToString();
               


            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        public void giderEkle()
        {            
            try
            {
                int d = Int32.Parse(txtd.Text);
                int e = Int32.Parse(txte.Text);
                int s = Int32.Parse(txts.Text);
                int di = Int32.Parse(txtdi.Text);
                int m = Int32.Parse(txtm.Text);
                int t = Int32.Parse(txtt.Text);
                int ssk = Int32.Parse(txtssk.Text);
                int sto = Int32.Parse(txtStopaj.Text);
                int kdv = Int32.Parse(txtKDV.Text);
                int ba = Int32.Parse(txtBagkur.Text);
                int secilenyilint = Int32.Parse(secilenyıl);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd1 = new SqlCommand("INSERT INTO GenelGiderler (OrtakAlanDogalgaz,OrtakAlanElektrik,OrtakAlanSu,OrtakAlanTüp,SSK,Market,DıgerGiderler,Bagkur,Stopaj,KDV,Ay,Yıl) VALUES (@OrtakAlanDogalgaz,@OrtakAlanElektrik,@OrtakAlanSu,@OrtakAlanTüp,@SSK,@Market,@DıgerGiderler,@Bagkur,@Stopaj,@KDV,@Ay,@Yıl) ", cnn);
                cmd1.Parameters.Add(new SqlParameter("@OrtakAlanDogalgaz", d));
                cmd1.Parameters.Add(new SqlParameter("@OrtakAlanElektrik", e));
                cmd1.Parameters.Add(new SqlParameter("@OrtakAlanSu", s));
                cmd1.Parameters.Add(new SqlParameter("@OrtakAlanTüp", t));
                cmd1.Parameters.Add(new SqlParameter("@SSK", ssk));
                cmd1.Parameters.Add(new SqlParameter("@Market", sto));
                cmd1.Parameters.Add(new SqlParameter("@DıgerGiderler", di));
                cmd1.Parameters.Add(new SqlParameter("@Bagkur",ba));
                cmd1.Parameters.Add(new SqlParameter("@Stopaj", sto));
                cmd1.Parameters.Add(new SqlParameter("@KDV", kdv));
                cmd1.Parameters.Add(new SqlParameter("@Ay", secilenay));
                cmd1.Parameters.Add(new SqlParameter("@Yıl", secilenyilint));
                int a = cmd1.ExecuteNonQuery();
                if (a>0)
                {
                    MessageBox.Show("Ekleme Başarılı");
                }
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            giderEkle();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.id = apartid;
            this.Hide();
            anasayfa.Show();
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.id = apartid;
            this.Hide();
            anasayfa.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.apartid = apartid;
            this.Hide();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.apartid = apartid;
            this.Hide();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.apartid = apartid;
            this.Hide();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.apartid = apartid;
            this.Hide();
            camasirmakinesi.Show();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.apartid = apartid;
            this.Hide();
            kisiarama.Show();
        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.apartid = apartid;
            this.Hide();
            calisanlistesi.Show();
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            OdaEkleme odaekleme = new OdaEkleme();
            odaekleme.apartid = apartid;
            this.Hide();
            odaekleme.Show();
        }
    }
}
