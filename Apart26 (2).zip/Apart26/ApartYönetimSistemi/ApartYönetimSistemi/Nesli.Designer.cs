﻿namespace ApartYönetimSistemi
{
    partial class Nesli
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.LBL = new System.Windows.Forms.Label();
            this.btnArya = new System.Windows.Forms.Button();
            this.btnNilsu = new System.Windows.Forms.Button();
            this.btnBegonvil = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LBL
            // 
            this.LBL.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LBL.AutoSize = true;
            this.LBL.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.LBL.ForeColor = System.Drawing.Color.White;
            this.LBL.Location = new System.Drawing.Point(285, 109);
            this.LBL.Name = "LBL";
            this.LBL.Size = new System.Drawing.Size(503, 45);
            this.LBL.TabIndex = 0;
            this.LBL.Text = "NESLİ APART YÖNETİM SİSTEMİ";
            // 
            // btnArya
            // 
            this.btnArya.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnArya.BackColor = System.Drawing.Color.DarkViolet;
            this.btnArya.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArya.ForeColor = System.Drawing.Color.White;
            this.btnArya.Location = new System.Drawing.Point(349, 199);
            this.btnArya.Name = "btnArya";
            this.btnArya.Size = new System.Drawing.Size(320, 55);
            this.btnArya.TabIndex = 1;
            this.btnArya.Text = "Arya Apart";
            this.btnArya.UseVisualStyleBackColor = false;
            this.btnArya.Click += new System.EventHandler(this.button1_Click);
            this.btnArya.MouseLeave += new System.EventHandler(this.btnArya_MouseLeave);
            this.btnArya.MouseHover += new System.EventHandler(this.btnArya_MouseHover);
            // 
            // btnNilsu
            // 
            this.btnNilsu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnNilsu.BackColor = System.Drawing.Color.MediumOrchid;
            this.btnNilsu.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNilsu.ForeColor = System.Drawing.Color.White;
            this.btnNilsu.Location = new System.Drawing.Point(349, 264);
            this.btnNilsu.Name = "btnNilsu";
            this.btnNilsu.Size = new System.Drawing.Size(320, 55);
            this.btnNilsu.TabIndex = 2;
            this.btnNilsu.Text = "Nilsu Apart";
            this.btnNilsu.UseVisualStyleBackColor = false;
            this.btnNilsu.Click += new System.EventHandler(this.button2_Click);
            this.btnNilsu.MouseLeave += new System.EventHandler(this.btnNilsu_MouseLeave);
            this.btnNilsu.MouseHover += new System.EventHandler(this.btnNilsu_MouseHover);
            // 
            // btnBegonvil
            // 
            this.btnBegonvil.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnBegonvil.BackColor = System.Drawing.Color.Violet;
            this.btnBegonvil.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBegonvil.ForeColor = System.Drawing.Color.White;
            this.btnBegonvil.Location = new System.Drawing.Point(349, 328);
            this.btnBegonvil.Name = "btnBegonvil";
            this.btnBegonvil.Size = new System.Drawing.Size(320, 55);
            this.btnBegonvil.TabIndex = 3;
            this.btnBegonvil.Text = "Begonvil Apart";
            this.btnBegonvil.UseVisualStyleBackColor = false;
            this.btnBegonvil.Click += new System.EventHandler(this.button3_Click);
            this.btnBegonvil.MouseLeave += new System.EventHandler(this.btnBegonvil_MouseLeave);
            this.btnBegonvil.MouseHover += new System.EventHandler(this.btnBegonvil_MouseHover);
            // 
            // Nesli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1073, 479);
            this.Controls.Add(this.btnBegonvil);
            this.Controls.Add(this.btnNilsu);
            this.Controls.Add(this.btnArya);
            this.Controls.Add(this.LBL);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Nesli";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LBL;
        private System.Windows.Forms.Button btnArya;
        private System.Windows.Forms.Button btnNilsu;
        private System.Windows.Forms.Button btnBegonvil;
    }
}

