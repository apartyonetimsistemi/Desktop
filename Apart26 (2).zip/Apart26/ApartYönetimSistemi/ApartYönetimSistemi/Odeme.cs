﻿using ApartYönetimSistemi.data;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class Odeme : Form
    {
        public Odeme()
        {
            InitializeComponent();

        }
        List<string> aylar = new List<string>();
        public string kisiid { get; set; }
        List<int> tumAylar11 = new List<int>();
        ArrayList tumAylar = new ArrayList();
        public string apartid { get; set; }
        public void getapart()

        {

            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Apartlar where ID  = '" + apartid + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    apartAdi.Text = dr4[1] as string;

                }
                dr4.NextResult();
                dr4.Close();

            }
        }
        public void DisplayData()
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                int id = Int32.Parse(kisiid);
                SqlDataAdapter adpt = new SqlDataAdapter("select Ay,Miktar,OdemeSekli,YilID from Aykira where KisiID = '" + id + "'", cnn);
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }
        public void getodemebilg()
        {
            SqlConnection cnn = database.getConnection();
            cnn.Open();
            int id = Int32.Parse(kisiid);
            using (SqlCommand cmd4 = new SqlCommand("select Ay from Aykira where KisiID = '" + id + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    tumAylar.Add(dr4["Ay"]);
                }
                dr4.NextResult();
                dr4.Close();
            }
            for (int i = 0; i < tumAylar.Count; i++)
            {

                FlowLayoutPanel pnl = new FlowLayoutPanel();
                Button btn = new Button();
                btn.Text = tumAylar[i].ToString();
                btn.Name = tumAylar[i].ToString();
                btn.Click += new System.EventHandler(btn_Click);               
                pnl.Controls.Add(btn);               
                flowLayoutPanel1.Controls.Add(pnl);

            }
        }

        private void btn_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;      
            string ay = btn.Name;
            KiraOde kiraode = new KiraOde();
            kiraode.id = kisiid;
            kiraode.odenecekAy = ay;
            kiraode.Show();     
        }

        private void Odeme_Load(object sender, EventArgs e)
        {

            getapart();
            DisplayData();
            getodemebilg();
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.id = apartid;
            this.Hide();
            anasayfa.Show();
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.apartid = apartid;
            this.Hide();
            yenikayit.Show();
        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.apartid = apartid;
            this.Hide();
            calisanlistesi.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.apartid = apartid;
            this.Hide();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.apartid = apartid;
            this.Hide();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.apartid = apartid;
            this.Hide();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.apartid = apartid;
            this.Hide();
            camasirmakinesi.Show();


        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.apartid = apartid;
            this.Hide();
            kisiarama.Show();
        }
        public void odeme()
        {
            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT Ay FROM AyKira WHERE ID  = '" + kisiid + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    aylar.Add(dr4.GetString(3));

                }
                dr4.NextResult();
                dr4.Close();

            }
        }



        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            OdaEkleme odaekleme = new OdaEkleme();
            odaekleme.apartid = apartid;
            this.Hide();
            odaekleme.Show();
        }
    }
}
