﻿namespace ApartYönetimSistemi
{
    partial class YeniKayıt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YeniKayıt));
            this.kayitBilgi = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtTelNo2 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtUyruk = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtDogumYeri = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtOkul = new System.Windows.Forms.TextBox();
            this.txtOzelDurum = new System.Windows.Forms.RichTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtDogumTarihi = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.txtTelNo = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtAdres = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.sinif = new System.Windows.Forms.ComboBox();
            this.txtBolum = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTc = new System.Windows.Forms.TextBox();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtBabaTelNo = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtAnneTelNo = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtBabaAdi = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtBabaMeslek = new System.Windows.Forms.TextBox();
            this.txtAnneMeslek = new System.Windows.Forms.TextBox();
            this.txtAnneAdi = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtAileAdres = new System.Windows.Forms.RichTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.txtIban = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtDepozito = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.bitisTarih = new System.Windows.Forms.DateTimePicker();
            this.baslangicTarih = new System.Windows.Forms.DateTimePicker();
            this.label22 = new System.Windows.Forms.Label();
            this.txtAylikUcret = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.yazOkuluKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çalışanKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.btnSave = new System.Windows.Forms.Button();
            this.secilenyatak = new System.Windows.Forms.Button();
            this.apartAdi = new System.Windows.Forms.Label();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.panel1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel21.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // kayitBilgi
            // 
            this.kayitBilgi.AutoSize = true;
            this.kayitBilgi.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kayitBilgi.ForeColor = System.Drawing.Color.White;
            this.kayitBilgi.Location = new System.Drawing.Point(52, 6);
            this.kayitBilgi.Name = "kayitBilgi";
            this.kayitBilgi.Size = new System.Drawing.Size(0, 25);
            this.kayitBilgi.TabIndex = 28;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel1.Controls.Add(this.txtTelNo2);
            this.panel1.Controls.Add(this.label33);
            this.panel1.Controls.Add(this.txtUyruk);
            this.panel1.Controls.Add(this.label32);
            this.panel1.Controls.Add(this.txtDogumYeri);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.txtOkul);
            this.panel1.Controls.Add(this.txtOzelDurum);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.txtDogumTarihi);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.txtTelNo);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.txtAdres);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.sinif);
            this.panel1.Controls.Add(this.txtBolum);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txtTc);
            this.panel1.Controls.Add(this.txtSoyad);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtAd);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(39, 153);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(803, 384);
            this.panel1.TabIndex = 29;
            // 
            // txtTelNo2
            // 
            this.txtTelNo2.Location = new System.Drawing.Point(151, 279);
            this.txtTelNo2.Name = "txtTelNo2";
            this.txtTelNo2.Size = new System.Drawing.Size(203, 20);
            this.txtTelNo2.TabIndex = 110;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(29, 289);
            this.label33.Name = "label33";
            this.label33.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label33.Size = new System.Drawing.Size(67, 16);
            this.label33.TabIndex = 109;
            this.label33.Text = "Tel No 2";
            // 
            // txtUyruk
            // 
            this.txtUyruk.Location = new System.Drawing.Point(151, 119);
            this.txtUyruk.Name = "txtUyruk";
            this.txtUyruk.Size = new System.Drawing.Size(203, 20);
            this.txtUyruk.TabIndex = 108;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(29, 124);
            this.label32.Name = "label32";
            this.label32.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label32.Size = new System.Drawing.Size(48, 16);
            this.label32.TabIndex = 107;
            this.label32.Text = "Uyruk";
            // 
            // txtDogumYeri
            // 
            this.txtDogumYeri.Location = new System.Drawing.Point(151, 215);
            this.txtDogumYeri.Name = "txtDogumYeri";
            this.txtDogumYeri.Size = new System.Drawing.Size(203, 20);
            this.txtDogumYeri.TabIndex = 32;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(29, 223);
            this.label30.Name = "label30";
            this.label30.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label30.Size = new System.Drawing.Size(89, 16);
            this.label30.TabIndex = 31;
            this.label30.Text = "Doğum Yeri";
            // 
            // txtOkul
            // 
            this.txtOkul.Location = new System.Drawing.Point(533, 91);
            this.txtOkul.Name = "txtOkul";
            this.txtOkul.Size = new System.Drawing.Size(203, 20);
            this.txtOkul.TabIndex = 30;
            // 
            // txtOzelDurum
            // 
            this.txtOzelDurum.Location = new System.Drawing.Point(151, 311);
            this.txtOzelDurum.Name = "txtOzelDurum";
            this.txtOzelDurum.Size = new System.Drawing.Size(203, 54);
            this.txtOzelDurum.TabIndex = 29;
            this.txtOzelDurum.Text = "";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(29, 322);
            this.label14.Name = "label14";
            this.label14.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label14.Size = new System.Drawing.Size(87, 16);
            this.label14.TabIndex = 28;
            this.label14.Text = "Özel Durum";
            // 
            // txtDogumTarihi
            // 
            this.txtDogumTarihi.Location = new System.Drawing.Point(151, 183);
            this.txtDogumTarihi.Name = "txtDogumTarihi";
            this.txtDogumTarihi.Size = new System.Drawing.Size(203, 20);
            this.txtDogumTarihi.TabIndex = 27;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.DarkOrchid;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(21, 15);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(178, 24);
            this.label15.TabIndex = 26;
            this.label15.Text = "KİŞİSEL BİLGİLER";
            // 
            // txtTelNo
            // 
            this.txtTelNo.Location = new System.Drawing.Point(151, 247);
            this.txtTelNo.Name = "txtTelNo";
            this.txtTelNo.Size = new System.Drawing.Size(203, 20);
            this.txtTelNo.TabIndex = 24;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(29, 256);
            this.label13.Name = "label13";
            this.label13.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label13.Size = new System.Drawing.Size(55, 16);
            this.label13.TabIndex = 23;
            this.label13.Text = "Tel No";
            // 
            // txtAdres
            // 
            this.txtAdres.Location = new System.Drawing.Point(533, 186);
            this.txtAdres.Name = "txtAdres";
            this.txtAdres.Size = new System.Drawing.Size(203, 83);
            this.txtAdres.TabIndex = 22;
            this.txtAdres.Text = "";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(416, 190);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(49, 16);
            this.label10.TabIndex = 21;
            this.label10.Text = "Adres";
            // 
            // sinif
            // 
            this.sinif.FormattingEnabled = true;
            this.sinif.Items.AddRange(new object[] {
            "Hazırlık",
            "1.Sınıf",
            "2.Sınıf",
            "3.Sınıf",
            "4.Sınıf",
            "5.Sınıf",
            "6.Sınıf"});
            this.sinif.Location = new System.Drawing.Point(533, 156);
            this.sinif.Name = "sinif";
            this.sinif.Size = new System.Drawing.Size(203, 21);
            this.sinif.TabIndex = 20;
            // 
            // txtBolum
            // 
            this.txtBolum.Location = new System.Drawing.Point(533, 123);
            this.txtBolum.Name = "txtBolum";
            this.txtBolum.Size = new System.Drawing.Size(203, 20);
            this.txtBolum.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(416, 91);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 16);
            this.label9.TabIndex = 16;
            this.label9.Text = "Okulu";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(413, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 16);
            this.label6.TabIndex = 17;
            this.label6.Text = "Bölümü";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(416, 157);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(42, 16);
            this.label5.TabIndex = 15;
            this.label5.Text = "Sınıfı";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(-302, 43);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "Soyadı";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(27, 91);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 16);
            this.label8.TabIndex = 8;
            this.label8.Text = "Soyadı";
            // 
            // txtTc
            // 
            this.txtTc.Location = new System.Drawing.Point(151, 151);
            this.txtTc.Name = "txtTc";
            this.txtTc.Size = new System.Drawing.Size(203, 20);
            this.txtTc.TabIndex = 9;
            // 
            // txtSoyad
            // 
            this.txtSoyad.Location = new System.Drawing.Point(151, 87);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(203, 20);
            this.txtSoyad.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(29, 157);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 16);
            this.label11.TabIndex = 8;
            this.label11.Text = "TC No";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(29, 190);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Doğum Tarihi";
            // 
            // txtAd
            // 
            this.txtAd.Location = new System.Drawing.Point(151, 56);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(203, 20);
            this.txtAd.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 54);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(29, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Adı";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(37, 95);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(70, 16);
            this.label27.TabIndex = 27;
            this.label27.Text = "Anne Adı";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(38, 225);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(96, 16);
            this.label17.TabIndex = 29;
            this.label17.Text = "Baba Tel No";
            // 
            // txtBabaTelNo
            // 
            this.txtBabaTelNo.Location = new System.Drawing.Point(155, 217);
            this.txtBabaTelNo.Name = "txtBabaTelNo";
            this.txtBabaTelNo.Size = new System.Drawing.Size(203, 20);
            this.txtBabaTelNo.TabIndex = 33;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(37, 176);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(94, 16);
            this.label20.TabIndex = 31;
            this.label20.Text = "Anne Tel No";
            // 
            // txtAnneTelNo
            // 
            this.txtAnneTelNo.Location = new System.Drawing.Point(155, 177);
            this.txtAnneTelNo.Name = "txtAnneTelNo";
            this.txtAnneTelNo.Size = new System.Drawing.Size(203, 20);
            this.txtAnneTelNo.TabIndex = 35;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(38, 135);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(72, 16);
            this.label23.TabIndex = 32;
            this.label23.Text = "Baba Adı";
            // 
            // txtBabaAdi
            // 
            this.txtBabaAdi.Location = new System.Drawing.Point(155, 137);
            this.txtBabaAdi.Name = "txtBabaAdi";
            this.txtBabaAdi.Size = new System.Drawing.Size(203, 20);
            this.txtBabaAdi.TabIndex = 36;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.label7);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(784, 82);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(8, 8);
            this.flowLayoutPanel1.TabIndex = 49;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(3, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 360);
            this.label7.TabIndex = 27;
            this.label7.Text = "KİŞİSEL BİLGİLER";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.txtBabaMeslek);
            this.panel2.Controls.Add(this.txtAnneMeslek);
            this.panel2.Controls.Add(this.txtAnneAdi);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.flowLayoutPanel1);
            this.panel2.Controls.Add(this.txtAileAdres);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.txtBabaAdi);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.txtAnneTelNo);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.txtBabaTelNo);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Location = new System.Drawing.Point(858, 153);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(412, 420);
            this.panel2.TabIndex = 32;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(38, 374);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(99, 16);
            this.label26.TabIndex = 55;
            this.label26.Text = "Baba Meslek";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(37, 333);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(97, 16);
            this.label25.TabIndex = 54;
            this.label25.Text = "Anne Meslek";
            // 
            // txtBabaMeslek
            // 
            this.txtBabaMeslek.Location = new System.Drawing.Point(155, 373);
            this.txtBabaMeslek.Name = "txtBabaMeslek";
            this.txtBabaMeslek.Size = new System.Drawing.Size(203, 20);
            this.txtBabaMeslek.TabIndex = 53;
            // 
            // txtAnneMeslek
            // 
            this.txtAnneMeslek.Location = new System.Drawing.Point(155, 333);
            this.txtAnneMeslek.Name = "txtAnneMeslek";
            this.txtAnneMeslek.Size = new System.Drawing.Size(203, 20);
            this.txtAnneMeslek.TabIndex = 52;
            // 
            // txtAnneAdi
            // 
            this.txtAnneAdi.Location = new System.Drawing.Point(155, 97);
            this.txtAnneAdi.Name = "txtAnneAdi";
            this.txtAnneAdi.Size = new System.Drawing.Size(203, 20);
            this.txtAnneAdi.TabIndex = 51;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(36, 15);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(153, 24);
            this.label16.TabIndex = 50;
            this.label16.Text = "AİLE BİLGİLERİ";
            // 
            // txtAileAdres
            // 
            this.txtAileAdres.Location = new System.Drawing.Point(155, 257);
            this.txtAileAdres.Name = "txtAileAdres";
            this.txtAileAdres.Size = new System.Drawing.Size(203, 56);
            this.txtAileAdres.TabIndex = 44;
            this.txtAileAdres.Text = "";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(38, 283);
            this.label18.Name = "label18";
            this.label18.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label18.Size = new System.Drawing.Size(49, 16);
            this.label18.TabIndex = 43;
            this.label18.Text = "Adres";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.txtIban);
            this.panel3.Controls.Add(this.label28);
            this.panel3.Controls.Add(this.txtDepozito);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.bitisTarih);
            this.panel3.Controls.Add(this.baslangicTarih);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.txtAylikUcret);
            this.panel3.Controls.Add(this.label24);
            this.panel3.Controls.Add(this.label29);
            this.panel3.Location = new System.Drawing.Point(39, 543);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(803, 184);
            this.panel3.TabIndex = 33;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(19, 19);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(178, 24);
            this.label19.TabIndex = 56;
            this.label19.Text = "SENET BİLGİLERİ";
            // 
            // txtIban
            // 
            this.txtIban.Location = new System.Drawing.Point(142, 144);
            this.txtIban.Name = "txtIban";
            this.txtIban.Size = new System.Drawing.Size(203, 20);
            this.txtIban.TabIndex = 55;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(18, 144);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(108, 16);
            this.label28.TabIndex = 54;
            this.label28.Text = "Iban Numarası";
            // 
            // txtDepozito
            // 
            this.txtDepozito.Location = new System.Drawing.Point(531, 109);
            this.txtDepozito.Name = "txtDepozito";
            this.txtDepozito.Size = new System.Drawing.Size(203, 20);
            this.txtDepozito.TabIndex = 53;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(412, 109);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(115, 16);
            this.label21.TabIndex = 52;
            this.label21.Text = "Depozito Ücreti";
            // 
            // bitisTarih
            // 
            this.bitisTarih.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.bitisTarih.Location = new System.Drawing.Point(142, 109);
            this.bitisTarih.Name = "bitisTarih";
            this.bitisTarih.Size = new System.Drawing.Size(203, 20);
            this.bitisTarih.TabIndex = 51;
            this.bitisTarih.ValueChanged += new System.EventHandler(this.bitisTarih_ValueChanged);
            // 
            // baslangicTarih
            // 
            this.baslangicTarih.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.baslangicTarih.Location = new System.Drawing.Point(140, 74);
            this.baslangicTarih.Name = "baslangicTarih";
            this.baslangicTarih.Size = new System.Drawing.Size(203, 20);
            this.baslangicTarih.TabIndex = 50;
            this.baslangicTarih.ValueChanged += new System.EventHandler(this.baslangicTarih_ValueChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(20, 109);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(82, 16);
            this.label22.TabIndex = 32;
            this.label22.Text = "Bitiş Tarihi";
            // 
            // txtAylikUcret
            // 
            this.txtAylikUcret.Location = new System.Drawing.Point(531, 74);
            this.txtAylikUcret.Name = "txtAylikUcret";
            this.txtAylikUcret.Size = new System.Drawing.Size(203, 20);
            this.txtAylikUcret.TabIndex = 35;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(412, 74);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(83, 16);
            this.label24.TabIndex = 31;
            this.label24.Text = "Aylık Ücret";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(18, 74);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(121, 16);
            this.label29.TabIndex = 27;
            this.label29.Text = "Başlangıç Tarihi";
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.BlueViolet;
            this.panel21.Controls.Add(this.kayitBilgi);
            this.panel21.Location = new System.Drawing.Point(39, 112);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(485, 37);
            this.panel21.TabIndex = 37;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Indigo;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(530, 112);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(125, 37);
            this.button2.TabIndex = 38;
            this.button2.Text = "Oda Seç";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.BlueViolet;
            this.toolStrip1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton5,
            this.toolStripSplitButton1,
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton6,
            this.toolStripButton7});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1370, 47);
            this.toolStrip1.TabIndex = 39;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.ForeColor = System.Drawing.Color.White;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(123, 44);
            this.toolStripButton5.Text = "Ana Sayfa";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yazOkuluKaydıToolStripMenuItem,
            this.normalKayıtToolStripMenuItem,
            this.çalışanKaydıToolStripMenuItem});
            this.toolStripSplitButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(133, 44);
            this.toolStripSplitButton1.Text = "Yeni Kayıt";
            // 
            // yazOkuluKaydıToolStripMenuItem
            // 
            this.yazOkuluKaydıToolStripMenuItem.Name = "yazOkuluKaydıToolStripMenuItem";
            this.yazOkuluKaydıToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.yazOkuluKaydıToolStripMenuItem.Text = "Yaz Okulu Kaydı";
            this.yazOkuluKaydıToolStripMenuItem.Click += new System.EventHandler(this.yazOkuluKaydıToolStripMenuItem_Click);
            // 
            // normalKayıtToolStripMenuItem
            // 
            this.normalKayıtToolStripMenuItem.Name = "normalKayıtToolStripMenuItem";
            this.normalKayıtToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.normalKayıtToolStripMenuItem.Text = "Normal Kayıt";
            this.normalKayıtToolStripMenuItem.Click += new System.EventHandler(this.normalKayıtToolStripMenuItem_Click);
            // 
            // çalışanKaydıToolStripMenuItem
            // 
            this.çalışanKaydıToolStripMenuItem.Name = "çalışanKaydıToolStripMenuItem";
            this.çalışanKaydıToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.çalışanKaydıToolStripMenuItem.Text = "Çalışan Kaydı";
            this.çalışanKaydıToolStripMenuItem.Click += new System.EventHandler(this.çalışanKaydıToolStripMenuItem_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.ForeColor = System.Drawing.Color.White;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(131, 44);
            this.toolStripButton2.Text = "Kayıt Silme";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(122, 44);
            this.toolStripButton1.Text = "Çalışanlar";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.ForeColor = System.Drawing.Color.White;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(131, 44);
            this.toolStripButton3.Text = "Gelir-Gider";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.ForeColor = System.Drawing.Color.White;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(177, 44);
            this.toolStripButton4.Text = "Çamaşır Makinesi";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.ForeColor = System.Drawing.Color.White;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(128, 44);
            this.toolStripButton6.Text = "Kişi Arama";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Indigo;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(977, 617);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(187, 50);
            this.btnSave.TabIndex = 35;
            this.btnSave.Text = "KAYDET";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // secilenyatak
            // 
            this.secilenyatak.BackColor = System.Drawing.Color.BlueViolet;
            this.secilenyatak.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.secilenyatak.ForeColor = System.Drawing.Color.White;
            this.secilenyatak.Location = new System.Drawing.Point(677, 112);
            this.secilenyatak.Name = "secilenyatak";
            this.secilenyatak.Size = new System.Drawing.Size(125, 37);
            this.secilenyatak.TabIndex = 41;
            this.secilenyatak.UseVisualStyleBackColor = false;
            this.secilenyatak.Click += new System.EventHandler(this.secilenyatak_Click);
            // 
            // apartAdi
            // 
            this.apartAdi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.apartAdi.AutoSize = true;
            this.apartAdi.BackColor = System.Drawing.Color.BlueViolet;
            this.apartAdi.Font = new System.Drawing.Font("Monotype Corsiva", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.apartAdi.ForeColor = System.Drawing.Color.White;
            this.apartAdi.Location = new System.Drawing.Point(1186, 0);
            this.apartAdi.Margin = new System.Windows.Forms.Padding(20);
            this.apartAdi.Name = "apartAdi";
            this.apartAdi.Size = new System.Drawing.Size(184, 36);
            this.apartAdi.TabIndex = 93;
            this.apartAdi.Text = "ARYA APART";
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.ForeColor = System.Drawing.Color.White;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(182, 44);
            this.toolStripButton7.Text = "Oda ve Daire Kayıt";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // YeniKayıt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.apartAdi);
            this.Controls.Add(this.secilenyatak);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panel21);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "YeniKayıt";
            this.Text = "YeniKayıt";
            this.Load += new System.EventHandler(this.YeniKayıt_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label kayitBilgi;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTelNo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RichTextBox txtAdres;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox sinif;
        private System.Windows.Forms.TextBox txtBolum;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtBabaTelNo;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtAnneTelNo;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtBabaAdi;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RichTextBox txtAileAdres;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DateTimePicker bitisTarih;
        private System.Windows.Forms.DateTimePicker baslangicTarih;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtAylikUcret;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.RichTextBox txtOzelDurum;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker txtDogumTarihi;
        private System.Windows.Forms.TextBox txtIban;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtDepozito;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtTc;
        private System.Windows.Forms.TextBox txtSoyad;
        private System.Windows.Forms.TextBox txtOkul;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAnneAdi;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem yazOkuluKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtBabaMeslek;
        private System.Windows.Forms.TextBox txtAnneMeslek;
        private System.Windows.Forms.TextBox txtDogumYeri;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ToolStripMenuItem çalışanKaydıToolStripMenuItem;
        private System.Windows.Forms.TextBox txtTelNo2;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtUyruk;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button secilenyatak;
        private System.Windows.Forms.Label apartAdi;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
    }
}