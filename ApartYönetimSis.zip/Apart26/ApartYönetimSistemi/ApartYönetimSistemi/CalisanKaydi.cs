﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class CalisanKaydi : Form
    {
        public CalisanKaydi()
        {
            InitializeComponent();
        }
        public int  calısmaId;
        private void CalisanKaydi_Load(object sender, EventArgs e)
        {
            getapart();
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
       
        }
        public string apartid { get; set; }
        public void getapart()

        {

            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Apartlar where ID  = '" + apartid + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    apartAdi.Text = dr4[1] as string;

                }
                dr4.NextResult();
                dr4.Close();

            }
        }



        //public void getapart()

        //{

        //    SqlConnection cnn = database.getConnection();
        //    cnn.Open();

        //    using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Apartlar where ID  = '" + Int32.Parse(apartid) + "' ", cnn))
        //    {

        //        SqlDataReader dr4 = cmd4.ExecuteReader();

        //        while (dr4.Read())
        //        {
        //            apartAdi.Text = dr4[1] as string;

        //        }
        //        dr4.NextResult();
        //        dr4.Close();

        //    }

        //}
        public void calisanKayit()
        {
            try
            {
                long tel = long.Parse(txtTel.Text);
                long tc = long.Parse(txtTc.Text);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Calisanlar(Adi,Soyadi,Telefon,Adres,DogumYeri,DogumTarihi,TCNo,Gorevi,BaslangicTarihi,CalismaID)VALUES (@Adi,@Soyadi,@Telefon,@Adres,@DogumYeri,@DogumTarihi,@TCNo,@Gorevi,@BaslangicTarihi,@CalismaID) ", cnn);
                cmd.Parameters.Add(new SqlParameter("@Adi", txtAd.Text));
                cmd.Parameters.Add(new SqlParameter("@Soyadi", txtSoyad.Text));
                cmd.Parameters.Add(new SqlParameter("@Telefon", tel));
                cmd.Parameters.Add(new SqlParameter("@Adres", txtAdres.Text));
                cmd.Parameters.Add(new SqlParameter("@DogumYeri", txtDogumYeri.Text));
                cmd.Parameters.Add(new SqlParameter("@DogumTarihi", dogumTarihi.Value));
                cmd.Parameters.Add(new SqlParameter("@TCNo", tc));
                cmd.Parameters.Add(new SqlParameter("@Gorevi", txtGorev.Text));
                cmd.Parameters.Add(new SqlParameter("@BaslangicTarihi", baslangicTarihi.Value));
                cmd.Parameters.Add(new SqlParameter("@CalismaID", calısmaId));


                cmd.ExecuteNonQuery();

                cnn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }
        public void calismasekli()
        {
            try
            {

                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO CalismaSaatleri(BaslangicSaati,BitisSaati,SaatlikUcret,IzinGunleri)VALUES (@BaslangicSaati,@BitisSaati,@SaatlikUcret,@IzinGünleri) ", cnn);
                cmd.Parameters.Add(new SqlParameter("@BaslangicSaati", txtGirisSaat.Text));
                cmd.Parameters.Add(new SqlParameter("@BitisSaati", txtCıkısSaat.Text));
                cmd.Parameters.Add(new SqlParameter("@SaatlikUcret", Convert.ToInt32(txtMaas.Text)));
                cmd.Parameters.Add(new SqlParameter("@IzinGünleri", txtİzinGünü.Text));


                cmd.ExecuteNonQuery();
                SqlCommand cmd2 = new SqlCommand("SELECT top 1 * FROM CalismaSaatleri order by ID desc  ", cnn);
                calısmaId = (int)cmd2.ExecuteScalar();

                cnn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                calismasekli();
                calisanKayit();
                MessageBox.Show("Ekleme Başarılı:)");

            }
            catch { MessageBox.Show("Ekleme Başarısız."); }
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.apartid = apartid;
            this.Hide();
            kisiarama.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.id = apartid;
            this.Hide();
            anasayfa.Show();
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {

            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.apartid = apartid;
            this.Hide();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.apartid = apartid;
            this.Hide();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.apartid = apartid;
            this.Hide();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.apartid = apartid;
            this.Hide();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.apartid = apartid;
            this.Hide();
            camasirmakinesi.Show();
        }


        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.apartid = apartid;
            this.Hide();
            calisanlistesi.Show();
        }

        private void normalKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            OdaEkleme odaekleme = new OdaEkleme();
            odaekleme.apartid = apartid;
            this.Hide();
            odaekleme.Show();
        }
    }
}
