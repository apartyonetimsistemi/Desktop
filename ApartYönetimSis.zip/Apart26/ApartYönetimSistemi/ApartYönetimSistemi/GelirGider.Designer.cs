﻿namespace ApartYönetimSistemi
{
    partial class GelirGider
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GelirGider));
            this.panel22 = new System.Windows.Forms.Panel();
            this.label95 = new System.Windows.Forms.Label();
            this.yıl = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.ay = new System.Windows.Forms.ComboBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.yazOkuluKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çalışanKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.topGelir = new System.Windows.Forms.Button();
            this.topCam = new System.Windows.Forms.Button();
            this.topKira = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.lblDigerGid = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblMaasGid = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblIntGid = new System.Windows.Forms.Label();
            this.lblGazGid = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblSuGid = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblElektrikGid = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblTopGid = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.lblCiro = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblKar = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblZarar = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.lbldaireadi = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lblt = new System.Windows.Forms.Label();
            this.lblm = new System.Windows.Forms.Label();
            this.lbldi = new System.Windows.Forms.Label();
            this.lbld = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.lbls = new System.Windows.Forms.Label();
            this.lble = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblkdv = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lblsto = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.lblba = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lblssk = new System.Windows.Forms.Label();
            this.apartAdi = new System.Windows.Forms.Label();
            this.panel22.SuspendLayout();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel22.Controls.Add(this.label95);
            this.panel22.Controls.Add(this.yıl);
            this.panel22.Location = new System.Drawing.Point(427, 79);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(219, 37);
            this.panel22.TabIndex = 32;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label95.ForeColor = System.Drawing.Color.White;
            this.label95.Location = new System.Drawing.Point(9, 11);
            this.label95.Margin = new System.Windows.Forms.Padding(0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(51, 15);
            this.label95.TabIndex = 19;
            this.label95.Text = "Yıl Seç";
            // 
            // yıl
            // 
            this.yıl.FormattingEnabled = true;
            this.yıl.Items.AddRange(new object[] {
            "2018",
            "2019",
            "2020",
            "2021",
            "2022",
            "2023",
            "2024"});
            this.yıl.Location = new System.Drawing.Point(71, 8);
            this.yıl.Margin = new System.Windows.Forms.Padding(0);
            this.yıl.Name = "yıl";
            this.yıl.Size = new System.Drawing.Size(132, 21);
            this.yıl.TabIndex = 22;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.ay);
            this.panel1.Location = new System.Drawing.Point(721, 79);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(219, 37);
            this.panel1.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkOrchid;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(9, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 15);
            this.label1.TabIndex = 19;
            this.label1.Text = "Ay Seç";
            // 
            // ay
            // 
            this.ay.FormattingEnabled = true;
            this.ay.Items.AddRange(new object[] {
            "Ocak",
            "Şubat",
            "Mart",
            "Nisan",
            "Mayıs",
            "Haziran",
            "Temmuz",
            "Ağustos",
            "Eylül",
            "Ekim",
            "Kasım",
            "Aralık"});
            this.ay.Location = new System.Drawing.Point(71, 8);
            this.ay.Margin = new System.Windows.Forms.Padding(0);
            this.ay.Name = "ay";
            this.ay.Size = new System.Drawing.Size(132, 21);
            this.ay.TabIndex = 22;
            this.ay.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.BlueViolet;
            this.toolStrip1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton5,
            this.toolStripSplitButton1,
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton6,
            this.toolStripButton7});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1366, 47);
            this.toolStrip1.TabIndex = 34;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.ForeColor = System.Drawing.Color.White;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(123, 44);
            this.toolStripButton5.Text = "Ana Sayfa";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yazOkuluKaydıToolStripMenuItem,
            this.normalKayıtToolStripMenuItem,
            this.çalışanKaydıToolStripMenuItem});
            this.toolStripSplitButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(133, 44);
            this.toolStripSplitButton1.Text = "Yeni Kayıt";
            this.toolStripSplitButton1.ButtonClick += new System.EventHandler(this.toolStripSplitButton1_ButtonClick);
            // 
            // yazOkuluKaydıToolStripMenuItem
            // 
            this.yazOkuluKaydıToolStripMenuItem.Name = "yazOkuluKaydıToolStripMenuItem";
            this.yazOkuluKaydıToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.yazOkuluKaydıToolStripMenuItem.Text = "Yaz Okulu Kaydı";
            this.yazOkuluKaydıToolStripMenuItem.Click += new System.EventHandler(this.yazOkuluKaydıToolStripMenuItem_Click);
            // 
            // normalKayıtToolStripMenuItem
            // 
            this.normalKayıtToolStripMenuItem.Name = "normalKayıtToolStripMenuItem";
            this.normalKayıtToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.normalKayıtToolStripMenuItem.Text = "Normal Kayıt";
            // 
            // çalışanKaydıToolStripMenuItem
            // 
            this.çalışanKaydıToolStripMenuItem.Name = "çalışanKaydıToolStripMenuItem";
            this.çalışanKaydıToolStripMenuItem.Size = new System.Drawing.Size(191, 26);
            this.çalışanKaydıToolStripMenuItem.Text = "Çalışan Kaydı";
            this.çalışanKaydıToolStripMenuItem.Click += new System.EventHandler(this.çalışanKaydıToolStripMenuItem_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.ForeColor = System.Drawing.Color.White;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(131, 44);
            this.toolStripButton2.Text = "Kayıt Silme";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(122, 44);
            this.toolStripButton1.Text = "Çalışanlar";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.ForeColor = System.Drawing.Color.White;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(131, 44);
            this.toolStripButton3.Text = "Gelir-Gider";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.ForeColor = System.Drawing.Color.White;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(177, 44);
            this.toolStripButton4.Text = "Çamaşır Makinesi";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.ForeColor = System.Drawing.Color.White;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(128, 44);
            this.toolStripButton6.Text = "Kişi Arama";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.ForeColor = System.Drawing.Color.White;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(182, 44);
            this.toolStripButton7.Text = "Oda ve Daire Kayıt";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel2.Controls.Add(this.topGelir);
            this.panel2.Controls.Add(this.topCam);
            this.panel2.Controls.Add(this.topKira);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(22, 164);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(417, 154);
            this.panel2.TabIndex = 38;
            // 
            // topGelir
            // 
            this.topGelir.BackColor = System.Drawing.Color.Plum;
            this.topGelir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.topGelir.ForeColor = System.Drawing.Color.White;
            this.topGelir.Location = new System.Drawing.Point(239, 106);
            this.topGelir.Name = "topGelir";
            this.topGelir.Size = new System.Drawing.Size(82, 26);
            this.topGelir.TabIndex = 44;
            this.topGelir.UseVisualStyleBackColor = false;
            this.topGelir.Click += new System.EventHandler(this.topGelir_Click);
            // 
            // topCam
            // 
            this.topCam.BackColor = System.Drawing.Color.Plum;
            this.topCam.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.topCam.ForeColor = System.Drawing.Color.White;
            this.topCam.Location = new System.Drawing.Point(239, 70);
            this.topCam.Name = "topCam";
            this.topCam.Size = new System.Drawing.Size(82, 26);
            this.topCam.TabIndex = 43;
            this.topCam.UseVisualStyleBackColor = false;
            this.topCam.Click += new System.EventHandler(this.topCam_Click);
            // 
            // topKira
            // 
            this.topKira.BackColor = System.Drawing.Color.Plum;
            this.topKira.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.topKira.ForeColor = System.Drawing.Color.White;
            this.topKira.Location = new System.Drawing.Point(239, 27);
            this.topKira.Name = "topKira";
            this.topKira.Size = new System.Drawing.Size(82, 26);
            this.topKira.TabIndex = 42;
            this.topKira.UseVisualStyleBackColor = false;
            this.topKira.Click += new System.EventHandler(this.topKira_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(30, 114);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "Toplam Gelir";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(30, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 18);
            this.label5.TabIndex = 3;
            this.label5.Text = "Toplam Çamaşırhane";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(30, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 18);
            this.label3.TabIndex = 1;
            this.label3.Text = "Toplam Kira";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.lblDigerGid);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.lblMaasGid);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.lblIntGid);
            this.panel3.Controls.Add(this.lblGazGid);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.lblSuGid);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.lblElektrikGid);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel3.Location = new System.Drawing.Point(482, 164);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(417, 273);
            this.panel3.TabIndex = 39;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(31, 190);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(160, 18);
            this.label13.TabIndex = 15;
            this.label13.Text = "Çalışan Maaş Gideri";
            // 
            // lblDigerGid
            // 
            this.lblDigerGid.AutoSize = true;
            this.lblDigerGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDigerGid.ForeColor = System.Drawing.Color.White;
            this.lblDigerGid.Location = new System.Drawing.Point(247, 228);
            this.lblDigerGid.Name = "lblDigerGid";
            this.lblDigerGid.Size = new System.Drawing.Size(17, 18);
            this.lblDigerGid.TabIndex = 12;
            this.lblDigerGid.Text = "0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(32, 228);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(113, 18);
            this.label17.TabIndex = 11;
            this.label17.Text = "Diğer Giderler";
            // 
            // lblMaasGid
            // 
            this.lblMaasGid.AutoSize = true;
            this.lblMaasGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMaasGid.ForeColor = System.Drawing.Color.White;
            this.lblMaasGid.Location = new System.Drawing.Point(248, 190);
            this.lblMaasGid.Name = "lblMaasGid";
            this.lblMaasGid.Size = new System.Drawing.Size(17, 18);
            this.lblMaasGid.TabIndex = 10;
            this.lblMaasGid.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(30, 152);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(64, 18);
            this.label19.TabIndex = 9;
            this.label19.Text = "İnternet";
            // 
            // lblIntGid
            // 
            this.lblIntGid.AutoSize = true;
            this.lblIntGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblIntGid.ForeColor = System.Drawing.Color.White;
            this.lblIntGid.Location = new System.Drawing.Point(248, 152);
            this.lblIntGid.Name = "lblIntGid";
            this.lblIntGid.Size = new System.Drawing.Size(17, 18);
            this.lblIntGid.TabIndex = 8;
            this.lblIntGid.Text = "0";
            // 
            // lblGazGid
            // 
            this.lblGazGid.AutoSize = true;
            this.lblGazGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGazGid.ForeColor = System.Drawing.Color.White;
            this.lblGazGid.Location = new System.Drawing.Point(248, 114);
            this.lblGazGid.Name = "lblGazGid";
            this.lblGazGid.Size = new System.Drawing.Size(17, 18);
            this.lblGazGid.TabIndex = 6;
            this.lblGazGid.Text = "0";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(30, 114);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(88, 18);
            this.label15.TabIndex = 5;
            this.label15.Text = "Doğal Gaz";
            // 
            // lblSuGid
            // 
            this.lblSuGid.AutoSize = true;
            this.lblSuGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSuGid.ForeColor = System.Drawing.Color.White;
            this.lblSuGid.Location = new System.Drawing.Point(248, 76);
            this.lblSuGid.Name = "lblSuGid";
            this.lblSuGid.Size = new System.Drawing.Size(17, 18);
            this.lblSuGid.TabIndex = 4;
            this.lblSuGid.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(31, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 18);
            this.label8.TabIndex = 3;
            this.label8.Text = "Su";
            // 
            // lblElektrikGid
            // 
            this.lblElektrikGid.AutoSize = true;
            this.lblElektrikGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblElektrikGid.ForeColor = System.Drawing.Color.White;
            this.lblElektrikGid.Location = new System.Drawing.Point(248, 38);
            this.lblElektrikGid.Name = "lblElektrikGid";
            this.lblElektrikGid.Size = new System.Drawing.Size(17, 18);
            this.lblElektrikGid.TabIndex = 2;
            this.lblElektrikGid.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(30, 38);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 18);
            this.label10.TabIndex = 1;
            this.label10.Text = "Elektrik";
            // 
            // lblTopGid
            // 
            this.lblTopGid.AutoSize = true;
            this.lblTopGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTopGid.ForeColor = System.Drawing.Color.White;
            this.lblTopGid.Location = new System.Drawing.Point(246, 31);
            this.lblTopGid.Name = "lblTopGid";
            this.lblTopGid.Size = new System.Drawing.Size(24, 25);
            this.lblTopGid.TabIndex = 14;
            this.lblTopGid.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(24, 31);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(131, 22);
            this.label21.TabIndex = 13;
            this.label21.Text = "Toplam Gider";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(40, 38);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(45, 18);
            this.label35.TabIndex = 1;
            this.label35.Text = "Ciro ";
            // 
            // lblCiro
            // 
            this.lblCiro.AutoSize = true;
            this.lblCiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCiro.ForeColor = System.Drawing.Color.White;
            this.lblCiro.Location = new System.Drawing.Point(270, 38);
            this.lblCiro.Name = "lblCiro";
            this.lblCiro.Size = new System.Drawing.Size(17, 18);
            this.lblCiro.TabIndex = 2;
            this.lblCiro.Text = "0";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel4.Controls.Add(this.lblKar);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.lblZarar);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.lblCiro);
            this.panel4.Controls.Add(this.label35);
            this.panel4.Location = new System.Drawing.Point(922, 164);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(417, 327);
            this.panel4.TabIndex = 40;
            // 
            // lblKar
            // 
            this.lblKar.AutoSize = true;
            this.lblKar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKar.ForeColor = System.Drawing.Color.White;
            this.lblKar.Location = new System.Drawing.Point(270, 78);
            this.lblKar.Name = "lblKar";
            this.lblKar.Size = new System.Drawing.Size(17, 18);
            this.lblKar.TabIndex = 6;
            this.lblKar.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(40, 78);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 18);
            this.label12.TabIndex = 5;
            this.label12.Text = "Kar";
            // 
            // lblZarar
            // 
            this.lblZarar.AutoSize = true;
            this.lblZarar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblZarar.ForeColor = System.Drawing.Color.White;
            this.lblZarar.Location = new System.Drawing.Point(270, 114);
            this.lblZarar.Name = "lblZarar";
            this.lblZarar.Size = new System.Drawing.Size(17, 18);
            this.lblZarar.TabIndex = 4;
            this.lblZarar.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(40, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 18);
            this.label7.TabIndex = 3;
            this.label7.Text = "Zarar";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.BlueViolet;
            this.panel5.Controls.Add(this.label22);
            this.panel5.Controls.Add(this.lbldaireadi);
            this.panel5.Location = new System.Drawing.Point(22, 130);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(417, 28);
            this.panel5.TabIndex = 80;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(152, 4);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(99, 20);
            this.label22.TabIndex = 29;
            this.label22.Text = "GELİRLER";
            // 
            // lbldaireadi
            // 
            this.lbldaireadi.AutoSize = true;
            this.lbldaireadi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbldaireadi.ForeColor = System.Drawing.Color.White;
            this.lbldaireadi.Location = new System.Drawing.Point(29, 6);
            this.lbldaireadi.Name = "lbldaireadi";
            this.lbldaireadi.Size = new System.Drawing.Size(0, 20);
            this.lbldaireadi.TabIndex = 28;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.BlueViolet;
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Location = new System.Drawing.Point(482, 130);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(417, 28);
            this.panel6.TabIndex = 81;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(152, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 20);
            this.label2.TabIndex = 29;
            this.label2.Text = "GİDERLER";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(29, 6);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 20);
            this.label11.TabIndex = 28;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.BlueViolet;
            this.panel7.Controls.Add(this.label23);
            this.panel7.Controls.Add(this.label24);
            this.panel7.Location = new System.Drawing.Point(922, 130);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(417, 28);
            this.panel7.TabIndex = 82;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(152, 4);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(112, 20);
            this.label23.TabIndex = 29;
            this.label23.Text = "KAR-ZARAR";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(29, 6);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(0, 20);
            this.label24.TabIndex = 28;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel8.Controls.Add(this.lblTopGid);
            this.panel8.Controls.Add(this.label21);
            this.panel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel8.Location = new System.Drawing.Point(482, 469);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(417, 69);
            this.panel8.TabIndex = 40;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(34, 119);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 18);
            this.label16.TabIndex = 18;
            this.label16.Text = "KDV";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(33, 81);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(56, 18);
            this.label20.TabIndex = 16;
            this.label20.Text = "Stopaj";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(34, 52);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(61, 18);
            this.label27.TabIndex = 18;
            this.label27.Text = "Bağkur";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(33, 14);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 18);
            this.label26.TabIndex = 16;
            this.label26.Text = "SSK";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DarkOrchid;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(30, 79);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(166, 37);
            this.button4.TabIndex = 49;
            this.button4.Text = "Genel Gider Ekle";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.BlueViolet;
            this.panel9.Controls.Add(this.label4);
            this.panel9.Controls.Add(this.label14);
            this.panel9.Location = new System.Drawing.Point(22, 333);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(417, 28);
            this.panel9.TabIndex = 82;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(115, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 20);
            this.label4.TabIndex = 29;
            this.label4.Text = "GENEL GİDERLER";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(29, 6);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 20);
            this.label14.TabIndex = 28;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.DarkOrchid;
            this.panel10.Controls.Add(this.lblt);
            this.panel10.Controls.Add(this.lblm);
            this.panel10.Controls.Add(this.lbldi);
            this.panel10.Controls.Add(this.lbld);
            this.panel10.Controls.Add(this.label37);
            this.panel10.Controls.Add(this.label39);
            this.panel10.Controls.Add(this.lbls);
            this.panel10.Controls.Add(this.lble);
            this.panel10.Controls.Add(this.label18);
            this.panel10.Controls.Add(this.lblkdv);
            this.panel10.Controls.Add(this.label25);
            this.panel10.Controls.Add(this.lblsto);
            this.panel10.Controls.Add(this.label28);
            this.panel10.Controls.Add(this.lblba);
            this.panel10.Controls.Add(this.label29);
            this.panel10.Controls.Add(this.lblssk);
            this.panel10.Controls.Add(this.label26);
            this.panel10.Controls.Add(this.label20);
            this.panel10.Controls.Add(this.label27);
            this.panel10.Controls.Add(this.label16);
            this.panel10.Location = new System.Drawing.Point(22, 367);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(417, 370);
            this.panel10.TabIndex = 81;
            // 
            // lblt
            // 
            this.lblt.AutoSize = true;
            this.lblt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblt.ForeColor = System.Drawing.Color.White;
            this.lblt.Location = new System.Drawing.Point(287, 336);
            this.lblt.Name = "lblt";
            this.lblt.Size = new System.Drawing.Size(17, 18);
            this.lblt.TabIndex = 27;
            this.lblt.Text = "0";
            // 
            // lblm
            // 
            this.lblm.AutoSize = true;
            this.lblm.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblm.ForeColor = System.Drawing.Color.White;
            this.lblm.Location = new System.Drawing.Point(287, 301);
            this.lblm.Name = "lblm";
            this.lblm.Size = new System.Drawing.Size(17, 18);
            this.lblm.TabIndex = 26;
            this.lblm.Text = "0";
            // 
            // lbldi
            // 
            this.lbldi.AutoSize = true;
            this.lbldi.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbldi.ForeColor = System.Drawing.Color.White;
            this.lbldi.Location = new System.Drawing.Point(287, 264);
            this.lbldi.Name = "lbldi";
            this.lbldi.Size = new System.Drawing.Size(17, 18);
            this.lbldi.TabIndex = 25;
            this.lbldi.Text = "0";
            // 
            // lbld
            // 
            this.lbld.AutoSize = true;
            this.lbld.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbld.ForeColor = System.Drawing.Color.White;
            this.lbld.Location = new System.Drawing.Point(287, 229);
            this.lbld.Name = "lbld";
            this.lbld.Size = new System.Drawing.Size(17, 18);
            this.lbld.TabIndex = 24;
            this.lbld.Text = "0";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(33, 336);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(36, 18);
            this.label37.TabIndex = 23;
            this.label37.Text = "Tüp";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(33, 301);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(60, 18);
            this.label39.TabIndex = 22;
            this.label39.Text = "Market";
            // 
            // lbls
            // 
            this.lbls.AutoSize = true;
            this.lbls.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbls.ForeColor = System.Drawing.Color.White;
            this.lbls.Location = new System.Drawing.Point(287, 191);
            this.lbls.Name = "lbls";
            this.lbls.Size = new System.Drawing.Size(17, 18);
            this.lbls.TabIndex = 21;
            this.lbls.Text = "0";
            // 
            // lble
            // 
            this.lble.AutoSize = true;
            this.lble.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lble.ForeColor = System.Drawing.Color.White;
            this.lble.Location = new System.Drawing.Point(287, 153);
            this.lble.Name = "lble";
            this.lble.Size = new System.Drawing.Size(17, 18);
            this.lble.TabIndex = 20;
            this.lble.Text = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(30, 264);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(113, 18);
            this.label18.TabIndex = 19;
            this.label18.Text = "Diğer Giderler";
            // 
            // lblkdv
            // 
            this.lblkdv.AutoSize = true;
            this.lblkdv.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblkdv.ForeColor = System.Drawing.Color.White;
            this.lblkdv.Location = new System.Drawing.Point(287, 119);
            this.lblkdv.Name = "lblkdv";
            this.lblkdv.Size = new System.Drawing.Size(17, 18);
            this.lblkdv.TabIndex = 19;
            this.lblkdv.Text = "0";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(30, 229);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(88, 18);
            this.label25.TabIndex = 18;
            this.label25.Text = "Doğal Gaz";
            // 
            // lblsto
            // 
            this.lblsto.AutoSize = true;
            this.lblsto.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblsto.ForeColor = System.Drawing.Color.White;
            this.lblsto.Location = new System.Drawing.Point(287, 81);
            this.lblsto.Name = "lblsto";
            this.lblsto.Size = new System.Drawing.Size(17, 18);
            this.lblsto.TabIndex = 18;
            this.lblsto.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(31, 191);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(28, 18);
            this.label28.TabIndex = 17;
            this.label28.Text = "Su";
            // 
            // lblba
            // 
            this.lblba.AutoSize = true;
            this.lblba.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblba.ForeColor = System.Drawing.Color.White;
            this.lblba.Location = new System.Drawing.Point(287, 52);
            this.lblba.Name = "lblba";
            this.lblba.Size = new System.Drawing.Size(17, 18);
            this.lblba.TabIndex = 17;
            this.lblba.Text = "0";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(30, 153);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(65, 18);
            this.label29.TabIndex = 16;
            this.label29.Text = "Elektrik";
            // 
            // lblssk
            // 
            this.lblssk.AutoSize = true;
            this.lblssk.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblssk.ForeColor = System.Drawing.Color.White;
            this.lblssk.Location = new System.Drawing.Point(287, 14);
            this.lblssk.Name = "lblssk";
            this.lblssk.Size = new System.Drawing.Size(17, 18);
            this.lblssk.TabIndex = 16;
            this.lblssk.Text = "0";
            // 
            // apartAdi
            // 
            this.apartAdi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.apartAdi.AutoSize = true;
            this.apartAdi.BackColor = System.Drawing.Color.BlueViolet;
            this.apartAdi.Font = new System.Drawing.Font("Monotype Corsiva", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.apartAdi.ForeColor = System.Drawing.Color.White;
            this.apartAdi.Location = new System.Drawing.Point(1182, 0);
            this.apartAdi.Margin = new System.Windows.Forms.Padding(20);
            this.apartAdi.Name = "apartAdi";
            this.apartAdi.Size = new System.Drawing.Size(184, 36);
            this.apartAdi.TabIndex = 93;
            this.apartAdi.Text = "ARYA APART";
            // 
            // GelirGider
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1366, 749);
            this.Controls.Add(this.apartAdi);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel22);
            this.Name = "GelirGider";
            this.Text = "0";
            this.Load += new System.EventHandler(this.GelirGider_Load);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.ComboBox yıl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox ay;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem yazOkuluKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripMenuItem çalışanKaydıToolStripMenuItem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblSuGid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblElektrikGid;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblDigerGid;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblMaasGid;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblIntGid;
        private System.Windows.Forms.Label lblGazGid;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblTopGid;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label lblCiro;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lbldaireadi;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button topGelir;
        private System.Windows.Forms.Button topCam;
        private System.Windows.Forms.Button topKira;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.Label lblKar;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblZarar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lblt;
        private System.Windows.Forms.Label lblm;
        private System.Windows.Forms.Label lbldi;
        private System.Windows.Forms.Label lbld;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label lbls;
        private System.Windows.Forms.Label lble;
        private System.Windows.Forms.Label lblkdv;
        private System.Windows.Forms.Label lblsto;
        private System.Windows.Forms.Label lblba;
        private System.Windows.Forms.Label lblssk;
        private System.Windows.Forms.Label apartAdi;
    }
}