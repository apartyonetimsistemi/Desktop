﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class OdaEkleme : Form
    {
        public OdaEkleme()
        {
            InitializeComponent();
        }

        private void OdaEkleme_Load(object sender, EventArgs e)
        {
            getapart();
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
            DisplayData();
        }
        public string apartid { get; set; }
        public void getapart()

        {

            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Apartlar where ID  = '" + apartid + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    apartAdi.Text += dr4[1] as string;

                }
                dr4.NextResult();
                dr4.Close();

            }
        }
        public void DisplayData()
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlDataAdapter adpt = new SqlDataAdapter("select * from odaEklemeView", cnn);
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch { MessageBox.Show("Hata display data"); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            birbir();
            DisplayData();

        }
        public void birbir()
        {
            try
            {
                string aprt = apart.SelectedItem.ToString();
                int a = Int32.Parse(aprt);
                int daireNuma = Int32.Parse(daireNum.Text);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd1 = new SqlCommand("INSERT INTO Daire(DaireNum,ApartID) VALUES (@DaireNum,@ApartID) ", cnn);
                cmd1.Parameters.Add(new SqlParameter("@DaireNum", daireNuma));
                cmd1.Parameters.Add(new SqlParameter("@ApartID", a));
                cmd1.ExecuteNonQuery();

                SqlCommand cmddaireid = new SqlCommand("SELECT top 1 * FROM Daire order by ID desc  ", cnn);
                int daireid = (int)cmddaireid.ExecuteScalar();

                for (int i = 0; i < 2; i++)
                {
                    SqlCommand cmd2 = new SqlCommand("INSERT INTO Oda(DaireID) VALUES (@DaireID) ", cnn);
                    cmd2.Parameters.Add(new SqlParameter("@DaireID", daireid));
                    cmd2.ExecuteNonQuery();
                    SqlCommand cmdodaid = new SqlCommand("SELECT top 1 * FROM Oda order by ID desc  ", cnn);
                    int odaid = (int)cmdodaid.ExecuteScalar();
                    MessageBox.Show(odaid.ToString());

                    SqlCommand cmd3 = new SqlCommand("INSERT INTO Yatak(OdaID) VALUES (@OdaID) ", cnn);
                    cmd3.Parameters.Add(new SqlParameter("@OdaID", odaid));
                    cmd3.ExecuteNonQuery();
                }





                cnn.Close();



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string aprt = apart.SelectedItem.ToString();
                int a = Int32.Parse(aprt);
                int daireNuma = Int32.Parse(daireNum.Text);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd1 = new SqlCommand("INSERT INTO Daire(DaireNum,ApartID) VALUES (@DaireNum,@ApartID) ", cnn);
                cmd1.Parameters.Add(new SqlParameter("@DaireNum", daireNuma));
                cmd1.Parameters.Add(new SqlParameter("@ApartID", a));
                cmd1.ExecuteNonQuery();

                SqlCommand cmddaireid = new SqlCommand("SELECT top 1 * FROM Daire order by ID desc  ", cnn);
                int daireid = (int)cmddaireid.ExecuteScalar();
                SqlCommand cmd2 = new SqlCommand("INSERT INTO Oda(DaireID) VALUES (@DaireID) ", cnn);
                cmd2.Parameters.Add(new SqlParameter("@DaireID", daireid));
                cmd2.ExecuteNonQuery();
                SqlCommand cmdodaid = new SqlCommand("SELECT top 1 * FROM Oda order by ID desc  ", cnn);
                int odaid = (int)cmdodaid.ExecuteScalar();
                for (int i = 0; i < 2; i++)
                {
                    SqlCommand cmd3 = new SqlCommand("INSERT INTO Yatak(OdaID) VALUES (@OdaID) ", cnn);
                    cmd3.Parameters.Add(new SqlParameter("@OdaID", odaid));
                    cmd3.ExecuteNonQuery();
                }
                SqlCommand cmd4 = new SqlCommand("INSERT INTO Oda(DaireID) VALUES (@DaireID) ", cnn);
                cmd4.Parameters.Add(new SqlParameter("@DaireID", daireid));
                cmd4.ExecuteNonQuery();
                SqlCommand cmdodaid1 = new SqlCommand("SELECT top 1 * FROM Oda order by ID desc  ", cnn);
                int odaidsi = (int)cmdodaid1.ExecuteScalar();
                SqlCommand cmd5 = new SqlCommand("INSERT INTO Yatak(OdaID) VALUES (@OdaID) ", cnn);
                cmd5.Parameters.Add(new SqlParameter("@OdaID", odaidsi));
                cmd5.ExecuteNonQuery();




                cnn.Close();
                DisplayData();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string aprt = apart.SelectedItem.ToString();
                int a = Int32.Parse(aprt);
                int daireNuma = Int32.Parse(daireNum.Text);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd1 = new SqlCommand("INSERT INTO Daire(DaireNum,ApartID) VALUES (@DaireNum,@ApartID) ", cnn);
                cmd1.Parameters.Add(new SqlParameter("@DaireNum", daireNuma));
                cmd1.Parameters.Add(new SqlParameter("@ApartID", a));
                cmd1.ExecuteNonQuery();

                SqlCommand cmddaireid = new SqlCommand("SELECT top 1 * FROM Daire order by ID desc  ", cnn);
                int daireid = (int)cmddaireid.ExecuteScalar();

                for (int i = 0; i < 2; i++)
                {
                    SqlCommand cmd2 = new SqlCommand("INSERT INTO Oda(DaireID) VALUES (@DaireID) ", cnn);
                    cmd2.Parameters.Add(new SqlParameter("@DaireID", daireid));
                    cmd2.ExecuteNonQuery();
                    SqlCommand cmdodaid = new SqlCommand("SELECT top 1 * FROM Oda order by ID desc  ", cnn);
                    int odaid = (int)cmdodaid.ExecuteScalar();
                    MessageBox.Show(odaid.ToString());


                    for (int j = 0; j < 2; j++)
                    {
                        SqlCommand cmd3 = new SqlCommand("INSERT INTO Yatak(OdaID) VALUES (@OdaID) ", cnn);
                        cmd3.Parameters.Add(new SqlParameter("@OdaID", odaid));
                        cmd3.ExecuteNonQuery();
                    }
                }



                DisplayData();

                cnn.Close();



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string aprt = apart.SelectedItem.ToString();
                int a = Int32.Parse(aprt);
                int daireNuma = Int32.Parse(daireNum.Text);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd1 = new SqlCommand("INSERT INTO Daire(DaireNum,ApartID) VALUES (@DaireNum,@ApartID) ", cnn);
                cmd1.Parameters.Add(new SqlParameter("@DaireNum", daireNuma));
                cmd1.Parameters.Add(new SqlParameter("@ApartID", a));
                cmd1.ExecuteNonQuery();

                SqlCommand cmddaireid = new SqlCommand("SELECT top 1 * FROM Daire order by ID desc  ", cnn);
                int daireid = (int)cmddaireid.ExecuteScalar();
                SqlCommand cmd2 = new SqlCommand("INSERT INTO Oda(DaireID) VALUES (@DaireID) ", cnn);
                cmd2.Parameters.Add(new SqlParameter("@DaireID", daireid));
                cmd2.ExecuteNonQuery();
                SqlCommand cmdodaid = new SqlCommand("SELECT top 1 * FROM Oda order by ID desc  ", cnn);
                int odaid = (int)cmdodaid.ExecuteScalar();
                MessageBox.Show(odaid.ToString());

                for (int i = 0; i < 2; i++)
                {


                    SqlCommand cmd3 = new SqlCommand("INSERT INTO Yatak(OdaID) VALUES (@OdaID) ", cnn);
                    cmd3.Parameters.Add(new SqlParameter("@OdaID", odaid));
                    cmd3.ExecuteNonQuery();
                }





                cnn.Close();
                DisplayData();

            }       
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
}
        public void daire26()
        {
            try
            {
                string aprt = apart.SelectedItem.ToString();
                int a = Int32.Parse(aprt);
                int daireNuma = Int32.Parse(daireNum.Text);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd1 = new SqlCommand("INSERT INTO Daire(DaireNum,ApartID) VALUES (@DaireNum,@ApartID) ", cnn);
                cmd1.Parameters.Add(new SqlParameter("@DaireNum", daireNuma));
                cmd1.Parameters.Add(new SqlParameter("@ApartID", a));
                cmd1.ExecuteNonQuery();

                SqlCommand cmddaireid = new SqlCommand("SELECT top 1 * FROM Daire order by ID desc  ", cnn);
                int daireid = (int)cmddaireid.ExecuteScalar();
               
               

                for (int i = 0; i < 4; i++)
                {
                    SqlCommand cmd2 = new SqlCommand("INSERT INTO Oda(DaireID) VALUES (@DaireID) ", cnn);
                    cmd2.Parameters.Add(new SqlParameter("@DaireID", daireid));
                    cmd2.ExecuteNonQuery();
                    SqlCommand cmdodaid = new SqlCommand("SELECT top 1 * FROM Oda order by ID desc  ", cnn);
                    int odaid = (int)cmdodaid.ExecuteScalar();
                    MessageBox.Show(odaid.ToString());

                    SqlCommand cmd3 = new SqlCommand("INSERT INTO Yatak(OdaID) VALUES (@OdaID) ", cnn);
                    cmd3.Parameters.Add(new SqlParameter("@OdaID", odaid));
                    cmd3.ExecuteNonQuery();
                }

                SqlCommand cmd4 = new SqlCommand("INSERT INTO Oda(DaireID) VALUES (@DaireID) ", cnn);
                cmd4.Parameters.Add(new SqlParameter("@DaireID", daireid));
                cmd4.ExecuteNonQuery();
                SqlCommand cmdodaid12 = new SqlCommand("SELECT top 1 * FROM Oda order by ID desc  ", cnn);
                int odaid12 = (int)cmdodaid12.ExecuteScalar();
                MessageBox.Show(odaid12.ToString());
                for (int k = 0; k < 2; k++) {
                    SqlCommand cmd6 = new SqlCommand("INSERT INTO Yatak(OdaID) VALUES (@OdaID) ", cnn);
                    cmd6.Parameters.Add(new SqlParameter("@OdaID", odaid12));
                    cmd6.ExecuteNonQuery();
                }





                cnn.Close();
                DisplayData();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }



        public void daire30()
        {
            try
            {
                string aprt = apart.SelectedItem.ToString();
                int a = Int32.Parse(aprt);
                int daireNuma = Int32.Parse(daireNum.Text);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd1 = new SqlCommand("INSERT INTO Daire(DaireNum,ApartID) VALUES (@DaireNum,@ApartID) ", cnn);
                cmd1.Parameters.Add(new SqlParameter("@DaireNum", daireNuma));
                cmd1.Parameters.Add(new SqlParameter("@ApartID", a));
                cmd1.ExecuteNonQuery();

                SqlCommand cmddaireid = new SqlCommand("SELECT top 1 * FROM Daire order by ID desc  ", cnn);
                int daireid = (int)cmddaireid.ExecuteScalar();



                for (int i = 0; i < 3; i++)
                {
                    SqlCommand cmd2 = new SqlCommand("INSERT INTO Oda(DaireID) VALUES (@DaireID) ", cnn);
                    cmd2.Parameters.Add(new SqlParameter("@DaireID", daireid));
                    cmd2.ExecuteNonQuery();
                    SqlCommand cmdodaid = new SqlCommand("SELECT top 1 * FROM Oda order by ID desc  ", cnn);
                    int odaid = (int)cmdodaid.ExecuteScalar();
                    MessageBox.Show(odaid.ToString());

                    SqlCommand cmd3 = new SqlCommand("INSERT INTO Yatak(OdaID) VALUES (@OdaID) ", cnn);
                    cmd3.Parameters.Add(new SqlParameter("@OdaID", odaid));
                    cmd3.ExecuteNonQuery();
                }
                for (int b = 0; b < 2; b++) {
                    SqlCommand cmd4 = new SqlCommand("INSERT INTO Oda(DaireID) VALUES (@DaireID) ", cnn);
                    cmd4.Parameters.Add(new SqlParameter("@DaireID", daireid));
                    cmd4.ExecuteNonQuery();
                    SqlCommand cmdodaid12 = new SqlCommand("SELECT top 1 * FROM Oda order by ID desc  ", cnn);
                    int odaid12 = (int)cmdodaid12.ExecuteScalar();
                    MessageBox.Show(odaid12.ToString());
                    for (int k = 0; k < 2; k++)
                    {
                        SqlCommand cmd6 = new SqlCommand("INSERT INTO Yatak(OdaID) VALUES (@OdaID) ", cnn);
                        cmd6.Parameters.Add(new SqlParameter("@OdaID", odaid12));
                        cmd6.ExecuteNonQuery();
                    }


                }


                cnn.Close();
                DisplayData();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }



        public void daire31()
        {
            try
            {
                string aprt = apart.SelectedItem.ToString();
                int a = Int32.Parse(aprt);
                int daireNuma = Int32.Parse(daireNum.Text);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd1 = new SqlCommand("INSERT INTO Daire(DaireNum,ApartID) VALUES (@DaireNum,@ApartID) ", cnn);
                cmd1.Parameters.Add(new SqlParameter("@DaireNum", daireNuma));
                cmd1.Parameters.Add(new SqlParameter("@ApartID", a));
                cmd1.ExecuteNonQuery();

                SqlCommand cmddaireid = new SqlCommand("SELECT top 1 * FROM Daire order by ID desc  ", cnn);
                int daireid = (int)cmddaireid.ExecuteScalar();



                for (int i = 0; i < 3; i++)
                {
                    for (int b = 0; b < 2; b++)
                    {
                        SqlCommand cmd4 = new SqlCommand("INSERT INTO Oda(DaireID) VALUES (@DaireID) ", cnn);
                        cmd4.Parameters.Add(new SqlParameter("@DaireID", daireid));
                        cmd4.ExecuteNonQuery();
                        SqlCommand cmdodaid12 = new SqlCommand("SELECT top 1 * FROM Oda order by ID desc  ", cnn);
                        int odaid12 = (int)cmdodaid12.ExecuteScalar();
                        MessageBox.Show(odaid12.ToString());
                        for (int k = 0; k < 2; k++)
                        {
                            SqlCommand cmd6 = new SqlCommand("INSERT INTO Yatak(OdaID) VALUES (@OdaID) ", cnn);
                            cmd6.Parameters.Add(new SqlParameter("@OdaID", odaid12));
                            cmd6.ExecuteNonQuery();
                        }


                    }
                }
                


                cnn.Close();
                DisplayData();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }



        public void daire32()
        {
            try
            {
                string aprt = apart.SelectedItem.ToString();
                int a = Int32.Parse(aprt);
                int daireNuma = Int32.Parse(daireNum.Text);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd1 = new SqlCommand("INSERT INTO Daire(DaireNum,ApartID) VALUES (@DaireNum,@ApartID) ", cnn);
                cmd1.Parameters.Add(new SqlParameter("@DaireNum", daireNuma));
                cmd1.Parameters.Add(new SqlParameter("@ApartID", a));
                cmd1.ExecuteNonQuery();

                SqlCommand cmddaireid = new SqlCommand("SELECT top 1 * FROM Daire order by ID desc  ", cnn);
                int daireid = (int)cmddaireid.ExecuteScalar();



                for (int i = 0; i < 3; i++)
                {
                    SqlCommand cmd2 = new SqlCommand("INSERT INTO Oda(DaireID) VALUES (@DaireID) ", cnn);
                    cmd2.Parameters.Add(new SqlParameter("@DaireID", daireid));
                    cmd2.ExecuteNonQuery();
                    SqlCommand cmdodaid = new SqlCommand("SELECT top 1 * FROM Oda order by ID desc  ", cnn);
                    int odaid = (int)cmdodaid.ExecuteScalar();
                    MessageBox.Show(odaid.ToString());

                    SqlCommand cmd3 = new SqlCommand("INSERT INTO Yatak(OdaID) VALUES (@OdaID) ", cnn);
                    cmd3.Parameters.Add(new SqlParameter("@OdaID", odaid));
                    cmd3.ExecuteNonQuery();
                }
               
                    SqlCommand cmd4 = new SqlCommand("INSERT INTO Oda(DaireID) VALUES (@DaireID) ", cnn);
                    cmd4.Parameters.Add(new SqlParameter("@DaireID", daireid));
                    cmd4.ExecuteNonQuery();
                    SqlCommand cmdodaid12 = new SqlCommand("SELECT top 1 * FROM Oda order by ID desc  ", cnn);
                    int odaid12 = (int)cmdodaid12.ExecuteScalar();
                    MessageBox.Show(odaid12.ToString());
                    for (int k = 0; k < 2; k++)
                    {
                        SqlCommand cmd6 = new SqlCommand("INSERT INTO Yatak(OdaID) VALUES (@OdaID) ", cnn);
                        cmd6.Parameters.Add(new SqlParameter("@OdaID", odaid12));
                        cmd6.ExecuteNonQuery();
                    }



                cnn.Close();
                DisplayData();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            daire26();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            daire30();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            daire31();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            daire32();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            OdaEkleme odaekleme = new OdaEkleme();
            odaekleme.apartid = apartid;
            this.Hide();
            odaekleme.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
