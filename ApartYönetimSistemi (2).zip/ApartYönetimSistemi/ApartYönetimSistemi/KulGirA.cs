﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class KulGirA : Form
    {
        public KulGirA()
        {
            InitializeComponent();
        }
        public string apartid { get; set; }
        string sifre, kulladi;
        
        
        private void KullaniciGirisi_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
            getapart();
        }
        public void getapart()

        {

            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Apartlar where ID  = '" + apartid + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    LBL.Text += dr4[1] as string;
                    sifre = dr4[3] as string;
                    kulladi = dr4[2] as string;
                    MessageBox.Show(sifre+kulladi);
                }
                dr4.NextResult();
                dr4.Close();

            }
        }

        private void txtSifre_TextChanged(object sender, EventArgs e)
        {
            txtSifre.PasswordChar = '*';
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int kullaniciid = Int32.Parse(apartid);

            if(txtSifre.Text == sifre && txtTcNo.Text == kulladi)
            {
                MessageBox.Show("Giriş Başarılı");
                AnaSayfa arya = new AnaSayfa();
                string kullanici = kullaniciid.ToString();
                arya.id = kullanici;
                this.Hide();
                arya.Show();
            }
            else
            {
                MessageBox.Show("Kullanıcı Adı veya Şifre Hatalı!!");
            }



            

        }

     
    }
}
