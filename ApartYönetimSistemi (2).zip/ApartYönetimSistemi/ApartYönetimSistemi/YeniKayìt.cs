﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ApartYönetimSistemi.data;
namespace ApartYönetimSistemi
{
    public partial class YeniKayıt : Form
    {
        public YeniKayıt()
        {
            InitializeComponent();
        }
        public string yatakidsi { get; set; }
        public string kayitbilgisi { get; set; }
        public int aileid;
        public int okulid;
        public int yilID;
        public int KisiID;
        string[] aylar = new string[] {"Aylar", "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık" };
        
       
        string[] words;
        string[] words1;
        int baslangicay ,baslangicyil;
        int bitisay, bitisyil;
        int i, k, j;
        public void yatakkayit()
        {
            try
            {
                int id = Convert.ToInt32(yatakidsi);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd = new SqlCommand("UPDATE Yatak SET KisiID = '" + KisiID + "' , Durumu=1 WHERE ID = '" + id + "' ", cnn);
                cmd.ExecuteNonQuery();
            }
                
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
}
        public void  ailekayit()
        {
            try
            {
                long annetel = long.Parse(txtAnneTelNo.Text);
                long babatel = long.Parse(txtBabaTelNo.Text);

                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO AileBilgileri(AnneAdi,AnneMeslek,AnneTel,BabaAdi,BabaMeslek,BabaTel,Adres) VALUES (@AnneAdi,@AnneMeslek,@AnneTel,@BabaAdi,@BabaMeslek,@BabaTel,@Adres) ", cnn);
                cmd.Parameters.Add(new SqlParameter("@AnneAdi", txtAnneAdi.Text));
                cmd.Parameters.Add(new SqlParameter("@AnneMeslek", txtAnneMeslek.Text));
                cmd.Parameters.Add(new SqlParameter("@AnneTel", annetel));
                cmd.Parameters.Add(new SqlParameter("@BabaAdi", txtBabaAdi.Text));
                cmd.Parameters.Add(new SqlParameter("@BabaMeslek", txtBabaMeslek.Text));
                cmd.Parameters.Add(new SqlParameter("@BabaTel", babatel));
                cmd.Parameters.Add(new SqlParameter("@Adres", txtAileAdres.Text));
                cmd.ExecuteNonQuery();

                SqlCommand cmdaileid = new SqlCommand("SELECT top 1 * FROM AileBilgileri order by ID desc  ", cnn);
                aileid = (int)cmdaileid.ExecuteScalar();
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public void okulkayit()
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd1 = new SqlCommand("INSERT INTO OkulBilgileri(Okul,Bölüm,Sınıf) VALUES (@Okul,@Bölüm,@Sınıf) ", cnn);
                cmd1.Parameters.Add(new SqlParameter("@Okul", txtOkul.Text));
                cmd1.Parameters.Add(new SqlParameter("@Bölüm", txtBolum.Text));
                cmd1.Parameters.Add(new SqlParameter("@Sınıf", sinif.SelectedItem.ToString()));

                cmd1.ExecuteNonQuery();

                SqlCommand cmdokulid = new SqlCommand("SELECT top 1 * FROM OkulBilgileri order by ID desc  ", cnn);
                okulid = (int)cmdokulid.ExecuteScalar();
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }


        }
        public void aylikUcret()
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                if (baslangicyil != bitisyil)
                {
                    SqlCommand cmd2 = new SqlCommand("INSERT INTO AyKira(YilID,Kira,Ay,KisiID,Miktar) VALUES (@YilID,@Kira,@Ay,@KisiID,@Miktar) ", cnn);
                    for (i = baslangicay; i < 13; i++)
                    {
                        cmd2.Parameters.Clear();
                        cmd2.Parameters.Add(new SqlParameter("@YilID", baslangicyil));
                        cmd2.Parameters.Add(new SqlParameter("@Kira", Convert.ToInt32(txtAylikUcret.Text)));
                        cmd2.Parameters.Add(new SqlParameter("@Ay", aylar[i]));
                        cmd2.Parameters.Add(new SqlParameter("@KisiID", KisiID));
                        cmd2.Parameters.Add(new SqlParameter("@Miktar",0));
                        cmd2.ExecuteNonQuery();
                    }
                    SqlCommand cmd3 = new SqlCommand("INSERT INTO AyKira(YilID,Kira,Ay,KisiID,Miktar) VALUES (@YilID1,@Kira1,@Ay1,@KisiID1,@Miktar1) ", cnn);
                    cmd2.Parameters.Clear();

                    for (j= 1; j< bitisay; j++)
                    {
                        cmd3.Parameters.Clear();

                        cmd3.Parameters.Add(new SqlParameter("@YilID1", bitisyil));
                        cmd3.Parameters.Add(new SqlParameter("@Kira1", Convert.ToInt32(txtAylikUcret.Text)));
                        cmd3.Parameters.Add(new SqlParameter("@Ay1", aylar[j]));
                        cmd3.Parameters.Add(new SqlParameter("@KisiID1", KisiID));
                        cmd3.Parameters.Add(new SqlParameter("@Miktar1",0));
                        cmd3.ExecuteNonQuery();
                    }
                }
                else
                {
                    SqlCommand cmd2 = new SqlCommand("INSERT INTO AyKira(YilID,Kira,Ay,KisiID,Miktar) VALUES (@YilID,@Kira,@Ay,@KisiID,@Miktar) ", cnn);
                    for (k= baslangicay; k <bitisay+1; k++)
                    {
                        cmd2.Parameters.Clear();
                        cmd2.Parameters.Add(new SqlParameter("@YilID", baslangicyil));
                        cmd2.Parameters.Add(new SqlParameter("@Kira", Convert.ToInt32(txtAylikUcret.Text)));
                        cmd2.Parameters.Add(new SqlParameter("@Ay", aylar[k]));
                        cmd2.Parameters.Add(new SqlParameter("@KisiID", KisiID));
                        cmd2.Parameters.Add(new SqlParameter("@Miktar", 0));
                        cmd2.ExecuteNonQuery();
                    }
                }
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }


        }

        public void ogrenciKayit()
        {
            try
            {
                long tc = long.Parse(txtTc.Text);
                long tel = long.Parse(txtTelNo.Text);
                string k = kayitbilgisi;
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO OgrenciBilgileri(Adi,Soyadi,TcNum,TelNo,TelNo2,DogumYeri,DogumTarih,Uyruk,Adres,GirisTarih,CikisTairh,AylıkUcret,Depozito,AileID,OkulID,KayitBilg,OzelDurum,IBAN,Durum) VALUES (@Adi,@Soyadi,@TcNum,@TelNo,@TelNo2,@DogumYeri,@DogumTarih,@Uyruk,@Adres,@GirisTarih,@CikisTairh,@AylıkUcret,@Depozito,@AileID,@OkulID,@KayitBilg,@OzelDurum,@IBAN,@Durum) ", cnn);
                cmd.Parameters.Add(new SqlParameter("@Adi", txtAd.Text));
                cmd.Parameters.Add(new SqlParameter("@Soyadi", txtSoyad.Text));
                cmd.Parameters.Add(new SqlParameter("@TcNum", tc));
                cmd.Parameters.Add(new SqlParameter("@TelNo", tel));
                cmd.Parameters.Add(new SqlParameter("@TelNo2", tel));
                cmd.Parameters.Add(new SqlParameter("@DogumYeri", txtDogumYeri.Text));
                cmd.Parameters.Add(new SqlParameter("@DogumTarih", txtDogumTarihi.Value));
                cmd.Parameters.Add(new SqlParameter("@Uyruk", "Uyruk"));
                cmd.Parameters.Add(new SqlParameter("@Adres", txtAdres.Text));
                cmd.Parameters.Add(new SqlParameter("@GirisTarih", baslangicTarih.Value));
                cmd.Parameters.Add(new SqlParameter("@CikisTairh", bitisTarih.Value));
                cmd.Parameters.Add(new SqlParameter("@AylıkUcret", Convert.ToInt32(txtAylikUcret.Text)));
                cmd.Parameters.Add(new SqlParameter("@Depozito", Convert.ToInt32(txtDepozito.Text)));
                cmd.Parameters.Add(new SqlParameter("@AileID", aileid));
                cmd.Parameters.Add(new SqlParameter("@OkulID", okulid));
                cmd.Parameters.Add(new SqlParameter("@KayitBilg", "Yaz Okulu"));
                cmd.Parameters.Add(new SqlParameter("@OzelDurum", txtOzelDurum.Text));
                cmd.Parameters.Add(new SqlParameter("@IBAN", txtIban.Text));
                cmd.Parameters.Add(new SqlParameter("@Durum", 1));
                cmd.ExecuteNonQuery();

                SqlCommand cmd2 = new SqlCommand("SELECT top 1 * FROM OgrenciBilgileri order by ID desc  ", cnn);
                KisiID = (int)cmd2.ExecuteScalar();
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }


        }
        /*public void getapart()

        {

            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Apartlar where ID  = '" + apartid + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    apartAdi.Text += dr4[1] as string;

                }
                dr4.NextResult();
                dr4.Close();

            }
        }*/
        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {

                DateTime dt = baslangicTarih.Value;
                DateTime dt1 = bitisTarih.Value;
                string bastarih = dt.ToString();
                string sontarih = dt.ToString();
                words = bastarih.Split('.', ' ');
                words1 = sontarih.Split('.', ' ');
                string baslangic = words[1];
                string baslangic1 = words[2];
                string bitis = words1[1];
                string bitis1 = words1[2];
                baslangicay = Convert.ToInt32(baslangic);
                bitisay = Convert.ToInt32(bitis);
                baslangicyil = Convert.ToInt32(baslangic1);
                bitisyil = Convert.ToInt32(bitis1);
                //MessageBox.Show(baslangicyil.ToString() + bitisyil.ToString());
                ailekayit();
                okulkayit();
                ogrenciKayit();
                aylikUcret();
                yatakkayit();
                MessageBox.Show("Kayıt Başaralı");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }
       

        private void YeniKayıt_Load(object sender, EventArgs e)
        {
            try
            {
                kayitBilgi.Text = kayitbilgisi;
                //MessageBox.Show(kayitbilgisi);
                secilenyatak.Text = "Seçilen Daire" + yatakidsi;
                baslangicTarih.CustomFormat = "dd/MM/yyyy";
                bitisTarih.CustomFormat = "dd/MM/yyyy";
                txtDogumTarihi.CustomFormat = "dd/MM/yyyy";
                this.TopMost = true;
                this.FormBorderStyle = FormBorderStyle.Fixed3D;
                this.WindowState = FormWindowState.Maximized;
                this.Bounds = Screen.PrimaryScreen.Bounds;
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                try
                {
                    if (cnn.State != ConnectionState.Open)
                    {
                        MessageBox.Show("Fail");
                    }
                    else
                    {
                        MessageBox.Show("Success");
                    }
                }
                catch { MessageBox.Show("Bağlantı hatası oluştu"); }
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {

            Odalar odalar = new Odalar();
            this.Hide();
            odalar.Show();

        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.kayitbilgisi = "YazOkulu";
            this.Hide();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            this.Hide();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            this.Hide();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            this.Hide();
            gelirgider.Show();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            this.Hide();
            kisiarama.Show();
        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            this.Hide();
            calisanlistesi.Show();
        }

        private void normalKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.kayitbilgisi = "NormalKayıt";
            yenikayit.Show();
        }

        private void secilenyatak_Click(object sender, EventArgs e)
        {

        }

        private void baslangicTarih_ValueChanged(object sender, EventArgs e)
        {
            try
            {

                DateTime dt = baslangicTarih.Value;
                
                string bastarih = dt.ToString();
               
                words = bastarih.Split('.', ' ');
                
                string baslangic = words[1];
                string baslangic1 = words[2];
             
                baslangicay = Convert.ToInt32(baslangic);
                
                baslangicyil = Convert.ToInt32(baslangic1);
               
                MessageBox.Show(baslangicyil.ToString() + baslangicay.ToString());
              
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void bitisTarih_ValueChanged(object sender, EventArgs e)
        {
            try
            {

                DateTime dt1 = bitisTarih.Value;
               
                string sontarih = dt1.ToString();
               
                words1 = sontarih.Split('.', ' ');
               
                string bitis = words1[1];
                string bitis1 = words1[2];
                
                bitisay = Convert.ToInt32(bitis);
       
                bitisyil = Convert.ToInt32(bitis1);
                MessageBox.Show(bitisay.ToString() + bitisyil.ToString());
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            this.Hide();
            camasirmakinesi.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            this.Hide();
            anasayfa.Show();
        }

    }
}
