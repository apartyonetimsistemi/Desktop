﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace ApartYönetimSistemi.data
{
    class database
    {
        public static SqlConnection getConnection()
        {
            SqlConnection cnn = new SqlConnection("Data Source= CASPERNIRVANA\\SQLEXPRESS;Initial Catalog=ApartYonetimSistemi;User ID=sa;Password=1");
            return cnn;
        }
    }
}
