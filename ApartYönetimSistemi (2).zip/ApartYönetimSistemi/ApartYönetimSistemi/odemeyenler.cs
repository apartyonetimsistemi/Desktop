﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class odemeyenler : Form
    {
        public odemeyenler()
        {
            InitializeComponent();
        }
        string ay, yıl;
        private void odemeyenler_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
            ay = DateTime.Now.Month.ToString();
            string gün = DateTime.Now.Day.ToString();
            yıl= DateTime.Now.Year.ToString();
            label1.Text = gün + " / " + ay + " / " + yıl;
            DisplayData();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            this.Hide();
            anasayfa.Show();
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            this.Hide();
            yenikayit.Show();
        }

        private void normalKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            this.Hide();
            calisanlistesi.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            this.Hide();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            this.Hide();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            this.Hide();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            this.Hide();
            camasirmakinesi.Show();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            this.Hide();
            kisiarama.Show();
        }

        public void DisplayData()
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlDataAdapter adpt = new SqlDataAdapter("select * from odemeyenbul where Ay='"+ay+"' AND YilID='"+Int32.Parse(yıl)+"' AND OdemeTarih IS NULL", cnn);
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch { MessageBox.Show("Hata display data"); }
        }
    }
}
