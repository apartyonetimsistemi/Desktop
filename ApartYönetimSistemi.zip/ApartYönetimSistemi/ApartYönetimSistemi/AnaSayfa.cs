﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ApartYönetimSistemi.data;
using System.Data.Sql;
namespace ApartYönetimSistemi
{
    public partial class AnaSayfa : Form
    {
        internal string kullanici;

        public AnaSayfa()
        {
            InitializeComponent();
        }
        public System.Windows.Forms.Padding Margin { get; set; }
        public System.Drawing.Color LinkColor { get; set; }
        public string id { get; set; }
        
        public string kayitbilg;
        List<int> tumdaireler = new List<int>();
        List<int> tumodalar = new List<int>();
        List<int> tumyataklar = new List<int>();
        List<int> daireNum = new List<int>();
        int deneme;
        public void daireler(int apartid)
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();

                using (SqlCommand cmd4 = new SqlCommand("SELECT DISTINCT ID,DaireNum FROM Daire where ApartID  = '" + apartid + "' ", cnn))
                {

                    SqlDataReader dr4 = cmd4.ExecuteReader();

                    while (dr4.Read())
                    {
                        tumdaireler.Add(dr4.GetInt32(0));
                        daireNum.Add(dr4.GetInt32(1));
                    }
                    dr4.NextResult();
                    dr4.Close();
                }

                for (int i = 0; i < tumdaireler.Count; i++)
                {

                    FlowLayoutPanel pnl = new FlowLayoutPanel();
                    pnl.Name = i.ToString();
                    pnl.Width = 110;
                    pnl.Height = 280;
                    pnl.BackColor = Color.Black;
                    LinkLabel lbl = new LinkLabel(); //dairenumrası
                    lbl.Click += new EventHandler(daireClick);
                    lbl.LinkColor = System.Drawing.Color.White;
                    lbl.Name = tumdaireler[i].ToString();
                    lbl.Width = 110;
                    lbl.Height = 12;
                    lbl.BackColor = Color.MediumOrchid;
                    lbl.Text = daireNum[i].ToString();
                    lbl.Font = new Font("Arial", 8, FontStyle.Bold);
                    flowLayoutPanel1.Controls.Add(pnl);
                    pnl.Controls.Add(lbl);

                    using (SqlCommand cmd5 = new SqlCommand("SELECT DISTINCT ID FROM Oda where DaireID  = '" + tumdaireler[i] + "' ", cnn))
                    {

                        SqlDataReader dr5 = cmd5.ExecuteReader();

                        while (dr5.Read())
                        {
                            tumodalar.Add(dr5.GetInt32(0));
                        }
                        dr5.NextResult();
                        dr5.Close();
                    }
                    for (int j = 0; j < tumodalar.Count; j++)
                    {

                        FlowLayoutPanel pnl2 = new FlowLayoutPanel();
                        pnl2.BackColor = Color.DeepPink;
                        pnl2.Width = 105;
                        pnl2.Height = 40;
                        pnl.Controls.Add(pnl2);


                        using (SqlCommand cmd7 = new SqlCommand("SELECT DISTINCT ID  FROM Yatak where OdaID  = '" + tumodalar[j] + "' ", cnn))
                        {

                            SqlDataReader dr7 = cmd7.ExecuteReader();

                            while (dr7.Read())
                            {
                                tumyataklar.Add(dr7.GetInt32(0));

                            }
                            dr7.NextResult();
                            dr7.Close();
                        }

                        for (int k = 0; k < tumyataklar.Count; k++)
                        {
                            LinkLabel lbl2 = new LinkLabel();
                            lbl2.BackColor = Color.Plum;
                            lbl2.LinkColor = System.Drawing.Color.White;
                            lbl2.Font = new Font("Arial", 10, FontStyle.Bold);
                            lbl2.Margin = new Padding(2, 2, 2, 2);
                            lbl2.Width = 100;
                            lbl2.Height = 15;
                            lbl2.Click += new EventHandler(kisiClick);
                            using (SqlCommand cmd6 = new SqlCommand("SELECT DISTINCT o.Adi,o.Soyadi,o.AylıkUcret,y.KisiID FROM Yatak AS y FULL OUTER JOIN OgrenciBilgileri AS o ON  y.KisiID = o.ID  where OdaID  = '" + tumyataklar[k] + "' and y.Durumu=1", cnn))
                            {

                                SqlDataReader dr6 = cmd6.ExecuteReader();

                                while (dr6.Read())
                                {
                                    lbl2.Text += dr6[0] as string;
                                    lbl2.Text += " " + dr6[1] as string;
                                    lbl2.Text += "  " + dr6[2].ToString();
                                    lbl2.Name = dr6[3].ToString();
                                    deneme = dr6.GetInt32(3);
                                }
                                dr6.NextResult();
                                dr6.Close();
                                pnl2.Controls.Add(lbl2);
                                if (deneme == 0)
                                {
                                    lbl2.BackColor = Color.White;
                                }
                            }
                        }
                        tumyataklar.Clear();

                    }
                    tumodalar.Clear();
                }
                cnn.Close();
            }
            catch(Exception ex) { MessageBox.Show(ex.ToString()); }
        }
        private void daireClick(object sender, EventArgs e)
        {
            LinkLabel lbl = (LinkLabel)sender;
            string daireid = lbl.Name;
            DaireBilgileri dairebilg = new DaireBilgileri();
            dairebilg.apartid = id;
            dairebilg.daireid = daireid;
            this.Hide();
            dairebilg.Show();

        }
        private void kisiClick(object sender, EventArgs e)
        {
            LinkLabel lbl2 = (LinkLabel)sender;
            string kisiid = lbl2.Name;
            KisiBilgileri kisibilg = new KisiBilgileri();
            kisibilg.apartid = id;
            kisibilg.kisiid = kisiid;
            this.Hide();
            kisibilg.Show();
        }

        private void arya_Load(object sender, EventArgs e)
        {
            
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;

            SqlConnection cnn = database.getConnection();
            cnn.Open();
            try
            {
                if (cnn.State != ConnectionState.Open)
                {
                    MessageBox.Show("Fail");
                }
                else 
                {
                    
                }
            }
            catch { MessageBox.Show("Bağlantı hatası oluştu"); }
            cnn.Close();

            daireler(Int32.Parse(id));

        }

        public void getapart()

        {

            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Apartlar where ID  = '" + Int32.Parse(id) + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    apartAdi.Text += dr4[1] as string;
                    
                }
                dr4.NextResult();
                dr4.Close();

            }
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
           

            kayitbilg = "YazOkulu";
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.apartid = id;
            yenikayit.kayitbilgisi = "YazOkulu";
            this.Hide();
            yenikayit.Show();

        }



        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DaireBilgileri dairebilgileri = new DaireBilgileri();
            dairebilgileri.apartid = id;
            dairebilgileri.Show();

        }

        private void normalKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            kayitbilg = "NormalKayıt";
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.kayitbilgisi = "NormalKayıt";
            yenikayit.apartid = id;

            yenikayit.Show();
        }



        private void linkLabel9_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            KisiBilgileri kisibilgileri = new KisiBilgileri();
            kisibilgileri.apartid = id;
            this.Hide();
            kisibilgileri.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.apartid = id;
            this.Hide();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.apartid = id;
            this.Hide();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.apartid = id;
            this.Hide();
            gelirgider.Show();

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.apartid = id;
            this.Hide();
            camasirmakinesi.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.id = id;
            this.Hide();
            anasayfa.Show();
        }

        private void linkLabel11_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            KisiBilgileri kisibilgileri = new KisiBilgileri();
            kisibilgileri.apartid = id;
            this.Hide();
            kisibilgileri.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.apartid = id;
            this.Hide();
            kisiarama.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.apartid = id;
            this.Hide();
            calisanlistesi.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            odemeyenler ode = new odemeyenler();
            ode.apartid = id;
            ode.Show();
            this.Hide();
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
