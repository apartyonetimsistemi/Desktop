﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ApartYönetimSistemi.data;
using System.Data.Sql;
namespace ApartYönetimSistemi
{
    public partial class AnaSayfa : Form
    {
        internal string kullanici;

        public AnaSayfa()
        {
            InitializeComponent();
        }
        public System.Windows.Forms.Padding Margin { get; set; }
        public System.Drawing.Color LinkColor { get; set; }
        public string id { get; set; }
        int apartidtest = 1;
        public string kayitbilg;
        List<int> tumdaireler = new List<int>();
        List<int> tumodalar = new List<int>();
        List<int> tumyataklar = new List<int>();
        int deneme;
        public void daireler(int apartid)
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();

                using (SqlCommand cmd4 = new SqlCommand("SELECT DISTINCT ID FROM Daire where ApartID  = '" + apartid + "' ", cnn))
                {

                    SqlDataReader dr4 = cmd4.ExecuteReader();

                    while (dr4.Read())
                    {
                        tumdaireler.Add(dr4.GetInt32(0));
                    }
                    dr4.NextResult();
                    dr4.Close();
                }

                for (int i = 0; i < tumdaireler.Count; i++)
                {

                    FlowLayoutPanel pnl = new FlowLayoutPanel();
                    pnl.Name = i.ToString();
                    pnl.Width = 180;
                    pnl.Height = 570;
                    pnl.BackColor = Color.Black;
                    pnl.Margin = new Padding(5, 5, 5, 5);
                    LinkLabel lbl = new LinkLabel(); //dairenumrası
                    lbl.Click += new EventHandler(daireClick);
                    lbl.LinkColor = System.Drawing.Color.White;
                    lbl.Name = tumdaireler[i].ToString();
                    lbl.Width = 230;
                    lbl.BackColor = Color.MediumOrchid;
                    lbl.Text = tumdaireler[i].ToString();
                    lbl.Font = new Font("Arial", 20, FontStyle.Bold);
                    flowLayoutPanel1.Controls.Add(pnl);
                    pnl.Controls.Add(lbl);

                    using (SqlCommand cmd5 = new SqlCommand("SELECT DISTINCT ID FROM Oda where DaireID  = '" + tumdaireler[i] + "' ", cnn))
                    {

                        SqlDataReader dr5 = cmd5.ExecuteReader();

                        while (dr5.Read())
                        {
                            tumodalar.Add(dr5.GetInt32(0));
                        }
                        dr5.NextResult();
                        dr5.Close();
                    }
                    for (int j = 0; j < tumodalar.Count; j++)
                    {

                        FlowLayoutPanel pnl2 = new FlowLayoutPanel();
                        pnl2.BackColor = Color.DeepPink;
                        pnl2.Width = 160;
                        pnl2.Margin = new Padding(5, 5, 5, 5);
                        pnl2.Height = 100;
                        pnl.Controls.Add(pnl2);


                        using (SqlCommand cmd7 = new SqlCommand("SELECT DISTINCT ID  FROM Yatak where OdaID  = '" + tumodalar[j] + "' ", cnn))
                        {

                            SqlDataReader dr7 = cmd7.ExecuteReader();

                            while (dr7.Read())
                            {
                                tumyataklar.Add(dr7.GetInt32(0));

                            }
                            dr7.NextResult();
                            dr7.Close();
                        }

                        for (int k = 0; k < tumyataklar.Count; k++)
                        {
                            LinkLabel lbl2 = new LinkLabel();
                            lbl2.BackColor = Color.Plum;
                            lbl2.LinkColor = System.Drawing.Color.White;
                            lbl2.Font = new Font("Arial", 10, FontStyle.Bold);
                            lbl2.Margin = new Padding(5, 5, 5, 5);
                            lbl2.Width = 130;
                            lbl2.Height = 35;
                            lbl2.Click += new EventHandler(kisiClick);
                            using (SqlCommand cmd6 = new SqlCommand("SELECT DISTINCT o.Adi,o.Soyadi,o.AylıkUcret,y.KisiID FROM Yatak AS y FULL OUTER JOIN OgrenciBilgileri AS o ON  y.KisiID = o.ID  where OdaID  = '" + tumyataklar[k] + "' and y.Durumu=1", cnn))
                            {

                                SqlDataReader dr6 = cmd6.ExecuteReader();

                                while (dr6.Read())
                                {
                                    lbl2.Text += dr6[0] as string;
                                    lbl2.Text += " " + dr6[1] as string;
                                    lbl2.Text += "  " + dr6[2].ToString();
                                    lbl2.Name = dr6[3].ToString();
                                    deneme = dr6.GetInt32(3);
                                }
                                dr6.NextResult();
                                dr6.Close();
                                pnl2.Controls.Add(lbl2);
                                if (deneme == 0)
                                {
                                    lbl2.BackColor = Color.White;
                                }
                            }
                        }
                        tumyataklar.Clear();

                    }
                    tumodalar.Clear();
                }
                cnn.Close();
            }
            catch(Exception ex) { MessageBox.Show(ex.ToString()); }
        }
        private void daireClick(object sender, EventArgs e)
        {
            LinkLabel lbl = (LinkLabel)sender;
            string daireid = lbl.Name;
            DaireBilgileri dairebilg = new DaireBilgileri();
            dairebilg.daireid = daireid;
            dairebilg.Show();

        }
        private void kisiClick(object sender, EventArgs e)
        {
            LinkLabel lbl2 = (LinkLabel)sender;
            string kisiid = lbl2.Name;
            KisiBilgileri kisibilg = new KisiBilgileri();
            kisibilg.kisiid = kisiid;
            kisibilg.Show();
        }

        private void arya_Load(object sender, EventArgs e)
        {
            
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;

            SqlConnection cnn = database.getConnection();
            cnn.Open();
            try
            {
                if (cnn.State != ConnectionState.Open)
                {
                    MessageBox.Show("Fail");
                }
                else 
                {
                    
                }
            }
            catch { MessageBox.Show("Bağlantı hatası oluştu"); }
            cnn.Close();

            daireler(apartidtest);

        }


        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            kayitbilg = "YazOkulu";
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.kayitbilgisi = "YazOkulu";
            yenikayit.Show();

        }



        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DaireBilgileri dairebilgileri = new DaireBilgileri();
            dairebilgileri.Show();

        }

        private void normalKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            kayitbilg = "NormalKayıt";
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.kayitbilgisi = "NormalKayıt";

            yenikayit.Show();
        }



        private void linkLabel9_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            KisiBilgileri kisibilgileri = new KisiBilgileri();
            kisibilgileri.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.Show();

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.Show();
        }

        private void linkLabel11_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            KisiBilgileri kisibilgileri = new KisiBilgileri();
            kisibilgileri.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.Show();
        }

    
    }
}
