﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class CalisanKaydi : Form
    {
        public CalisanKaydi()
        {
            InitializeComponent();
        }
        public int  calısmaId;
        private void CalisanKaydi_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
        }
        public void calisanKayit()
        {
            long tel = long.Parse(txtTel.Text);
            long tc = long.Parse(txtTc.Text);
            SqlConnection cnn = database.getConnection();
            cnn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Calisanlar(Adi,Soyadi,Telefon,Adres,DogumYeri,DogumTarihi,TCNo,Gorevi,BaslangicTarihi,CalismaID)VALUES (@Adi,@Soyadi,@Telefon,@Adres,@DogumYeri,@DogumTarihi,@TCNo,@Gorevi,@BaslangicTarihi,@CalismaID) ", cnn);
            cmd.Parameters.Add(new SqlParameter("@Adi", txtAd.Text));
            cmd.Parameters.Add(new SqlParameter("@Soyadi", txtSoyad.Text));
            cmd.Parameters.Add(new SqlParameter("@Telefon",tel ));
            cmd.Parameters.Add(new SqlParameter("@Adres",txtAdres.Text));
            cmd.Parameters.Add(new SqlParameter("@DogumYeri", txtdogumyeri.Text));
            cmd.Parameters.Add(new SqlParameter("@DogumTarihi", dogumtarihi.Value));
            cmd.Parameters.Add(new SqlParameter("@TCNo", tc));
            cmd.Parameters.Add(new SqlParameter("@Gorevi", txtGorev.Text));
            cmd.Parameters.Add(new SqlParameter("@BaslangicTarihi", baslangıctarihi.Value));
            cmd.Parameters.Add(new SqlParameter("@CalismaID", calısmaId));


            cmd.ExecuteNonQuery();

            cnn.Close();
        }
        public void calismasekli()
        {
           
            SqlConnection cnn = database.getConnection();
            cnn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO CalismaSaatleri(BaslangicSaati,BitisSaati,SaatlikUcret,IzinGunleri)VALUES (@BaslangicSaati,@BitisSaati,@SaatlikUcret,@IzinGünleri) ", cnn);
            cmd.Parameters.Add(new SqlParameter("@BaslangicSaati", txtGirisSaat.Text));
            cmd.Parameters.Add(new SqlParameter("@BitisSaati", txtcıkısSaat.Text));
            cmd.Parameters.Add(new SqlParameter("@SaatlikUcret", Convert.ToInt32(txtMaas.Text)));
            cmd.Parameters.Add(new SqlParameter("@IzinGünleri", txtizinGünü.Text));
   

            cmd.ExecuteNonQuery();
            SqlCommand cmd2 = new SqlCommand("SELECT top 1 * FROM CalismaSaatleri order by ID desc  ", cnn);
            calısmaId = (int)cmd2.ExecuteScalar();

            cnn.Close();
        }
        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                calismasekli();
                calisanKayit();
                MessageBox.Show("Ekleme Başarılı:)");

            }
            catch { MessageBox.Show("Ekleme Başarısız."); }
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.Show();
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.Show();
        }

        private void normalKayıtToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.Show();
        }
    }
}
