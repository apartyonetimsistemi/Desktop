﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class Calisanlar : Form
    {
        SqlConnection cnn = database.getConnection();        
        SqlCommand cmd;
        DataTable dt;
        SqlDataAdapter adpt;
        public Calisanlar()
        {
            InitializeComponent();
        }
        public void DisplayData()
        {
            try
            {
                cnn.Open();
                adpt = new SqlDataAdapter("select * from calisanbilgileri", cnn);
                dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch { MessageBox.Show("Hata"); }
        }
        private void Calisanlar_Load(object sender, EventArgs e)
        {

            DisplayData();


            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
        }
       

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.Show();
        }

        private void çalışanlarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisan = new CalisanKaydi();
            calisan.Show();
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.calisanbilgileriTableAdapter3.FillBy(this.apartYonetimSistemiDataSet6.calisanbilgileri);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
        int id ;
     

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                

        }
        private void button3_Click(object sender, EventArgs e)
        {
           // id = Convert.ToInt32(datagri);
            if (id != 0)
            {
                SqlConnection cnn = database.getConnection();
                SqlCommand cmd = new SqlCommand("UPDATE Calisanlar SET Durum=@Durum WHERE ID=@ID ",cnn);
                cnn.Open();
                cmd.Parameters.AddWithValue("@ID",id);
                cmd.Parameters.AddWithValue("@Durum",1);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Silme Başarılı");
                cnn.Close();
                DisplayData();
                id = 0;
            }
            else
            {
                MessageBox.Show("Seçim yapmadınız");
            }
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CalisanListesi calisanlistesi = new CalisanListesi();
            calisanlistesi.Show();
        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.Show();
        }
        public void CalisanAra(string calisanadi)
        {
            try
            {
                cnn.Open();
                string sorgu = "select * from calisanbilgileri where Adi like '%" + calisanadi + "%' or Soyadi like '%" + calisanadi + "%' ";
                adpt = new SqlDataAdapter(sorgu, cnn);
                dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch { MessageBox.Show("Hata"); }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            CalisanAra(ara.Text);
        }
    }
}
