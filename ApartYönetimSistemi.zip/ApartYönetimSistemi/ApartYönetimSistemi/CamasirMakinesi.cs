﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class CamasirMakinesi : Form
    {
        public CamasirMakinesi()
        {
            InitializeComponent();
        }
        public int makID;
        public int KisiID;
        private void CamasirMakinesi_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'apartYonetimSistemiDataSet9.camasirMak' table. You can move, or remove it, as needed.
            this.camasirMakTableAdapter.Fill(this.apartYonetimSistemiDataSet9.camasirMak);
            // TODO: This line of code loads data into the 'apartYonetimSistemiDataSet8.camasirhaneView' table. You can move, or remove it, as needed.
            //this.camasirhaneViewTableAdapter.Fill(this.apartYonetimSistemiDataSet8.camasirhaneView);
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
            try
            {
                DisplayData();
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                String query = "Select * from AdSoyad";
                SqlCommand cmd = new SqlCommand(query, cnn);
                SqlDataAdapter adt = new SqlDataAdapter(query, cnn);
                DataTable dt = new DataTable();
                adt.Fill(dt);
                AdSoyad.DisplayMember = "Name";
                AdSoyad.ValueMember = "Name";
                AdSoyad.DataSource = dt;
                AdSoyad.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                AdSoyad.AutoCompleteSource = AutoCompleteSource.ListItems;
                cnn.Close();
                
                

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        
    }
        public void DisplayData()
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlDataAdapter adpt = new SqlDataAdapter("select * from camasirhaneView", cnn);
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch { MessageBox.Show("Hata display data"); }
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.Show();
        }

      

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.Show();
        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.Show();
        }
        public void getMakineID()
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                int makNum = Int32.Parse(Makine.SelectedValue.ToString());
                SqlCommand cmd = new SqlCommand("Select ID from camasirMak  where CamasırMakinesi =  '" + makNum + "'", cnn);
                makID = (int)cmd.ExecuteScalar();
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public void getKisiID()
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                String Adi =AdSoyad.SelectedItem.ToString();
                SqlCommand cmd = new SqlCommand("Select ID from AdSoyad  where Name =  '" + AdSoyad.SelectedValue + "'", cnn);
                KisiID = (int)cmd.ExecuteScalar();
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void makineKayit()
        {
            try
            {
                getMakineID();
                getKisiID();
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Camasirhane(MakineUcret,MakineID,Tarih,KisiID) VALUES (@MakineUcret,@MakineID,@Tarih,@KisiID) ", cnn);
                cmd.Parameters.Add(new SqlParameter("@MakineUcret", Int32.Parse(txtUcret.Text)));
                cmd.Parameters.Add(new SqlParameter("@Tarih", DateTime.Now));
                cmd.Parameters.Add(new SqlParameter("@MakineID", makID));
                cmd.Parameters.Add(new SqlParameter("@KisiID", KisiID));
                cmd.ExecuteNonQuery();

                
                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            makineKayit();
            DisplayData();
        }
    }
}
