﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApartYönetimSistemi
{
    class Daire
    {
        public int ID { get; set; }
        public int DaireNum { get; set; }
        public int ApartID { get; set; }
    }
}
