﻿namespace ApartYönetimSistemi
{
    partial class DaireBilgileri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DaireBilgileri));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.yazOkuluKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çalışanKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.label38 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtGazGid = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.txtDigerGid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIntGid = new System.Windows.Forms.TextBox();
            this.btnDuzen1 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtSuGid = new System.Windows.Forms.TextBox();
            this.txtElektrikGid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtToplamGid = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dogalgaz = new System.Windows.Forms.TextBox();
            this.txtElektrikKota = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.txtIntKota = new System.Windows.Forms.TextBox();
            this.btnDuzen2 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.txtSuKota = new System.Windows.Forms.TextBox();
            this.txtZimmetli = new System.Windows.Forms.Label();
            this.ElektrikKota = new System.Windows.Forms.TextBox();
            this.txtKotaAsimi = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtAriza = new System.Windows.Forms.TextBox();
            this.txtGazKota = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.aylarKota = new System.Windows.Forms.ComboBox();
            this.txtKotaBel = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtTopGelir = new System.Windows.Forms.TextBox();
            this.lblgelir = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtKiraGel = new System.Windows.Forms.TextBox();
            this.txtMakineGel = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.aylar = new System.Windows.Forms.ComboBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.lbldaireadi = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.apartYonetimSistemiDataSet = new ApartYönetimSistemi.ApartYonetimSistemiDataSet();
            this.apartYonetimSistemiDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.apartYonetimSistemiDataSet7 = new ApartYönetimSistemi.ApartYonetimSistemiDataSet7();
            this.daireGiderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.daireGiderTableAdapter = new ApartYönetimSistemi.ApartYonetimSistemiDataSet7TableAdapters.DaireGiderTableAdapter();
            this.apartYonetimSistemiDataSet1 = new ApartYönetimSistemi.ApartYonetimSistemiDataSet();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.toolStrip1.SuspendLayout();
            this.txtGazGid.SuspendLayout();
            this.txtElektrikKota.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.daireGiderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton5,
            this.toolStripSplitButton1,
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton6});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1370, 47);
            this.toolStrip1.TabIndex = 35;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.ForeColor = System.Drawing.Color.White;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(103, 44);
            this.toolStripButton5.Text = "Ana Sayfa";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yazOkuluKaydıToolStripMenuItem,
            this.normalKayıtToolStripMenuItem,
            this.çalışanKaydıToolStripMenuItem});
            this.toolStripSplitButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(114, 44);
            this.toolStripSplitButton1.Text = "Yeni Kayıt";
            // 
            // yazOkuluKaydıToolStripMenuItem
            // 
            this.yazOkuluKaydıToolStripMenuItem.Name = "yazOkuluKaydıToolStripMenuItem";
            this.yazOkuluKaydıToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.yazOkuluKaydıToolStripMenuItem.Text = "Yaz Okulu Kaydı";
            this.yazOkuluKaydıToolStripMenuItem.Click += new System.EventHandler(this.yazOkuluKaydıToolStripMenuItem_Click);
            // 
            // normalKayıtToolStripMenuItem
            // 
            this.normalKayıtToolStripMenuItem.Name = "normalKayıtToolStripMenuItem";
            this.normalKayıtToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.normalKayıtToolStripMenuItem.Text = "Normal Kayıt";
            // 
            // çalışanKaydıToolStripMenuItem
            // 
            this.çalışanKaydıToolStripMenuItem.Name = "çalışanKaydıToolStripMenuItem";
            this.çalışanKaydıToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.çalışanKaydıToolStripMenuItem.Text = "Çalışan Kaydı";
            this.çalışanKaydıToolStripMenuItem.Click += new System.EventHandler(this.çalışanKaydıToolStripMenuItem_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.ForeColor = System.Drawing.Color.White;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(109, 44);
            this.toolStripButton2.Text = "Kayıt Silme";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(102, 44);
            this.toolStripButton1.Text = "Çalışanlar";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.ForeColor = System.Drawing.Color.White;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(108, 44);
            this.toolStripButton3.Text = "Gelir-Gider";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.ForeColor = System.Drawing.Color.White;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(144, 44);
            this.toolStripButton4.Text = "Çamaşır Makinesi";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.ForeColor = System.Drawing.Color.White;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(107, 44);
            this.toolStripButton6.Text = "Kişi Arama";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // label38
            // 
            this.label38.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Monotype Corsiva", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label38.ForeColor = System.Drawing.Color.SteelBlue;
            this.label38.Location = new System.Drawing.Point(1145, 50);
            this.label38.Margin = new System.Windows.Forms.Padding(20);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(215, 18);
            this.label38.TabIndex = 30;
            this.label38.Text = "Hoşgeldiniz Neslihan Demirtaş";
            // 
            // label40
            // 
            this.label40.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label40.Font = new System.Drawing.Font("Monotype Corsiva", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label40.ForeColor = System.Drawing.Color.SteelBlue;
            this.label40.Location = new System.Drawing.Point(1136, 0);
            this.label40.Margin = new System.Windows.Forms.Padding(20);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(224, 43);
            this.label40.TabIndex = 29;
            this.label40.Text = "ARYA APART";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(-302, 43);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "Soyadı";
            // 
            // txtGazGid
            // 
            this.txtGazGid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtGazGid.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtGazGid.Controls.Add(this.label8);
            this.txtGazGid.Controls.Add(this.txtDigerGid);
            this.txtGazGid.Controls.Add(this.label2);
            this.txtGazGid.Controls.Add(this.txtIntGid);
            this.txtGazGid.Controls.Add(this.btnDuzen1);
            this.txtGazGid.Controls.Add(this.label11);
            this.txtGazGid.Controls.Add(this.txtSuGid);
            this.txtGazGid.Controls.Add(this.txtElektrikGid);
            this.txtGazGid.Controls.Add(this.label1);
            this.txtGazGid.Controls.Add(this.txtToplamGid);
            this.txtGazGid.Controls.Add(this.label3);
            this.txtGazGid.Controls.Add(this.label4);
            this.txtGazGid.Controls.Add(this.dogalgaz);
            this.txtGazGid.Location = new System.Drawing.Point(343, 88);
            this.txtGazGid.Name = "txtGazGid";
            this.txtGazGid.Size = new System.Drawing.Size(291, 287);
            this.txtGazGid.TabIndex = 76;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(18, 164);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 16);
            this.label8.TabIndex = 79;
            this.label8.Text = "Arıza Gideri";
            // 
            // txtDigerGid
            // 
            this.txtDigerGid.Location = new System.Drawing.Point(146, 163);
            this.txtDigerGid.Name = "txtDigerGid";
            this.txtDigerGid.Size = new System.Drawing.Size(118, 20);
            this.txtDigerGid.TabIndex = 80;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(18, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 16);
            this.label2.TabIndex = 77;
            this.label2.Text = "İnternet Gideri";
            // 
            // txtIntGid
            // 
            this.txtIntGid.Location = new System.Drawing.Point(146, 126);
            this.txtIntGid.Name = "txtIntGid";
            this.txtIntGid.Size = new System.Drawing.Size(118, 20);
            this.txtIntGid.TabIndex = 78;
            // 
            // btnDuzen1
            // 
            this.btnDuzen1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDuzen1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnDuzen1.ForeColor = System.Drawing.Color.White;
            this.btnDuzen1.Location = new System.Drawing.Point(182, 244);
            this.btnDuzen1.Name = "btnDuzen1";
            this.btnDuzen1.Size = new System.Drawing.Size(82, 23);
            this.btnDuzen1.TabIndex = 76;
            this.btnDuzen1.Text = "Düzenle";
            this.btnDuzen1.UseVisualStyleBackColor = false;
            this.btnDuzen1.Click += new System.EventHandler(this.btnDuzen1_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(18, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 16);
            this.label11.TabIndex = 8;
            this.label11.Text = "Su Gideri";
            // 
            // txtSuGid
            // 
            this.txtSuGid.Location = new System.Drawing.Point(146, 15);
            this.txtSuGid.Name = "txtSuGid";
            this.txtSuGid.Size = new System.Drawing.Size(118, 20);
            this.txtSuGid.TabIndex = 9;
            // 
            // txtElektrikGid
            // 
            this.txtElektrikGid.Location = new System.Drawing.Point(146, 52);
            this.txtElektrikGid.Name = "txtElektrikGid";
            this.txtElektrikGid.Size = new System.Drawing.Size(118, 20);
            this.txtElektrikGid.TabIndex = 37;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(18, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 16);
            this.label1.TabIndex = 36;
            this.label1.Text = "Elektrik Gideri";
            // 
            // txtToplamGid
            // 
            this.txtToplamGid.Location = new System.Drawing.Point(146, 200);
            this.txtToplamGid.Name = "txtToplamGid";
            this.txtToplamGid.Size = new System.Drawing.Size(118, 20);
            this.txtToplamGid.TabIndex = 71;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(18, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 16);
            this.label3.TabIndex = 38;
            this.label3.Text = "Doğalgaz Gideri";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(18, 201);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 16);
            this.label4.TabIndex = 70;
            this.label4.Text = "Toplam Gider";
            // 
            // dogalgaz
            // 
            this.dogalgaz.Location = new System.Drawing.Point(146, 89);
            this.dogalgaz.Name = "dogalgaz";
            this.dogalgaz.Size = new System.Drawing.Size(118, 20);
            this.dogalgaz.TabIndex = 39;
            // 
            // txtElektrikKota
            // 
            this.txtElektrikKota.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtElektrikKota.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtElektrikKota.Controls.Add(this.label10);
            this.txtElektrikKota.Controls.Add(this.txtIntKota);
            this.txtElektrikKota.Controls.Add(this.btnDuzen2);
            this.txtElektrikKota.Controls.Add(this.label21);
            this.txtElektrikKota.Controls.Add(this.richTextBox1);
            this.txtElektrikKota.Controls.Add(this.txtSuKota);
            this.txtElektrikKota.Controls.Add(this.txtZimmetli);
            this.txtElektrikKota.Controls.Add(this.ElektrikKota);
            this.txtElektrikKota.Controls.Add(this.txtKotaAsimi);
            this.txtElektrikKota.Controls.Add(this.label22);
            this.txtElektrikKota.Controls.Add(this.label5);
            this.txtElektrikKota.Controls.Add(this.label23);
            this.txtElektrikKota.Controls.Add(this.txtAriza);
            this.txtElektrikKota.Controls.Add(this.txtGazKota);
            this.txtElektrikKota.Controls.Add(this.label6);
            this.txtElektrikKota.Location = new System.Drawing.Point(669, 88);
            this.txtElektrikKota.Name = "txtElektrikKota";
            this.txtElektrikKota.Size = new System.Drawing.Size(287, 287);
            this.txtElektrikKota.TabIndex = 77;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(13, 128);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 16);
            this.label10.TabIndex = 87;
            this.label10.Text = "İnternet";
            // 
            // txtIntKota
            // 
            this.txtIntKota.Location = new System.Drawing.Point(141, 127);
            this.txtIntKota.Name = "txtIntKota";
            this.txtIntKota.Size = new System.Drawing.Size(118, 20);
            this.txtIntKota.TabIndex = 88;
            // 
            // btnDuzen2
            // 
            this.btnDuzen2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDuzen2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnDuzen2.ForeColor = System.Drawing.Color.White;
            this.btnDuzen2.Location = new System.Drawing.Point(4, 264);
            this.btnDuzen2.Name = "btnDuzen2";
            this.btnDuzen2.Size = new System.Drawing.Size(84, 23);
            this.btnDuzen2.TabIndex = 76;
            this.btnDuzen2.Text = "Düzenle";
            this.btnDuzen2.UseVisualStyleBackColor = false;
            this.btnDuzen2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(13, 17);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(30, 16);
            this.label21.TabIndex = 81;
            this.label21.Text = "Su ";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(142, 235);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(117, 32);
            this.richTextBox1.TabIndex = 77;
            this.richTextBox1.Text = "";
            // 
            // txtSuKota
            // 
            this.txtSuKota.Location = new System.Drawing.Point(141, 16);
            this.txtSuKota.Name = "txtSuKota";
            this.txtSuKota.Size = new System.Drawing.Size(118, 20);
            this.txtSuKota.TabIndex = 82;
            // 
            // txtZimmetli
            // 
            this.txtZimmetli.AutoSize = true;
            this.txtZimmetli.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtZimmetli.ForeColor = System.Drawing.Color.White;
            this.txtZimmetli.Location = new System.Drawing.Point(13, 236);
            this.txtZimmetli.Name = "txtZimmetli";
            this.txtZimmetli.Size = new System.Drawing.Size(123, 16);
            this.txtZimmetli.TabIndex = 76;
            this.txtZimmetli.Text = "Zimmetli Eşyalar";
            // 
            // ElektrikKota
            // 
            this.ElektrikKota.Location = new System.Drawing.Point(141, 53);
            this.ElektrikKota.Name = "ElektrikKota";
            this.ElektrikKota.Size = new System.Drawing.Size(118, 20);
            this.ElektrikKota.TabIndex = 84;
            // 
            // txtKotaAsimi
            // 
            this.txtKotaAsimi.Location = new System.Drawing.Point(142, 160);
            this.txtKotaAsimi.Name = "txtKotaAsimi";
            this.txtKotaAsimi.Size = new System.Drawing.Size(117, 20);
            this.txtKotaAsimi.TabIndex = 73;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(13, 54);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(60, 16);
            this.label22.TabIndex = 83;
            this.label22.Text = "Elektrik";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(13, 161);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 16);
            this.label5.TabIndex = 72;
            this.label5.Text = "Kota Aşımı";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(13, 91);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(75, 16);
            this.label23.TabIndex = 85;
            this.label23.Text = "Doğalgaz";
            // 
            // txtAriza
            // 
            this.txtAriza.Location = new System.Drawing.Point(142, 194);
            this.txtAriza.Name = "txtAriza";
            this.txtAriza.Size = new System.Drawing.Size(117, 20);
            this.txtAriza.TabIndex = 75;
            // 
            // txtGazKota
            // 
            this.txtGazKota.Location = new System.Drawing.Point(141, 90);
            this.txtGazKota.Name = "txtGazKota";
            this.txtGazKota.Size = new System.Drawing.Size(118, 20);
            this.txtGazKota.TabIndex = 86;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(13, 198);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 16);
            this.label6.TabIndex = 74;
            this.label6.Text = "Arıza Detay";
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.panel1.CausesValidation = false;
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.panel9);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.flowLayoutPanel1);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.aylar);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.txtElektrikKota);
            this.panel1.Controls.Add(this.txtGazGid);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Location = new System.Drawing.Point(21, 109);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1312, 669);
            this.panel1.TabIndex = 30;
            // 
            // panel9
            // 
            this.panel9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel9.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel9.Controls.Add(this.aylarKota);
            this.panel9.Controls.Add(this.txtKotaBel);
            this.panel9.Location = new System.Drawing.Point(669, 52);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(287, 30);
            this.panel9.TabIndex = 89;
            // 
            // aylarKota
            // 
            this.aylarKota.FormattingEnabled = true;
            this.aylarKota.Items.AddRange(new object[] {
            "Ocak",
            "Şubat",
            "Mart",
            "Nisan",
            "Mayıs",
            "Haziran",
            "Temmuz",
            "Ağustos",
            "Eylül",
            "Ekim",
            "Kasım",
            "Aralık"});
            this.aylarKota.Location = new System.Drawing.Point(138, 4);
            this.aylarKota.Name = "aylarKota";
            this.aylarKota.Size = new System.Drawing.Size(121, 21);
            this.aylarKota.TabIndex = 91;
            // 
            // txtKotaBel
            // 
            this.txtKotaBel.AutoSize = true;
            this.txtKotaBel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtKotaBel.ForeColor = System.Drawing.Color.White;
            this.txtKotaBel.Location = new System.Drawing.Point(4, 5);
            this.txtKotaBel.Name = "txtKotaBel";
            this.txtKotaBel.Size = new System.Drawing.Size(109, 16);
            this.txtKotaBel.TabIndex = 79;
            this.txtKotaBel.Text = "Kota Belirleme";
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(811, 399);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(145, 39);
            this.button3.TabIndex = 90;
            this.button3.Text = "Kaydet";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel8.Location = new System.Drawing.Point(979, 13);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(287, 28);
            this.panel8.TabIndex = 81;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(985, 52);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(281, 323);
            this.flowLayoutPanel1.TabIndex = 85;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel7.Controls.Add(this.label14);
            this.panel7.Controls.Add(this.label15);
            this.panel7.Location = new System.Drawing.Point(343, 13);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(291, 28);
            this.panel7.TabIndex = 84;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(80, 4);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(134, 20);
            this.label14.TabIndex = 29;
            this.label14.Text = "DAİRE GİDERİ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(29, 6);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(0, 20);
            this.label15.TabIndex = 28;
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel4.Controls.Add(this.txtTopGelir);
            this.panel4.Controls.Add(this.lblgelir);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.txtKiraGel);
            this.panel4.Controls.Add(this.txtMakineGel);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Location = new System.Drawing.Point(17, 88);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(291, 123);
            this.panel4.TabIndex = 83;
            // 
            // txtTopGelir
            // 
            this.txtTopGelir.Location = new System.Drawing.Point(153, 90);
            this.txtTopGelir.Name = "txtTopGelir";
            this.txtTopGelir.Size = new System.Drawing.Size(100, 20);
            this.txtTopGelir.TabIndex = 78;
            // 
            // lblgelir
            // 
            this.lblgelir.AutoSize = true;
            this.lblgelir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblgelir.ForeColor = System.Drawing.Color.White;
            this.lblgelir.Location = new System.Drawing.Point(18, 90);
            this.lblgelir.Name = "lblgelir";
            this.lblgelir.Size = new System.Drawing.Size(98, 16);
            this.lblgelir.TabIndex = 77;
            this.lblgelir.Text = "Toplam Gelir";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(18, 16);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(133, 16);
            this.label16.TabIndex = 8;
            this.label16.Text = "Toplam Kira Geliri";
            // 
            // txtKiraGel
            // 
            this.txtKiraGel.Location = new System.Drawing.Point(153, 15);
            this.txtKiraGel.Name = "txtKiraGel";
            this.txtKiraGel.Size = new System.Drawing.Size(100, 20);
            this.txtKiraGel.TabIndex = 9;
            // 
            // txtMakineGel
            // 
            this.txtMakineGel.Location = new System.Drawing.Point(153, 52);
            this.txtMakineGel.Name = "txtMakineGel";
            this.txtMakineGel.Size = new System.Drawing.Size(100, 20);
            this.txtMakineGel.TabIndex = 37;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(18, 53);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(131, 16);
            this.label17.TabIndex = 36;
            this.label17.Text = "Çamaşır Makinesi";
            // 
            // aylar
            // 
            this.aylar.FormattingEnabled = true;
            this.aylar.Items.AddRange(new object[] {
            "Ocak",
            "Şubat",
            "Mart",
            "Nisan",
            "Mayıs",
            "Haziran",
            "Temmuz",
            "Ağustos",
            "Eylül",
            "Ekim",
            "Kasım",
            "Aralık"});
            this.aylar.Location = new System.Drawing.Point(343, 52);
            this.aylar.Name = "aylar";
            this.aylar.Size = new System.Drawing.Size(291, 21);
            this.aylar.TabIndex = 82;
            this.aylar.SelectedIndexChanged += new System.EventHandler(this.aylar_SelectedIndexChanged);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel6.Controls.Add(this.label9);
            this.panel6.Location = new System.Drawing.Point(669, 13);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(287, 28);
            this.panel6.TabIndex = 80;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(84, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 20);
            this.label9.TabIndex = 28;
            this.label9.Text = "ARIZA, KOTA";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.lbldaireadi);
            this.panel5.Location = new System.Drawing.Point(17, 13);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(291, 28);
            this.panel5.TabIndex = 79;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(80, 4);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(131, 20);
            this.label13.TabIndex = 29;
            this.label13.Text = "DAİRE GELİRİ";
            // 
            // lbldaireadi
            // 
            this.lbldaireadi.AutoSize = true;
            this.lbldaireadi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbldaireadi.ForeColor = System.Drawing.Color.White;
            this.lbldaireadi.Location = new System.Drawing.Point(29, 6);
            this.lbldaireadi.Name = "lbldaireadi";
            this.lbldaireadi.Size = new System.Drawing.Size(0, 20);
            this.lbldaireadi.TabIndex = 28;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(442, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(194, 25);
            this.label7.TabIndex = 28;
            this.label7.Text = "DAİRE BİLGİLERİ";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(21, 66);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1276, 37);
            this.panel3.TabIndex = 38;
            // 
            // apartYonetimSistemiDataSet
            // 
            this.apartYonetimSistemiDataSet.DataSetName = "ApartYonetimSistemiDataSet";
            this.apartYonetimSistemiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // apartYonetimSistemiDataSetBindingSource
            // 
            this.apartYonetimSistemiDataSetBindingSource.DataSource = this.apartYonetimSistemiDataSet;
            this.apartYonetimSistemiDataSetBindingSource.Position = 0;
            // 
            // apartYonetimSistemiDataSet7
            // 
            this.apartYonetimSistemiDataSet7.DataSetName = "ApartYonetimSistemiDataSet7";
            this.apartYonetimSistemiDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // daireGiderBindingSource
            // 
            this.daireGiderBindingSource.DataMember = "DaireGider";
            this.daireGiderBindingSource.DataSource = this.apartYonetimSistemiDataSet7;
            // 
            // daireGiderTableAdapter
            // 
            this.daireGiderTableAdapter.ClearBeforeFill = true;
            // 
            // apartYonetimSistemiDataSet1
            // 
            this.apartYonetimSistemiDataSet1.DataSetName = "ApartYonetimSistemiDataSet";
            this.apartYonetimSistemiDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(17, 231);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(291, 144);
            this.dataGridView1.TabIndex = 91;
            // 
            // DaireBilgileri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.toolStrip1);
            this.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.Name = "DaireBilgileri";
            this.Text = "daireBilgileri";
            this.Load += new System.EventHandler(this.daireBilgileri_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.txtGazGid.ResumeLayout(false);
            this.txtGazGid.PerformLayout();
            this.txtElektrikKota.ResumeLayout(false);
            this.txtElektrikKota.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.daireGiderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem yazOkuluKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel txtGazGid;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtSuGid;
        private System.Windows.Forms.TextBox txtElektrikGid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtToplamGid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox dogalgaz;
        private System.Windows.Forms.Panel txtElektrikKota;
        private System.Windows.Forms.TextBox txtKotaAsimi;
        private System.Windows.Forms.TextBox txtAriza;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbldaireadi;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox aylar;
        private System.Windows.Forms.Button btnDuzen1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIntGid;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.TextBox txtDigerGid;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnDuzen2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtKiraGel;
        private System.Windows.Forms.TextBox txtMakineGel;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtTopGelir;
        private System.Windows.Forms.Label lblgelir;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label txtZimmetli;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ToolStripMenuItem çalışanKaydıToolStripMenuItem;
        private System.Windows.Forms.BindingSource apartYonetimSistemiDataSetBindingSource;
        private ApartYonetimSistemiDataSet apartYonetimSistemiDataSet;
        private ApartYonetimSistemiDataSet7 apartYonetimSistemiDataSet7;
        private System.Windows.Forms.BindingSource daireGiderBindingSource;
        private ApartYonetimSistemiDataSet7TableAdapters.DaireGiderTableAdapter daireGiderTableAdapter;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtIntKota;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtSuKota;
        private System.Windows.Forms.TextBox ElektrikKota;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtGazKota;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label txtKotaBel;
        private System.Windows.Forms.ComboBox aylarKota;
        private ApartYonetimSistemiDataSet apartYonetimSistemiDataSet1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}