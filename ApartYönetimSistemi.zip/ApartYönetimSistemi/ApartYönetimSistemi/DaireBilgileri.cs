﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class DaireBilgileri : Form
    {
        public DaireBilgileri()
        {
            InitializeComponent();
        }
        public string daireid { get; set; }
        List<int> odalar = new List<int>();
        List<int> Doluodalar = new List<int>();
        List<int> camasirOda = new List<int>();
        List<int> kisiler = new List<int>();
        List<int> kiralar = new List<int>();
        List<string> girilenaylar = new List<string>();
        public int topKira = 0;
        public int topCamasir = 0;
        /*public void getapart()

        {

            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Apartlar where ID  = '" + apartid + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    apartAdi.Text += dr4[1] as string;

                }
                dr4.NextResult();
                dr4.Close();

            }
        }*/
        public void dairebilgileri()
        {
            try
            {
                string ay = aylar.Text;

                SqlConnection cnn = database.getConnection();
                cnn.Open();
                using (SqlCommand cmd2 = new SqlCommand("SELECT DISTINCT ID FROM Oda where DaireID ='" + Convert.ToInt32(daireid) + "'", cnn))
                {

                    SqlDataReader dr2 = cmd2.ExecuteReader();

                    while (dr2.Read())
                    {
                        odalar.Add(dr2.GetInt32(0));
                    }
                    dr2.NextResult();
                    dr2.Close();
                }

                cnn.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }


        }
        //camasirhaneyi kullanan kisilerin odaları
        public void odaCamasir()
        {
            try
            {

                SqlConnection cnn = database.getConnection();
                cnn.Open();
                using (SqlCommand cmd2 = new SqlCommand("SELECT OdaID FROM camasirUcret where DaireID ='" + Convert.ToInt32(daireid) + "'", cnn))
                {

                    SqlDataReader dr2 = cmd2.ExecuteReader();

                    while (dr2.Read())
                    {
                        camasirOda.Add(dr2.GetInt32(0));
                    }
                    dr2.NextResult();
                    dr2.Close();
                }

                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }
        //dolu odalar
        public void doluodalar()
        {

            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                using (SqlCommand cmd2 = new SqlCommand("SELECT OdaID FROM doluYataklar where DaireID ='" + Convert.ToInt32(daireid) + "'", cnn))
                {

                    SqlDataReader dr2 = cmd2.ExecuteReader();

                    while (dr2.Read())
                    {
                        Doluodalar.Add(dr2.GetInt32(0));
                    }
                    dr2.NextResult();
                    dr2.Close();
                }

                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }
        public void giderbilg(string ay)
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                using (SqlCommand cmd2 = new SqlCommand("SELECT * FROM DaireGider where DaireID ='" + Convert.ToInt32(daireid) + "' AND Ay = '" + ay + "'", cnn))
                {

                    SqlDataReader dr2 = cmd2.ExecuteReader();

                    while (dr2.Read())
                    {

                        txtSuGid.Text += dr2[2].ToString();
                        dogalgaz.Text += dr2[0].ToString();
                        txtElektrikGid.Text += dr2[1].ToString();
                        txtIntGid.Text += dr2[4].ToString();
                    }
                    dr2.NextResult();
                    dr2.Close();
                }

                cnn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }       
        public void kiragetir()
        {
            try
            {
                doluodalar();
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                for (int i = 0; i < Doluodalar.Count; i++)
                {


                    using (SqlCommand cmd3 = new SqlCommand("select o.AylıkUcret From Yatak AS y Full outer join OgrenciBilgileri As o ON y.KisiID=o.ID where o.AylıkUcret Is Not null AND y.OdaID = '" + Doluodalar[i] + "'", cnn))
                    {
                        SqlDataReader dr3 = cmd3.ExecuteReader();

                        while (dr3.Read())
                        {
                            String a = dr3[0].ToString();
                            topKira = topKira + Int32.Parse(a);
                        }
                        dr3.NextResult();
                        dr3.Close();
                    }
                }
                txtKiraGel.Text = topKira.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void camasirgetir()
        {
            try
            {
                odaCamasir();
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                for (int i = 0; i < camasirOda.Count; i++)
                {
                    using (SqlCommand cmd3 = new SqlCommand("select MakineUcret From camasirUcret where OdaID = '" + camasirOda[i] + "'", cnn))
                    {
                        SqlDataReader dr3 = cmd3.ExecuteReader();

                        while (dr3.Read())
                        {
                            String a = dr3[0].ToString();
                            topCamasir = topCamasir + Int32.Parse(a);
                        }
                        dr3.NextResult();
                        dr3.Close();
                    }
                }
                txtMakineGel.Text = topCamasir.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void daireBilgileri_Load(object sender, EventArgs e)
        {
                 
            kiragetir();
            camasirgetir();
            DisplayData();
            int topgelir = topKira + topCamasir;
            lblgelir.Text = topgelir.ToString();       
            try
            {              

                this.daireGiderTableAdapter.Fill(this.apartYonetimSistemiDataSet7.DaireGider);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                this.TopMost = true;
                this.FormBorderStyle = FormBorderStyle.Fixed3D;
                this.WindowState = FormWindowState.Maximized;
                this.Bounds = Screen.PrimaryScreen.Bounds;
                lbldaireadi.Text = "Daire " + daireid;
                dairebilgileri();
               
                for (int i = 0; i < odalar.Count; i++)
                {
                    FlowLayoutPanel pnl = new FlowLayoutPanel();
                    pnl.Name = odalar[i].ToString();
                    pnl.BackColor = Color.SlateGray;
                    pnl.Margin = new Padding(5, 5, 5, 5);
                    flowLayoutPanel1.Controls.Add(pnl);
                    pnl.Width = 200;
                    pnl.Height = 50;


                    using (SqlCommand cmd3 = new SqlCommand("SELECT ID FROM Yatak where OdaID ='" + odalar[i] + "'", cnn))
                    {
                        SqlDataReader dr3 = cmd3.ExecuteReader();

                        while (dr3.Read())
                        {
                            kisiler.Add(dr3.GetInt32(0));
                        }
                        dr3.NextResult();
                        dr3.Close();
                    }
                    

                    for (int j = 0; j < kisiler.Count; j++)
                    {
                        LinkLabel lbl2 = new LinkLabel();
                        lbl2.BackColor = Color.Plum;
                        lbl2.LinkColor = System.Drawing.Color.White;
                        lbl2.Margin = new Padding(5, 5, 5, 5);
                        lbl2.Width = 130;
                        lbl2.Height = 15;
                        lbl2.Click += new EventHandler(kisiClick);

                        using (SqlCommand cmd2 = new SqlCommand("SELECT DISTINCT o.Adi,o.Soyadi,o.AylıkUcret FROM Yatak AS y Full Outer Join OgrenciBilgileri AS o ON y.KisiID=o.ID where OdaID ='" + kisiler[j] + "' and y.Durumu=1", cnn))
                        {

                            SqlDataReader dr2 = cmd2.ExecuteReader();

                            while (dr2.Read())
                            {
                                lbl2.Text += dr2[0] as string;
                                lbl2.Text += " " + dr2[1] as string;
                                lbl2.Text += "  " + dr2[2].ToString();
                               
                            }
                            dr2.NextResult();
                            dr2.Close();
                            pnl.Controls.Add(lbl2);
                            if (lbl2.Text == "")
                            {
                                lbl2.BackColor = Color.White;
                            }

                        }
                        

                    }

                    kisiler.Clear();         

                }
                cnn.Close();
            }
            catch(Exception ex) {
              MessageBox.Show(ex.ToString());
            }

        }
        private void kisiClick(object sender, EventArgs e)
        {
            LinkLabel lbl2 = (LinkLabel)sender;
            string kisiid = lbl2.Name;
            KisiBilgileri kisibilg = new KisiBilgileri();
            kisibilg.kisiid = kisiid;
            kisibilg.Show();
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            this.Hide();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            this.Hide();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            this.Hide();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            this.Hide();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            this.Hide();
            camasirmakinesi.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            this.Hide();
            anasayfa.Show();
        }

        private void aylar_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                txtSuGid.Text = "";
                dogalgaz.Text = "";
                txtElektrikGid.Text = "";
                txtIntGid.Text = "";
                txtToplamGid.Text = "";
                txtDigerGid.Text = "";

                string ay = aylar.SelectedItem.ToString();
                giderbilg(ay);

                int suint = Int32.Parse(txtSuGid.Text);
                int dogint = Int32.Parse(dogalgaz.Text);
                int elektint = Int32.Parse(txtElektrikGid.Text);
                int digerint = Int32.Parse(txtIntGid.Text);
                int toplam = suint + elektint + dogint + digerint;
                txtToplamGid.Text = toplam.ToString();
            }
            catch { }
        }
    

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.Show();
        }

        
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                using (SqlCommand cmd4 = new SqlCommand("select Ay From DaireGiderKota where DaireID = '" + daireid + "'", cnn))
                {

                    SqlDataReader dr7 = cmd4.ExecuteReader();

                    while (dr7.Read())
                    {
                        girilenaylar.Add(dr7.GetString(0));
                    }
                    dr7.NextResult();
                    dr7.Close();
                    cnn.Close();

                }
                string ay = aylarKota.SelectedItem.ToString();

                if (girilenaylar.Contains("Ocak"))
                {
                    cnn.Open();
                    MessageBox.Show("ok");
                    SqlCommand cmd3 = new SqlCommand("UPDATE DaireGiderKota SET DogalgazKota = '" + Int32.Parse(txtGazKota.Text) + "' ,ElektrikKota ='" + Int32.Parse(ElektrikKota.Text) + "' , SuKota ='" + Int32.Parse(txtSuKota.Text) + "'  , InternetKota ='" + Int32.Parse(txtIntKota.Text) + "'  , ArızaBilgileri ='" + Int32.Parse(txtAriza.Text) + "' WHERE DaireID = '" + daireid + "' ", cnn);
                    cmd3.ExecuteNonQuery();
                    cnn.Close();
                }
                else
                {
                    cnn.Open();

                    SqlCommand cmd1 = new SqlCommand("INSERT INTO DaireGiderKota(DogalgazKota,ElektrikKota,SuKota,InternetKota,ArızaBilgileri,Ay,DaireID) VALUES (@DogalgazKota,@ElektrikKota,@SuKota,@InternetKota,@ArızaBilgileri,@Ay,@DaireID) ", cnn);
                    cmd1.Parameters.Add(new SqlParameter("@DogalgazKota", Int32.Parse(txtGazKota.Text)));
                    cmd1.Parameters.Add(new SqlParameter("@ElektrikKota", Int32.Parse(ElektrikKota.Text)));
                    cmd1.Parameters.Add(new SqlParameter("@SuKota", Int32.Parse(txtSuKota.Text)));
                    cmd1.Parameters.Add(new SqlParameter("@InternetKota", Int32.Parse(txtIntKota.Text)));
                    cmd1.Parameters.Add(new SqlParameter("@ArızaBilgileri", txtAriza.Text));
                    cmd1.Parameters.Add(new SqlParameter("@Ay", aylarKota.SelectedItem.ToString()));
                    cmd1.Parameters.Add(new SqlParameter("@DaireID", daireid));

                    cmd1.ExecuteNonQuery();
                    cnn.Close();
                }

            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.Show();
        }

       

        private void btnDuzen1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd4 = new SqlCommand("select Ay From DaireGider where DaireID = '" + daireid + "'", cnn);
                
                    
                    SqlDataReader dr7 = cmd4.ExecuteReader();

                    while (dr7.Read())
                    {
                        girilenaylar.Add(dr7.GetString(0));
                    }
                    dr7.NextResult();
                    dr7.Close();
                    cnn.Close();
                   
                
                string ay = aylar.SelectedItem.ToString();
                
                if (girilenaylar.Contains("Ocak"))
                {
                    cnn.Open();
                    MessageBox.Show("ok");
                    SqlCommand cmd3 = new SqlCommand("UPDATE DaireGider SET Dogalgaz = '" + Int32.Parse(dogalgaz.Text) + "' ,Elektrik ='" + Int32.Parse(txtElektrikGid.Text) + "' , Su ='" + Int32.Parse(txtSuGid.Text) + "'  , Internet ='" + Int32.Parse(txtIntGid.Text) + "'  , DigerGiderler ='" + Int32.Parse(txtDigerGid.Text) + "' WHERE DaireID = '" + daireid + "' ", cnn);
                    cmd3.ExecuteNonQuery();
                    cnn.Close();
                }
                else
                {
                    cnn.Open();
                   
                    SqlCommand cmd1 = new SqlCommand("INSERT INTO DaireGider(Dogalgaz,Elektrik,Su,Internet,DigerGiderler,Ay,DaireID) VALUES (@Dogalgaz,@Elektrik,@Su,@Internet,@DigerGiderler,@Ay,@DaireID) ", cnn);
                    cmd1.Parameters.Add(new SqlParameter("@Dogalgaz", Int32.Parse(dogalgaz.Text)));
                    cmd1.Parameters.Add(new SqlParameter("@Elektrik", Int32.Parse(txtElektrikGid.Text)));
                    cmd1.Parameters.Add(new SqlParameter("@Su", Int32.Parse(txtSuGid.Text)));
                    cmd1.Parameters.Add(new SqlParameter("@Internet", Int32.Parse(txtIntGid.Text)));
                    cmd1.Parameters.Add(new SqlParameter("@DigerGiderler", Int32.Parse(txtDigerGid.Text)));
                    cmd1.Parameters.Add(new SqlParameter("@Ay", aylar.SelectedItem.ToString()));
                    cmd1.Parameters.Add(new SqlParameter("@DaireID", daireid));

                    cmd1.ExecuteNonQuery();
                    cnn.Close();
                }
              
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }


        
    }
        public void DisplayData()
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlDataAdapter adpt = new SqlDataAdapter("select * from camasirhaneView where DaireID ='" + Convert.ToInt32(daireid) + "'  ", cnn);
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch { MessageBox.Show("Hata display data"); }
        }

    }
}
