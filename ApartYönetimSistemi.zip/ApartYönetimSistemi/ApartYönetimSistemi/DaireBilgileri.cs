﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class DaireBilgileri : Form
    {
        public DaireBilgileri()
        {
            InitializeComponent();
        }
        public string daireid { get; set; }
        List<int> odalar = new List<int>();
        List<int> kisiler = new List<int>();


        public void dairebilgileri()
        {
            SqlConnection cnn = database.getConnection();
            cnn.Open();
            using (SqlCommand cmd2 = new SqlCommand("SELECT DISTINCT ID FROM Oda where DaireID ='"+Convert.ToInt32(daireid)+"'", cnn))
            {

                SqlDataReader dr2 = cmd2.ExecuteReader();

                while (dr2.Read())
                {
                    odalar.Add(dr2.GetInt32(0));
                }
                dr2.NextResult();
                dr2.Close();
            }

            cnn.Close();

        }

        private void daireBilgileri_Load(object sender, EventArgs e)
        {
            SqlConnection cnn = database.getConnection();
            cnn.Open();
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
            lbldaireadi.Text = "Daire " + daireid;
            dairebilgileri();
            for (int i=0; i < odalar.Count; i++)
            {
                FlowLayoutPanel pnl = new FlowLayoutPanel();
                pnl.Name = odalar[i].ToString();
                pnl.BackColor = Color.SlateGray;
                pnl.Margin = new Padding(5, 5, 5, 5);
                flowLayoutPanel1.Controls.Add(pnl);
                pnl.Width = 200;
                pnl.Height = 50;


                using (SqlCommand cmd3 = new SqlCommand("SELECT ID FROM Yatak where OdaID ='" + odalar[i] + "'", cnn))
                {
                    SqlDataReader dr3 = cmd3.ExecuteReader();

                    while (dr3.Read())
                    {
                        kisiler.Add(dr3.GetInt32(0));
                    }
                    dr3.NextResult();
                    dr3.Close();
                }
               
                for (int j=0;j<kisiler.Count; j++)
                {
                    LinkLabel lbl2 = new LinkLabel();
                    lbl2.BackColor = Color.Plum;
                    lbl2.LinkColor = System.Drawing.Color.White;
                    lbl2.Margin = new Padding(5, 5, 5, 5);
                    lbl2.Width = 130;
                    lbl2.Height = 15;

                    using (SqlCommand cmd2 = new SqlCommand("SELECT DISTINCT o.Adi,o.Soyadi,o.AylıkUcret FROM Yatak AS y Full Outer Join OgrenciBilgileri AS o ON y.KisiID=o.ID where OdaID ='" + kisiler[j] + "'", cnn))
                    {

                        SqlDataReader dr2 = cmd2.ExecuteReader();

                        while (dr2.Read())
                        {
                            lbl2.Text += dr2[0] as string;
                            lbl2.Text += " " + dr2[1] as string;
                            lbl2.Text += "  " + dr2[2].ToString();
                        }
                        dr2.NextResult();
                        dr2.Close();
                        pnl.Controls.Add(lbl2);
                        if (lbl2.Text == "")
                        {
                            lbl2.BackColor = Color.White;
                        }

                    }
                }

                kisiler.Clear();

            }

        }

  

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.Show();
        }

    }
}
