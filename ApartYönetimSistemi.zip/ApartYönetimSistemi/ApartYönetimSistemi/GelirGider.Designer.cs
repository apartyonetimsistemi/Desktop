﻿namespace ApartYönetimSistemi
{
    partial class GelirGider
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GelirGider));
            this.panel22 = new System.Windows.Forms.Panel();
            this.label95 = new System.Windows.Forms.Label();
            this.yıl = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.ay = new System.Windows.Forms.ComboBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.yazOkuluKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çalışanKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.label38 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.topGelir = new System.Windows.Forms.Button();
            this.topCam = new System.Windows.Forms.Button();
            this.topKira = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblKdvGid = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lblStopajGid = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblTopGid = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lblDigerGid = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblMaasGid = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblIntGid = new System.Windows.Forms.Label();
            this.lblGazGid = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblSuGid = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblElektrikGid = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.lblCiro = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.lbldaireadi = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel22.SuspendLayout();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel22.Controls.Add(this.label95);
            this.panel22.Controls.Add(this.yıl);
            this.panel22.Location = new System.Drawing.Point(427, 79);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(219, 37);
            this.panel22.TabIndex = 32;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label95.ForeColor = System.Drawing.Color.White;
            this.label95.Location = new System.Drawing.Point(9, 11);
            this.label95.Margin = new System.Windows.Forms.Padding(0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(51, 15);
            this.label95.TabIndex = 19;
            this.label95.Text = "Yıl Seç";
            // 
            // yıl
            // 
            this.yıl.FormattingEnabled = true;
            this.yıl.Items.AddRange(new object[] {
            "2018",
            "2019",
            "2020",
            "2021",
            "2022",
            "2023",
            "2024"});
            this.yıl.Location = new System.Drawing.Point(71, 8);
            this.yıl.Margin = new System.Windows.Forms.Padding(0);
            this.yıl.Name = "yıl";
            this.yıl.Size = new System.Drawing.Size(132, 21);
            this.yıl.TabIndex = 22;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.ay);
            this.panel1.Location = new System.Drawing.Point(721, 79);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(219, 37);
            this.panel1.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(9, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 15);
            this.label1.TabIndex = 19;
            this.label1.Text = "Ay Seç";
            // 
            // ay
            // 
            this.ay.FormattingEnabled = true;
            this.ay.Items.AddRange(new object[] {
            "Ocak",
            "Şubat",
            "Mart",
            "Nisan",
            "Mayıs",
            "Haziran",
            "Temmuz",
            "Ağustos",
            "Eylül",
            "Ekim",
            "Kasım",
            "Aralık"});
            this.ay.Location = new System.Drawing.Point(71, 8);
            this.ay.Margin = new System.Windows.Forms.Padding(0);
            this.ay.Name = "ay";
            this.ay.Size = new System.Drawing.Size(132, 21);
            this.ay.TabIndex = 22;
            this.ay.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton5,
            this.toolStripSplitButton1,
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton6,
            this.toolStripButton7});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1366, 47);
            this.toolStrip1.TabIndex = 34;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.ForeColor = System.Drawing.Color.White;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(103, 44);
            this.toolStripButton5.Text = "Ana Sayfa";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yazOkuluKaydıToolStripMenuItem,
            this.normalKayıtToolStripMenuItem,
            this.çalışanKaydıToolStripMenuItem});
            this.toolStripSplitButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(114, 44);
            this.toolStripSplitButton1.Text = "Yeni Kayıt";
            // 
            // yazOkuluKaydıToolStripMenuItem
            // 
            this.yazOkuluKaydıToolStripMenuItem.Name = "yazOkuluKaydıToolStripMenuItem";
            this.yazOkuluKaydıToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.yazOkuluKaydıToolStripMenuItem.Text = "Yaz Okulu Kaydı";
            this.yazOkuluKaydıToolStripMenuItem.Click += new System.EventHandler(this.yazOkuluKaydıToolStripMenuItem_Click);
            // 
            // normalKayıtToolStripMenuItem
            // 
            this.normalKayıtToolStripMenuItem.Name = "normalKayıtToolStripMenuItem";
            this.normalKayıtToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.normalKayıtToolStripMenuItem.Text = "Normal Kayıt";
            // 
            // çalışanKaydıToolStripMenuItem
            // 
            this.çalışanKaydıToolStripMenuItem.Name = "çalışanKaydıToolStripMenuItem";
            this.çalışanKaydıToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.çalışanKaydıToolStripMenuItem.Text = "Çalışan Kaydı";
            this.çalışanKaydıToolStripMenuItem.Click += new System.EventHandler(this.çalışanKaydıToolStripMenuItem_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.ForeColor = System.Drawing.Color.White;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(109, 44);
            this.toolStripButton2.Text = "Kayıt Silme";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(102, 44);
            this.toolStripButton1.Text = "Çalışanlar";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.ForeColor = System.Drawing.Color.White;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(108, 44);
            this.toolStripButton3.Text = "Gelir-Gider";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.ForeColor = System.Drawing.Color.White;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(144, 44);
            this.toolStripButton4.Text = "Çamaşır Makinesi";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.ForeColor = System.Drawing.Color.White;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(107, 44);
            this.toolStripButton6.Text = "Kişi Arama";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.ForeColor = System.Drawing.Color.White;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(147, 44);
            this.toolStripButton7.Text = "Oda ve Daire Kayıt";
            // 
            // label38
            // 
            this.label38.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Monotype Corsiva", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label38.ForeColor = System.Drawing.Color.SteelBlue;
            this.label38.Location = new System.Drawing.Point(1142, 51);
            this.label38.Margin = new System.Windows.Forms.Padding(20);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(215, 18);
            this.label38.TabIndex = 37;
            this.label38.Text = "Hoşgeldiniz Neslihan Demirtaş";
            // 
            // label40
            // 
            this.label40.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label40.Font = new System.Drawing.Font("Monotype Corsiva", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label40.ForeColor = System.Drawing.Color.SteelBlue;
            this.label40.Location = new System.Drawing.Point(1133, 0);
            this.label40.Margin = new System.Windows.Forms.Padding(20);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(224, 43);
            this.label40.TabIndex = 36;
            this.label40.Text = "ARYA APART";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.Controls.Add(this.topGelir);
            this.panel2.Controls.Add(this.topCam);
            this.panel2.Controls.Add(this.topKira);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(22, 164);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(417, 327);
            this.panel2.TabIndex = 38;
            // 
            // topGelir
            // 
            this.topGelir.BackColor = System.Drawing.Color.Plum;
            this.topGelir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.topGelir.ForeColor = System.Drawing.Color.White;
            this.topGelir.Location = new System.Drawing.Point(239, 106);
            this.topGelir.Name = "topGelir";
            this.topGelir.Size = new System.Drawing.Size(82, 26);
            this.topGelir.TabIndex = 44;
            this.topGelir.UseVisualStyleBackColor = false;
            this.topGelir.Click += new System.EventHandler(this.topGelir_Click);
            // 
            // topCam
            // 
            this.topCam.BackColor = System.Drawing.Color.Plum;
            this.topCam.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.topCam.ForeColor = System.Drawing.Color.White;
            this.topCam.Location = new System.Drawing.Point(239, 70);
            this.topCam.Name = "topCam";
            this.topCam.Size = new System.Drawing.Size(82, 26);
            this.topCam.TabIndex = 43;
            this.topCam.UseVisualStyleBackColor = false;
            this.topCam.Click += new System.EventHandler(this.topCam_Click);
            // 
            // topKira
            // 
            this.topKira.BackColor = System.Drawing.Color.Plum;
            this.topKira.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.topKira.ForeColor = System.Drawing.Color.White;
            this.topKira.Location = new System.Drawing.Point(239, 27);
            this.topKira.Name = "topKira";
            this.topKira.Size = new System.Drawing.Size(82, 26);
            this.topKira.TabIndex = 42;
            this.topKira.UseVisualStyleBackColor = false;
            this.topKira.Click += new System.EventHandler(this.topKira_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(30, 114);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 18);
            this.label6.TabIndex = 5;
            this.label6.Text = "Toplam Gelir";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(30, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 18);
            this.label5.TabIndex = 3;
            this.label5.Text = "Toplam Çamaşırhane";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(30, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 18);
            this.label3.TabIndex = 1;
            this.label3.Text = "Toplam Kira";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel3.Controls.Add(this.lblKdvGid);
            this.panel3.Controls.Add(this.label27);
            this.panel3.Controls.Add(this.lblStopajGid);
            this.panel3.Controls.Add(this.label26);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.lblTopGid);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.lblDigerGid);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.lblMaasGid);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.lblIntGid);
            this.panel3.Controls.Add(this.lblGazGid);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.lblSuGid);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.lblElektrikGid);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel3.Location = new System.Drawing.Point(482, 164);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(417, 393);
            this.panel3.TabIndex = 39;
            // 
            // lblKdvGid
            // 
            this.lblKdvGid.AutoSize = true;
            this.lblKdvGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblKdvGid.ForeColor = System.Drawing.Color.White;
            this.lblKdvGid.Location = new System.Drawing.Point(248, 266);
            this.lblKdvGid.Name = "lblKdvGid";
            this.lblKdvGid.Size = new System.Drawing.Size(26, 18);
            this.lblKdvGid.TabIndex = 19;
            this.lblKdvGid.Text = "10";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(31, 266);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 18);
            this.label27.TabIndex = 18;
            this.label27.Text = "KDV";
            // 
            // lblStopajGid
            // 
            this.lblStopajGid.AutoSize = true;
            this.lblStopajGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStopajGid.ForeColor = System.Drawing.Color.White;
            this.lblStopajGid.Location = new System.Drawing.Point(247, 228);
            this.lblStopajGid.Name = "lblStopajGid";
            this.lblStopajGid.Size = new System.Drawing.Size(26, 18);
            this.lblStopajGid.TabIndex = 17;
            this.lblStopajGid.Text = "10";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(30, 228);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(56, 18);
            this.label26.TabIndex = 16;
            this.label26.Text = "Stopaj";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(31, 190);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(160, 18);
            this.label13.TabIndex = 15;
            this.label13.Text = "Çalışan Maaş Gideri";
            // 
            // lblTopGid
            // 
            this.lblTopGid.AutoSize = true;
            this.lblTopGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTopGid.ForeColor = System.Drawing.Color.White;
            this.lblTopGid.Location = new System.Drawing.Point(247, 342);
            this.lblTopGid.Name = "lblTopGid";
            this.lblTopGid.Size = new System.Drawing.Size(26, 18);
            this.lblTopGid.TabIndex = 14;
            this.lblTopGid.Text = "10";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(30, 342);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(110, 18);
            this.label21.TabIndex = 13;
            this.label21.Text = "Toplam Gider";
            // 
            // lblDigerGid
            // 
            this.lblDigerGid.AutoSize = true;
            this.lblDigerGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblDigerGid.ForeColor = System.Drawing.Color.White;
            this.lblDigerGid.Location = new System.Drawing.Point(247, 304);
            this.lblDigerGid.Name = "lblDigerGid";
            this.lblDigerGid.Size = new System.Drawing.Size(26, 18);
            this.lblDigerGid.TabIndex = 12;
            this.lblDigerGid.Text = "10";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(30, 304);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(113, 18);
            this.label17.TabIndex = 11;
            this.label17.Text = "Diğer Giderler";
            // 
            // lblMaasGid
            // 
            this.lblMaasGid.AutoSize = true;
            this.lblMaasGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblMaasGid.ForeColor = System.Drawing.Color.White;
            this.lblMaasGid.Location = new System.Drawing.Point(248, 190);
            this.lblMaasGid.Name = "lblMaasGid";
            this.lblMaasGid.Size = new System.Drawing.Size(26, 18);
            this.lblMaasGid.TabIndex = 10;
            this.lblMaasGid.Text = "10";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(30, 152);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(64, 18);
            this.label19.TabIndex = 9;
            this.label19.Text = "İnternet";
            // 
            // lblIntGid
            // 
            this.lblIntGid.AutoSize = true;
            this.lblIntGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblIntGid.ForeColor = System.Drawing.Color.White;
            this.lblIntGid.Location = new System.Drawing.Point(248, 152);
            this.lblIntGid.Name = "lblIntGid";
            this.lblIntGid.Size = new System.Drawing.Size(26, 18);
            this.lblIntGid.TabIndex = 8;
            this.lblIntGid.Text = "10";
            // 
            // lblGazGid
            // 
            this.lblGazGid.AutoSize = true;
            this.lblGazGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblGazGid.ForeColor = System.Drawing.Color.White;
            this.lblGazGid.Location = new System.Drawing.Point(248, 114);
            this.lblGazGid.Name = "lblGazGid";
            this.lblGazGid.Size = new System.Drawing.Size(26, 18);
            this.lblGazGid.TabIndex = 6;
            this.lblGazGid.Text = "10";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(30, 114);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(88, 18);
            this.label15.TabIndex = 5;
            this.label15.Text = "Doğal Gaz";
            // 
            // lblSuGid
            // 
            this.lblSuGid.AutoSize = true;
            this.lblSuGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblSuGid.ForeColor = System.Drawing.Color.White;
            this.lblSuGid.Location = new System.Drawing.Point(248, 76);
            this.lblSuGid.Name = "lblSuGid";
            this.lblSuGid.Size = new System.Drawing.Size(26, 18);
            this.lblSuGid.TabIndex = 4;
            this.lblSuGid.Text = "10";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(31, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(28, 18);
            this.label8.TabIndex = 3;
            this.label8.Text = "Su";
            // 
            // lblElektrikGid
            // 
            this.lblElektrikGid.AutoSize = true;
            this.lblElektrikGid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblElektrikGid.ForeColor = System.Drawing.Color.White;
            this.lblElektrikGid.Location = new System.Drawing.Point(248, 38);
            this.lblElektrikGid.Name = "lblElektrikGid";
            this.lblElektrikGid.Size = new System.Drawing.Size(26, 18);
            this.lblElektrikGid.TabIndex = 2;
            this.lblElektrikGid.Text = "10";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(30, 38);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 18);
            this.label10.TabIndex = 1;
            this.label10.Text = "Elektrik";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(40, 38);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(45, 18);
            this.label35.TabIndex = 1;
            this.label35.Text = "Ciro ";
            // 
            // lblCiro
            // 
            this.lblCiro.AutoSize = true;
            this.lblCiro.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblCiro.ForeColor = System.Drawing.Color.White;
            this.lblCiro.Location = new System.Drawing.Point(270, 38);
            this.lblCiro.Name = "lblCiro";
            this.lblCiro.Size = new System.Drawing.Size(26, 18);
            this.lblCiro.TabIndex = 2;
            this.lblCiro.Text = "10";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.lblCiro);
            this.panel4.Controls.Add(this.label35);
            this.panel4.Location = new System.Drawing.Point(922, 164);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(417, 327);
            this.panel4.TabIndex = 40;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel5.Controls.Add(this.label22);
            this.panel5.Controls.Add(this.lbldaireadi);
            this.panel5.Location = new System.Drawing.Point(22, 130);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(417, 28);
            this.panel5.TabIndex = 80;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(152, 4);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(99, 20);
            this.label22.TabIndex = 29;
            this.label22.Text = "GELİRLER";
            // 
            // lbldaireadi
            // 
            this.lbldaireadi.AutoSize = true;
            this.lbldaireadi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbldaireadi.ForeColor = System.Drawing.Color.White;
            this.lbldaireadi.Location = new System.Drawing.Point(29, 6);
            this.lbldaireadi.Name = "lbldaireadi";
            this.lbldaireadi.Size = new System.Drawing.Size(0, 20);
            this.lbldaireadi.TabIndex = 28;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Location = new System.Drawing.Point(482, 130);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(417, 28);
            this.panel6.TabIndex = 81;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(152, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 20);
            this.label2.TabIndex = 29;
            this.label2.Text = "GİDERLER";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(29, 6);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 20);
            this.label11.TabIndex = 28;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel7.Controls.Add(this.label23);
            this.panel7.Controls.Add(this.label24);
            this.panel7.Location = new System.Drawing.Point(922, 130);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(417, 28);
            this.panel7.TabIndex = 82;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(152, 4);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(112, 20);
            this.label23.TabIndex = 29;
            this.label23.Text = "KAR-ZARAR";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(29, 6);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(0, 20);
            this.label24.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(270, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 18);
            this.label4.TabIndex = 4;
            this.label4.Text = "10";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(40, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 18);
            this.label7.TabIndex = 3;
            this.label7.Text = "Zarar";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(270, 78);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 18);
            this.label9.TabIndex = 6;
            this.label9.Text = "10";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(40, 78);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 18);
            this.label12.TabIndex = 5;
            this.label12.Text = "Kar";
            // 
            // GelirGider
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1366, 749);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel22);
            this.Name = "GelirGider";
            this.Text = "500";
            this.Load += new System.EventHandler(this.GelirGider_Load);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.ComboBox yıl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox ay;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem yazOkuluKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripMenuItem çalışanKaydıToolStripMenuItem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblSuGid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblElektrikGid;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblDigerGid;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblMaasGid;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblIntGid;
        private System.Windows.Forms.Label lblGazGid;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblTopGid;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label lblCiro;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lbldaireadi;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblKdvGid;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label lblStopajGid;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button topGelir;
        private System.Windows.Forms.Button topCam;
        private System.Windows.Forms.Button topKira;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
    }
}