﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class GelirGider : Form
    {
        int miktar, miktarCam;
        string secilenay, secilenyıl;
        List<DateTime> camasirhane = new List<DateTime>();
        public GelirGider()
        {
            InitializeComponent();
        }

        private void GelirGider_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.Show();
        }

      
        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.Show();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.Show();
        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.Show();
        }
        public void ToplamGelir()
        {
            try
            {
                int secilenyılint = Int32.Parse(secilenyıl);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd = new SqlCommand("SELECT SUM(Miktar) FROM AyKira where Ay= '" + secilenay + "' AND YilID='" + secilenyılint + "' ", cnn);
                miktar = (int)cmd.ExecuteScalar();
                topKira.Text = miktar.ToString();
               
                cnn.Close();
            }
            catch
            {

                int miktar = 0;
                topKira.Text = miktar.ToString();
                int top = miktar + miktarCam;
                topGelir.Text = top.ToString();
            }
            try
            {
                string[] aylar = new string[] { "Aylar", "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık" };
                int secilenyılint = Int32.Parse(secilenyıl);
                int index = Array.IndexOf(aylar, secilenay);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd1 = new SqlCommand("SELECT SUM(MakineUcret) FROM Camasirhane WHERE  (DATEPART(yy, Tarih) = '" + secilenyılint + "' AND    DATEPART(mm, Tarih) = '" + index + "') AND ID IS NOT NULL", cnn);

                miktarCam = (int)cmd1.ExecuteScalar();
                topCam.Text = miktarCam.ToString();
                int top = miktar + miktarCam;
                topGelir.Text = top.ToString();
                cnn.Close();

            }
            catch
            {
                int miktarCam = 0;
                topCam.Text = miktarCam.ToString();
                int top = miktar + miktarCam;
                topGelir.Text = top.ToString();


            }
    
            
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                secilenay = ay.SelectedItem.ToString();
                secilenyıl = yıl.SelectedItem.ToString();
                
                ToplamGelir();
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        private void topGelir_Click(object sender, EventArgs e)
        {

        }

        private void topCam_Click(object sender, EventArgs e)
        {

        }

        private void topKira_Click(object sender, EventArgs e)
        {

        }
    }
}
