﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class GelirGider : Form
    {
        int miktar, miktarCam;
        string secilenay = "Ocak";
        string secilenyıl = "2019";
        int topKİraGeliri;
        int elektrik, su, dogalgaz, diger,internet,calisan;
        int topG;
        int secilenyılint;
        int index;
        long calisanmaas;
        int el, s, d, t, di, m, sto, kdv, ssk, ba;
        string[] aylar = new string[] { "Aylar", "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık" };
        public GelirGider()
        {
            InitializeComponent();
        }
        /*public void getapart()

        {

            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Apartlar where ID  = '" + apartid + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    apartAdi.Text += dr4[1] as string;

                }
                dr4.NextResult();
                dr4.Close();

            }
        }*/
        private void GelirGider_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            this.Hide();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            this.Hide();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            this.Hide();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            this.Hide();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            this.Hide();
            camasirmakinesi.Show();
        }

      
        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            this.Hide();
            anasayfa.Show();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            this.Hide();
            kisiarama.Show();
        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            this.Hide();
            calisanlistesi.Show();
        }
        public void ToplamGelir()
        {
            try
            {
                secilenyılint = Int32.Parse(secilenyıl);
                index = Array.IndexOf(aylar, secilenay);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd = new SqlCommand("SELECT SUM(Miktar) FROM AyKira where (DATEPART(yy, OdemeTarih) = '" + secilenyılint + "' AND    DATEPART(mm, OdemeTarih) = '" + index + "') ", cnn);
                miktar = (int)cmd.ExecuteScalar();
                topKira.Text = miktar.ToString();
               
                cnn.Close();
            }
            catch
            {

                int miktar = 0;
                topKira.Text = miktar.ToString();
                topG = miktar + miktarCam;
                topGelir.Text = topG.ToString();
            }
            try
            {
                
                secilenyılint = Int32.Parse(secilenyıl);
                index = Array.IndexOf(aylar, secilenay);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlCommand cmd1 = new SqlCommand("SELECT SUM(MakineUcret) FROM Camasirhane WHERE  (DATEPART(yy, Tarih) = '" + secilenyılint + "' AND    DATEPART(mm, Tarih) = '" + index + "') AND ID IS NOT NULL", cnn);

                miktarCam = (int)cmd1.ExecuteScalar();
                topCam.Text = miktarCam.ToString();
                int top = miktar + miktarCam;
                topGelir.Text = top.ToString();
                cnn.Close();

            }
            catch
            {
                int miktarCam = 0;
                topCam.Text = miktarCam.ToString();
                int top = miktar + miktarCam;
                topGelir.Text = top.ToString();


            }
    
            
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                secilenay = ay.SelectedItem.ToString();
                secilenyıl = yıl.SelectedItem.ToString();
                
                ToplamGelir();
                DaireGiderleri();
                
                int myIntValue = unchecked((int)calisanmaas);
                int topgider = internet + elektrik + su + dogalgaz + diger+ myIntValue+ el + d + s + di + sto + kdv + ba + ssk + m + t;
                int tp = el + d + s + di + sto + kdv + ba + ssk + m + t;
                lblTopGid.Text = topgider.ToString();
                int kar = topG - topgider;
                int zarar = topgider - topG;
                if (topG>topgider)
                {
                    lblKar.Text = kar.ToString();
                }
                else
                {
                    lblZarar.Text = zarar.ToString();
                }
                
                
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        private void topGelir_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            GenelGider gnlgdr = new GenelGider();
            gnlgdr.Show();
            this.Hide();
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            OdaEkleme oe = new OdaEkleme();
            oe.Show();
            this.Hide();
        }

        private void toolStripSplitButton1_ButtonClick(object sender, EventArgs e)
        {

        }

        private void topCam_Click(object sender, EventArgs e)
        {

        }

        private void topKira_Click(object sender, EventArgs e)
        {

        }
        public void toplamKiraGeliri()
        {
            SqlConnection cnn = database.getConnection();
            cnn.Open();
            using (SqlCommand cmd4 = new SqlCommand("SELECT Count(Miktar) FROM AyKira ", cnn))
            {

                topKİraGeliri = (Int32)cmd4.ExecuteScalar();

            }
        }
        public void DaireGiderleri()
        {
            secilenyılint = Int32.Parse(secilenyıl);
            try {
                int secilenyılint = Int32.Parse(secilenyıl);
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                try
                {
                    using (SqlCommand cmd4 = new SqlCommand("SELECT Sum(Elektrik) FROM DaireGider where Ay= '" + secilenay + "' AND Yıl= '" + secilenyılint + "' ", cnn))
                    {
                        SqlDataReader rd = cmd4.ExecuteReader();
                        while (rd.Read())
                        {
                            elektrik = rd.GetInt32(0);
                        }
                        rd.Close();
                    }

                    lblElektrikGid.Text = elektrik.ToString();

                }
                catch
                {
                    elektrik = 0;
                    lblElektrikGid.Text = elektrik.ToString();
                }
                try
                {
                    using (SqlCommand cmd4 = new SqlCommand("SELECT Sum(Su) FROM DaireGider where Ay= '" + secilenay + "' AND Yıl= '" + secilenyılint + "' ", cnn))
                    {
                        SqlDataReader rd = cmd4.ExecuteReader();
                        while (rd.Read())
                        {
                            su = rd.GetInt32(0);
                        }
                        rd.Close();
                        lblSuGid.Text = su.ToString();

                    }
                }
                catch
                {
                    su = 0;
                    lblSuGid.Text = su.ToString();
                }
                try
                {
                    using (SqlCommand cmd4 = new SqlCommand("SELECT Sum(Dogalgaz) FROM DaireGider where Ay= '" + secilenay + "' AND Yıl= '" + secilenyılint + "' ", cnn))
                    {
                        SqlDataReader rd = cmd4.ExecuteReader();
                        while (rd.Read())
                        {
                            dogalgaz = rd.GetInt32(0);
                        }
                        rd.Close();

                        lblGazGid.Text = dogalgaz.ToString();

                    }
                }
                catch
                {
                    dogalgaz = 0;
                    lblGazGid.Text = dogalgaz.ToString();
                }
                try
                {
                    using (SqlCommand cmd4 = new SqlCommand("SELECT Sum(DigerGiderler) FROM DaireGider where Ay= '" + secilenay + "' AND Yıl= '" + secilenyılint + "' ", cnn))
                    {
                        SqlDataReader rd = cmd4.ExecuteReader();
                        while (rd.Read())
                        {
                            diger = rd.GetInt32(0);
                        }
                        rd.Close();

                        lblDigerGid.Text = diger.ToString();

                    }
                }
                catch
                {
                    diger = 0;
                    lblDigerGid.Text = diger.ToString();
                }
                try
                {
                    using (SqlCommand cmd4 = new SqlCommand("SELECT Sum(Internet) FROM DaireGider where Ay= '" + secilenay + "' AND Yıl= '" + secilenyılint + "' ", cnn))
                    {
                        SqlDataReader rd = cmd4.ExecuteReader();
                        while (rd.Read())
                        {
                            internet = rd.GetInt32(0);
                        }
                        rd.Close();

                        lblIntGid.Text = internet.ToString();

                    }
                }
                catch
                {
                    internet = 0;
                    lblIntGid.Text = internet.ToString();
                }
                try
                {
                    using (SqlCommand cmd4 = new SqlCommand("SELECT Sum(SaatlikUcret) FROM CalismaSaatleri", cnn))
                    {
                        SqlDataReader rd = cmd4.ExecuteReader();
                        while (rd.Read())
                        {
                            calisanmaas = rd.GetInt64(0);
                        }
                        rd.Close();


                        lblMaasGid.Text = calisanmaas.ToString();

                    }
                }
                catch
                {
                    calisanmaas = 0;
                    lblMaasGid.Text = calisanmaas.ToString();
                }
                try
                {
                    using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM GenelGiderler where Ay= '" + secilenay + "' AND Yıl= '" + secilenyılint + "'", cnn))
                    {
                        SqlDataReader rd = cmd4.ExecuteReader();
                        while (rd.Read())
                        {
                            d = rd.GetInt32(1);
                            el = rd.GetInt32(2);
                            s = rd.GetInt32(3);
                            t = rd.GetInt32(4);
                            ssk = rd.GetInt32(5);
                            m = rd.GetInt32(6);
                            di = rd.GetInt32(7);
                            ba = rd.GetInt32(8);
                            sto = rd.GetInt32(9);
                            kdv = rd.GetInt32(10);
                        }
                        rd.Close();


                        lbld.Text = d.ToString();
                        lble.Text = el.ToString();
                        lbls.Text = s.ToString();
                        lblt.Text = t.ToString();
                        lblssk.Text = ssk.ToString();
                        lblm.Text = m.ToString();
                        lbldi.Text = di.ToString();
                        lblba.Text = ba.ToString();
                        lblsto.Text = sto.ToString();
                        lblkdv.Text = kdv.ToString();

                    }
                }
                catch 
                {
                    lbld.Text = "0";
                    lble.Text = "0";
                    lbls.Text = "0";
                    lblt.Text = "0";
                    lblssk.Text = "0";
                    lblm.Text = "0";
                    lbldi.Text = "0";
                    lblsto.Text = "0";
                    lblkdv.Text = "0";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        
    }
}
