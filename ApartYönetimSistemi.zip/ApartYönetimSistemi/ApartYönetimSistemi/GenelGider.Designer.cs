﻿namespace ApartYönetimSistemi
{
    partial class GenelGider
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GenelGider));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.yazOkuluKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çalışanKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.txtBagkur = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtssk = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtStopaj = new System.Windows.Forms.TextBox();
            this.txtKDV = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.txtm = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtdi = new System.Windows.Forms.TextBox();
            this.txts = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txte = new System.Windows.Forms.TextBox();
            this.txtd = new System.Windows.Forms.TextBox();
            this.txtt = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.ay = new System.Windows.Forms.ComboBox();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label95 = new System.Windows.Forms.Label();
            this.yıl = new System.Windows.Forms.ComboBox();
            this.apartAdi = new System.Windows.Forms.Label();
            this.toolStrip1.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel22.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton5,
            this.toolStripSplitButton1,
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton6,
            this.toolStripButton7});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1366, 47);
            this.toolStrip1.TabIndex = 35;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.ForeColor = System.Drawing.Color.White;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(103, 44);
            this.toolStripButton5.Text = "Ana Sayfa";
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yazOkuluKaydıToolStripMenuItem,
            this.normalKayıtToolStripMenuItem,
            this.çalışanKaydıToolStripMenuItem});
            this.toolStripSplitButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(114, 44);
            this.toolStripSplitButton1.Text = "Yeni Kayıt";
            // 
            // yazOkuluKaydıToolStripMenuItem
            // 
            this.yazOkuluKaydıToolStripMenuItem.Name = "yazOkuluKaydıToolStripMenuItem";
            this.yazOkuluKaydıToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.yazOkuluKaydıToolStripMenuItem.Text = "Yaz Okulu Kaydı";
            // 
            // normalKayıtToolStripMenuItem
            // 
            this.normalKayıtToolStripMenuItem.Name = "normalKayıtToolStripMenuItem";
            this.normalKayıtToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.normalKayıtToolStripMenuItem.Text = "Normal Kayıt";
            // 
            // çalışanKaydıToolStripMenuItem
            // 
            this.çalışanKaydıToolStripMenuItem.Name = "çalışanKaydıToolStripMenuItem";
            this.çalışanKaydıToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.çalışanKaydıToolStripMenuItem.Text = "Çalışan Kaydı";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.ForeColor = System.Drawing.Color.White;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(109, 44);
            this.toolStripButton2.Text = "Kayıt Silme";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(102, 44);
            this.toolStripButton1.Text = "Çalışanlar";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.ForeColor = System.Drawing.Color.White;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(108, 44);
            this.toolStripButton3.Text = "Gelir-Gider";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.ForeColor = System.Drawing.Color.White;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(144, 44);
            this.toolStripButton4.Text = "Çamaşır Makinesi";
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.ForeColor = System.Drawing.Color.White;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(107, 44);
            this.toolStripButton6.Text = "Kişi Arama";
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.ForeColor = System.Drawing.Color.White;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(147, 44);
            this.toolStripButton7.Text = "Oda ve Daire Kayıt";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel9.Controls.Add(this.label4);
            this.panel9.Controls.Add(this.label14);
            this.panel9.Location = new System.Drawing.Point(96, 161);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(787, 28);
            this.panel9.TabIndex = 84;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(278, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 20);
            this.label4.TabIndex = 29;
            this.label4.Text = "GENEL GİDERLER";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(29, 6);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 20);
            this.label14.TabIndex = 28;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel10.Controls.Add(this.label26);
            this.panel10.Controls.Add(this.txtBagkur);
            this.panel10.Controls.Add(this.label20);
            this.panel10.Controls.Add(this.txtssk);
            this.panel10.Controls.Add(this.label27);
            this.panel10.Controls.Add(this.label16);
            this.panel10.Controls.Add(this.txtStopaj);
            this.panel10.Controls.Add(this.txtKDV);
            this.panel10.Location = new System.Drawing.Point(96, 195);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(417, 324);
            this.panel10.TabIndex = 83;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(27, 45);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 18);
            this.label26.TabIndex = 16;
            this.label26.Text = "SSK";
            // 
            // txtBagkur
            // 
            this.txtBagkur.Location = new System.Drawing.Point(220, 77);
            this.txtBagkur.Name = "txtBagkur";
            this.txtBagkur.Size = new System.Drawing.Size(62, 20);
            this.txtBagkur.TabIndex = 48;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(27, 112);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(56, 18);
            this.label20.TabIndex = 16;
            this.label20.Text = "Stopaj";
            // 
            // txtssk
            // 
            this.txtssk.Location = new System.Drawing.Point(220, 42);
            this.txtssk.Name = "txtssk";
            this.txtssk.Size = new System.Drawing.Size(62, 20);
            this.txtssk.TabIndex = 47;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(27, 81);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(61, 18);
            this.label27.TabIndex = 18;
            this.label27.Text = "Bağkur";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(28, 150);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 18);
            this.label16.TabIndex = 18;
            this.label16.Text = "KDV";
            // 
            // txtStopaj
            // 
            this.txtStopaj.Location = new System.Drawing.Point(220, 109);
            this.txtStopaj.Name = "txtStopaj";
            this.txtStopaj.Size = new System.Drawing.Size(62, 20);
            this.txtStopaj.TabIndex = 20;
            // 
            // txtKDV
            // 
            this.txtKDV.Location = new System.Drawing.Point(220, 144);
            this.txtKDV.Name = "txtKDV";
            this.txtKDV.Size = new System.Drawing.Size(62, 20);
            this.txtKDV.TabIndex = 21;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(29, 179);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(36, 18);
            this.label18.TabIndex = 19;
            this.label18.Text = "Tüp";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(29, 144);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(88, 18);
            this.label25.TabIndex = 18;
            this.label25.Text = "Doğal Gaz";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(30, 106);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(28, 18);
            this.label28.TabIndex = 17;
            this.label28.Text = "Su";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(29, 68);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(65, 18);
            this.label29.TabIndex = 16;
            this.label29.Text = "Elektrik";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Plum;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.txtm);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtdi);
            this.panel1.Controls.Add(this.txts);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txte);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.txtd);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.txtt);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Location = new System.Drawing.Point(537, 195);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(346, 324);
            this.panel1.TabIndex = 85;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(29, 258);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 18);
            this.label5.TabIndex = 58;
            this.label5.Text = "Market";
            // 
            // txtm
            // 
            this.txtm.Location = new System.Drawing.Point(167, 256);
            this.txtm.Name = "txtm";
            this.txtm.Size = new System.Drawing.Size(62, 20);
            this.txtm.TabIndex = 59;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(29, 217);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 18);
            this.label3.TabIndex = 56;
            this.label3.Text = "Diğer Giderler";
            // 
            // txtdi
            // 
            this.txtdi.Location = new System.Drawing.Point(167, 215);
            this.txtdi.Name = "txtdi";
            this.txtdi.Size = new System.Drawing.Size(62, 20);
            this.txtdi.TabIndex = 57;
            // 
            // txts
            // 
            this.txts.Location = new System.Drawing.Point(167, 110);
            this.txts.Name = "txts";
            this.txts.Size = new System.Drawing.Size(62, 20);
            this.txts.TabIndex = 55;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(29, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 18);
            this.label1.TabIndex = 20;
            this.label1.Text = "Ortak Alan Giderleri";
            // 
            // txte
            // 
            this.txte.Location = new System.Drawing.Point(167, 75);
            this.txte.Name = "txte";
            this.txte.Size = new System.Drawing.Size(62, 20);
            this.txte.TabIndex = 54;
            // 
            // txtd
            // 
            this.txtd.Location = new System.Drawing.Point(167, 142);
            this.txtd.Name = "txtd";
            this.txtd.Size = new System.Drawing.Size(62, 20);
            this.txtd.TabIndex = 52;
            // 
            // txtt
            // 
            this.txtt.Location = new System.Drawing.Point(167, 177);
            this.txtt.Name = "txtt";
            this.txtt.Size = new System.Drawing.Size(62, 20);
            this.txtt.TabIndex = 53;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.DarkOrchid;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(805, 538);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(78, 37);
            this.button5.TabIndex = 52;
            this.button5.Text = "Ekle";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.ay);
            this.panel2.Location = new System.Drawing.Point(564, 95);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(219, 37);
            this.panel2.TabIndex = 87;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(9, 11);
            this.label2.Margin = new System.Windows.Forms.Padding(0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 15);
            this.label2.TabIndex = 19;
            this.label2.Text = "Ay Seç";
            // 
            // ay
            // 
            this.ay.FormattingEnabled = true;
            this.ay.Items.AddRange(new object[] {
            "Ocak",
            "Şubat",
            "Mart",
            "Nisan",
            "Mayıs",
            "Haziran",
            "Temmuz",
            "Ağustos",
            "Eylül",
            "Ekim",
            "Kasım",
            "Aralık"});
            this.ay.Location = new System.Drawing.Point(71, 8);
            this.ay.Margin = new System.Windows.Forms.Padding(0);
            this.ay.Name = "ay";
            this.ay.Size = new System.Drawing.Size(132, 21);
            this.ay.TabIndex = 22;
            this.ay.SelectedIndexChanged += new System.EventHandler(this.ay_SelectedIndexChanged);
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel22.Controls.Add(this.label95);
            this.panel22.Controls.Add(this.yıl);
            this.panel22.Location = new System.Drawing.Point(270, 95);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(219, 37);
            this.panel22.TabIndex = 86;
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label95.ForeColor = System.Drawing.Color.White;
            this.label95.Location = new System.Drawing.Point(9, 11);
            this.label95.Margin = new System.Windows.Forms.Padding(0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(51, 15);
            this.label95.TabIndex = 19;
            this.label95.Text = "Yıl Seç";
            // 
            // yıl
            // 
            this.yıl.FormattingEnabled = true;
            this.yıl.Items.AddRange(new object[] {
            "2018",
            "2019",
            "2020",
            "2021",
            "2022",
            "2023",
            "2024"});
            this.yıl.Location = new System.Drawing.Point(71, 8);
            this.yıl.Margin = new System.Windows.Forms.Padding(0);
            this.yıl.Name = "yıl";
            this.yıl.Size = new System.Drawing.Size(132, 21);
            this.yıl.TabIndex = 22;
            // 
            // apartAdi
            // 
            this.apartAdi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.apartAdi.AutoSize = true;
            this.apartAdi.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.apartAdi.Font = new System.Drawing.Font("Monotype Corsiva", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.apartAdi.ForeColor = System.Drawing.Color.SteelBlue;
            this.apartAdi.Location = new System.Drawing.Point(1054, 0);
            this.apartAdi.Margin = new System.Windows.Forms.Padding(20);
            this.apartAdi.Name = "apartAdi";
            this.apartAdi.Size = new System.Drawing.Size(224, 43);
            this.apartAdi.TabIndex = 92;
            this.apartAdi.Text = "ARYA APART";
            // 
            // GenelGider
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1366, 749);
            this.Controls.Add(this.apartAdi);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel22);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.toolStrip1);
            this.Name = "GenelGider";
            this.Text = "GenelGider";
            this.Load += new System.EventHandler(this.GenelGider_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem yazOkuluKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem çalışanKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtBagkur;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtssk;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtStopaj;
        private System.Windows.Forms.TextBox txtKDV;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox txts;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txte;
        private System.Windows.Forms.TextBox txtd;
        private System.Windows.Forms.TextBox txtt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtm;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtdi;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox ay;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.ComboBox yıl;
        private System.Windows.Forms.Label apartAdi;
    }
}