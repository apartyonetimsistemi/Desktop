﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class KayitSilme : Form
    {
        public KayitSilme()
        {
            InitializeComponent();
        }
        int secilenKisiID;
        public void DisplayData()
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlDataAdapter adpt = new SqlDataAdapter("select * from OgrenciBilgileri  where Durum = 1", cnn);
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch { MessageBox.Show("Hata display data"); }
        }

        private void KayitSilme_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;

            DisplayData();
        }
        

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.Show();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.Show();
        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.Show();
        }
        public void kayitsilme()

        {
            try
            {
                
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                if (cnn.State != ConnectionState.Open)
                {
                    MessageBox.Show("Fail");
                    
                }
                else { MessageBox.Show("Success"); }
              
               

                SqlCommand cmd = new SqlCommand("UPDATE OgrenciBilgileri  SET Durum =0 where ID= '" + secilenKisiID + "' ",cnn);
                cmd.ExecuteNonQuery();
                SqlCommand cmd1 = new SqlCommand("UPDATE Yatak  SET Durumu =0 where KisiID= '" + secilenKisiID + "' ", cnn);
                cmd1.ExecuteNonQuery();
                MessageBox.Show("Kayıt Silme Başarılı");
                DisplayData();
                cnn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }

        }
        public void KisiArama(string adi)
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                string sorgu = "select * from OgrenciBilgileri where Adi like '%" + adi + "%' or Soyadi like '%" + adi + "%' ";
                SqlDataAdapter adpt = new SqlDataAdapter(sorgu, cnn);
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }
        private void btnDel_Click(object sender, EventArgs e)
        {
            kayitsilme();
        }

        private void txtKisiAra_TextChanged(object sender, EventArgs e)
        {
            KisiArama(txtKisiAra.Text);
        }
     
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int index = e.RowIndex;
                DataGridViewRow SelectedRow = dataGridView1.Rows[index];
                string secilenKisi = SelectedRow.Cells[0].Value.ToString();
                secilenKisiID = Int32.Parse(secilenKisi);
                MessageBox.Show(secilenKisi);
            }

            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }
    }
}
