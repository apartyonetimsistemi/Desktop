﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class KiraOde : Form
    {
        public string odenecekAy { get; set; }
        public string id { get; set; }
        public string apartid { get; set; }
        public KiraOde()
        {
            InitializeComponent();
        }
        public void kiraOde()
        {


            SqlConnection cnn = database.getConnection();
            cnn.Open();
            
            int kisiid = Int32.Parse(id);
            int miktar = 0;
            Int32.TryParse(textBox1.Text, out miktar);
            string odemeSekli = comboBox1.SelectedItem.ToString();
             if (kisiid != 0)
                {                    
                    SqlCommand cmd = new SqlCommand("UPDATE AyKira SET Miktar=@Miktar,OdemeSekli=@OdemeSekli,OdemeTarih=@OdemeTarih WHERE KisiID='" + kisiid+"' AND Ay='"+ay+"'", cnn);
                 
                    cmd.Parameters.AddWithValue("@Miktar", miktar);
                    cmd.Parameters.AddWithValue("@OdemeSekli", odemeSekli);
                    cmd.Parameters.AddWithValue("@OdemeTarih", DateTime.Now);;
                    int a = cmd.ExecuteNonQuery();
                    
                    
                if (a == 0)
                {
                    MessageBox.Show("Ödeme Başarılı");
                }

                else
                {
                    MessageBox.Show("Ödeme Başarısız");
                }
                cnn.Close();
            }
                else
                {
                    MessageBox.Show("Seçim yapmadınız");
                }
           
        }

        private void KiraOde_Load(object sender, EventArgs e)
        {
            MessageBox.Show(DateTime.Now.ToString());
            ay.Text = odenecekAy;

            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            kiraOde();

        }

        private void btnYazdir_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.id = apartid;
            this.Hide();
            anasayfa.Show();
        }

        private void toolStripSplitButton1_ButtonClick(object sender, EventArgs e)
        {

        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.apartid = apartid;
            this.Hide();
            yenikayit.Show();
        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.apartid = apartid;
            this.Hide();
            calisanlistesi.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.apartid = apartid;
            this.Hide();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.apartid = apartid;
            this.Hide();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.apartid = apartid;
            this.Hide();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.apartid = apartid;
            this.Hide();
            camasirmakinesi.Show();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.apartid = apartid;
            this.Hide();
            kisiarama.Show();
        }
    }
}
