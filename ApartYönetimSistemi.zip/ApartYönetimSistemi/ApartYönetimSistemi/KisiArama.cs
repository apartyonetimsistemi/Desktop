﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class KisiArama : Form
    {
        SqlConnection cnn = database.getConnection();
        SqlCommand cmd;
        DataTable dt;
        SqlDataAdapter adpt;
        int secilenKisiID;
        public KisiArama()
        {
            InitializeComponent();
        }
       /* public void getapart()

        {

            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Apartlar where ID  = '" + apartid + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    apartAdi.Text += dr4[1] as string;

                }
                dr4.NextResult();
                dr4.Close();

            }
        }*/
        public void DisplayData()
        {
            try
            {
                cnn.Open();
                adpt = new SqlDataAdapter("select ID ,Adi,Soyadi,TcNum,TelNo,DogumYeri,DogumTarih, Uyruk,Adres,GirisTarih,CikisTairh,AylıkUcret,Depozito,KayitBilg,OzelDurum,IBAN,AnneAdi,AnneMeslek,AnneTel,BabaAdi,BabaMeslek,BabaTel,Expr2,Okul,Bölüm,Sınıf from tumBilgiler", cnn);
                dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch { MessageBox.Show("Hata display data"); }
        }
        public void KisiAra(string calisanadi)
        {
            cnn.Open();
            try
            {       
                string sorgu = "select Adi,Soyadi,TcNum,TelNo,DogumYeri,DogumTarih, Uyruk,Adres,GirisTarih,CikisTairh,AylıkUcret,Depozito,KayitBilg,OzelDurum,IBAN,AnneAdi,AnneMeslek,AnneTel,BabaAdi,BabaMeslek,BabaTel,Expr2,Okul,Bölüm,Sınıf from tumBilgiler where Adi like '%" + calisanadi + "%' or Soyadi like '%" + calisanadi + "%' or TcNum like '%" + calisanadi + "%' or TelNo like '%" + calisanadi + "%'  or KayitBilg like '%" + calisanadi + "%'";
                adpt = new SqlDataAdapter(sorgu, cnn);
                dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;    

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            cnn.Close();
        }
        private void KisiArama_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
            DisplayData();
        }
       
       

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            this.Hide();
            kisiarama.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            this.Hide();
            anasayfa.Show();
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            this.Hide();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            this.Hide();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            this.Hide();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            this.Hide();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            this.Hide();
            camasirmakinesi.Show();
        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            this.Hide();
            calisanlistesi.Show();
        }

        private void ara_TextChanged(object sender, EventArgs e)
        {
            KisiAra(ara.Text);
        }

  
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int index = e.RowIndex;
                DataGridViewRow SelectedRow = dataGridView1.Rows[index];
                string secilenKisi = SelectedRow.Cells[0].Value.ToString();

             
                MessageBox.Show(secilenKisi);
                KisiBilgileri kisiBilgileri = new KisiBilgileri();
                kisiBilgileri.kisiid = secilenKisi;
                kisiBilgileri.Show();
            }

            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }
    }
}
