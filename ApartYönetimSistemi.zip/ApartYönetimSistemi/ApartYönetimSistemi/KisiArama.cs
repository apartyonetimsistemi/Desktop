﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class KisiArama : Form
    {
        SqlConnection cnn = database.getConnection();
        SqlCommand cmd;
        DataTable dt;
        SqlDataAdapter adpt;
        public KisiArama()
        {
            InitializeComponent();
        }
        public void DisplayData()
        {
            try
            {
                cnn.Open();
                adpt = new SqlDataAdapter("select Adi,Soyadi,TcNum,TelNo,DogumYeri,DogumTarih, Uyruk,Adres,GirisTarih,CikisTairh,AylıkUcret,Depozito,KayitBilg,OzelDurum,IBAN,AnneAdi,AnneMeslek,AnneTel,BabaAdi,BabaMeslek,BabaTel,Expr2,Okul,Bölüm,Sınıf from tumBilgiler", cnn);
                dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch { MessageBox.Show("Hata display data"); }
        }
        public void KisiAra(string calisanadi)
        {
            cnn.Open();
            try
            {
                
                //long tc = long.Parse(calisanadi);             
                string sorgu = "select Adi,Soyadi,TcNum,TelNo,DogumYeri,DogumTarih, Uyruk,Adres,GirisTarih,CikisTairh,AylıkUcret,Depozito,KayitBilg,OzelDurum,IBAN,AnneAdi,AnneMeslek,AnneTel,BabaAdi,BabaMeslek,BabaTel,Expr2,Okul,Bölüm,Sınıf from tumBilgiler where Adi like '%" + calisanadi + "%' or Soyadi like '%" + calisanadi + "%' or TcNum like '%" + calisanadi + "%' or TelNo like '%" + calisanadi + "%'  or KayitBilg like '%" + calisanadi + "%'";
                adpt = new SqlDataAdapter(sorgu, cnn);
                dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;

                



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            cnn.Close();
        }
        private void KisiArama_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
            DisplayData();
        }
       
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.Show();
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.Show();
        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.Show();
        }

        private void ara_TextChanged(object sender, EventArgs e)
        {
            KisiAra(ara.Text);
        }
    }
}
