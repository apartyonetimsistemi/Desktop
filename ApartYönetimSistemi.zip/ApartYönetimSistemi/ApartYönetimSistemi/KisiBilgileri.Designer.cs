﻿namespace ApartYönetimSistemi
{
    partial class KisiBilgileri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KisiBilgileri));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.yazOkuluKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çalışanKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtKayıtBil = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtBasTarih = new System.Windows.Forms.TextBox();
            this.txtBitTarih = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtIban = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtDepozito = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtAylıkUcret = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtBabaMes = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.txtAnneMes = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtAnneAd = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAileAdres = new System.Windows.Forms.RichTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtBabaAd = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtAnneTel = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtBabaTel = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtDogumYeri = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtTel2 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtUyruk = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtSınıf = new System.Windows.Forms.TextBox();
            this.txtOkul = new System.Windows.Forms.TextBox();
            this.txtAdres = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtBolum = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtDogumTarih = new System.Windows.Forms.TextBox();
            this.txtOzelDurum = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTel = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTc = new System.Windows.Forms.TextBox();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.ogrenciödemeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.apartYonetimSistemiDataSet10 = new ApartYönetimSistemi.ApartYonetimSistemiDataSet10();
            this.ayKiraBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ayKiraTableAdapter = new ApartYönetimSistemi.ApartYonetimSistemiDataSet10TableAdapters.AyKiraTableAdapter();
            this.apartAdi = new System.Windows.Forms.Label();
            this.toolStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ogrenciödemeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ayKiraBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton5,
            this.toolStripSplitButton1,
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton6});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1269, 47);
            this.toolStrip1.TabIndex = 32;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.ForeColor = System.Drawing.Color.White;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(103, 44);
            this.toolStripButton5.Text = "Ana Sayfa";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yazOkuluKaydıToolStripMenuItem,
            this.normalKayıtToolStripMenuItem,
            this.çalışanKaydıToolStripMenuItem});
            this.toolStripSplitButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(114, 44);
            this.toolStripSplitButton1.Text = "Yeni Kayıt";
            // 
            // yazOkuluKaydıToolStripMenuItem
            // 
            this.yazOkuluKaydıToolStripMenuItem.Name = "yazOkuluKaydıToolStripMenuItem";
            this.yazOkuluKaydıToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.yazOkuluKaydıToolStripMenuItem.Text = "Yaz Okulu Kaydı";
            this.yazOkuluKaydıToolStripMenuItem.Click += new System.EventHandler(this.yazOkuluKaydıToolStripMenuItem_Click);
            // 
            // normalKayıtToolStripMenuItem
            // 
            this.normalKayıtToolStripMenuItem.Name = "normalKayıtToolStripMenuItem";
            this.normalKayıtToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.normalKayıtToolStripMenuItem.Text = "Normal Kayıt";
            // 
            // çalışanKaydıToolStripMenuItem
            // 
            this.çalışanKaydıToolStripMenuItem.Name = "çalışanKaydıToolStripMenuItem";
            this.çalışanKaydıToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.çalışanKaydıToolStripMenuItem.Text = "Çalışan Kaydı";
            this.çalışanKaydıToolStripMenuItem.Click += new System.EventHandler(this.çalışanKaydıToolStripMenuItem_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.ForeColor = System.Drawing.Color.White;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(109, 44);
            this.toolStripButton2.Text = "Kayıt Silme";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(102, 44);
            this.toolStripButton1.Text = "Çalışanlar";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.ForeColor = System.Drawing.Color.White;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(108, 44);
            this.toolStripButton3.Text = "Gelir-Gider";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.ForeColor = System.Drawing.Color.White;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(144, 44);
            this.toolStripButton4.Text = "Çamaşır Makinesi";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.ForeColor = System.Drawing.Color.White;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(107, 44);
            this.toolStripButton6.Text = "Kişi Arama";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.panel1.CausesValidation = false;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel1.Location = new System.Drawing.Point(19, 50);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1238, 724);
            this.panel1.TabIndex = 33;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(844, 575);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(145, 39);
            this.button1.TabIndex = 148;
            this.button1.Text = " Ödeme Bilgileri";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSave.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(844, 483);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(145, 39);
            this.btnSave.TabIndex = 147;
            this.btnSave.Text = "Kaydet";
            this.btnSave.UseVisualStyleBackColor = false;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel7.Controls.Add(this.label7);
            this.panel7.Location = new System.Drawing.Point(2, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1247, 37);
            this.panel7.TabIndex = 82;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(496, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 25);
            this.label7.TabIndex = 28;
            this.label7.Text = "KİŞİ BİLGİLERİ";
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel4.Controls.Add(this.txtKayıtBil);
            this.panel4.Controls.Add(this.label39);
            this.panel4.Controls.Add(this.txtBasTarih);
            this.panel4.Controls.Add(this.txtBitTarih);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.txtIban);
            this.panel4.Controls.Add(this.label28);
            this.panel4.Controls.Add(this.txtDepozito);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.txtAylıkUcret);
            this.panel4.Controls.Add(this.label24);
            this.panel4.Controls.Add(this.label29);
            this.panel4.Location = new System.Drawing.Point(631, 44);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(595, 409);
            this.panel4.TabIndex = 77;
            // 
            // txtKayıtBil
            // 
            this.txtKayıtBil.Location = new System.Drawing.Point(130, 155);
            this.txtKayıtBil.Name = "txtKayıtBil";
            this.txtKayıtBil.Size = new System.Drawing.Size(134, 20);
            this.txtKayıtBil.TabIndex = 150;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(3, 156);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(89, 16);
            this.label39.TabIndex = 149;
            this.label39.Text = "Kayıt Bilgisi";
            // 
            // txtBasTarih
            // 
            this.txtBasTarih.Location = new System.Drawing.Point(130, 30);
            this.txtBasTarih.Name = "txtBasTarih";
            this.txtBasTarih.Size = new System.Drawing.Size(134, 20);
            this.txtBasTarih.TabIndex = 69;
            // 
            // txtBitTarih
            // 
            this.txtBitTarih.Location = new System.Drawing.Point(130, 55);
            this.txtBitTarih.Name = "txtBitTarih";
            this.txtBitTarih.Size = new System.Drawing.Size(134, 20);
            this.txtBitTarih.TabIndex = 68;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(1, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(178, 24);
            this.label9.TabIndex = 67;
            this.label9.Text = "SENET BİLGİLERİ";
            // 
            // txtIban
            // 
            this.txtIban.Location = new System.Drawing.Point(130, 80);
            this.txtIban.Name = "txtIban";
            this.txtIban.Size = new System.Drawing.Size(134, 20);
            this.txtIban.TabIndex = 66;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(3, 82);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(108, 16);
            this.label28.TabIndex = 65;
            this.label28.Text = "Iban Numarası";
            // 
            // txtDepozito
            // 
            this.txtDepozito.Location = new System.Drawing.Point(130, 130);
            this.txtDepozito.Name = "txtDepozito";
            this.txtDepozito.Size = new System.Drawing.Size(134, 20);
            this.txtDepozito.TabIndex = 64;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(3, 131);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(115, 16);
            this.label21.TabIndex = 63;
            this.label21.Text = "Depozito Ücreti";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(4, 56);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(82, 16);
            this.label22.TabIndex = 59;
            this.label22.Text = "Bitiş Tarihi";
            // 
            // txtAylıkUcret
            // 
            this.txtAylıkUcret.Location = new System.Drawing.Point(130, 105);
            this.txtAylıkUcret.Name = "txtAylıkUcret";
            this.txtAylıkUcret.Size = new System.Drawing.Size(134, 20);
            this.txtAylıkUcret.TabIndex = 60;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(3, 106);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(83, 16);
            this.label24.TabIndex = 58;
            this.label24.Text = "Aylık Ücret";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(3, 31);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(121, 16);
            this.label29.TabIndex = 57;
            this.label29.Text = "Başlangıç Tarihi";
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.Controls.Add(this.txtBabaMes);
            this.panel2.Controls.Add(this.label34);
            this.panel2.Controls.Add(this.txtAnneMes);
            this.panel2.Controls.Add(this.label33);
            this.panel2.Controls.Add(this.txtAnneAd);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.txtAileAdres);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.txtBabaAd);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.txtAnneTel);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.txtBabaTel);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Location = new System.Drawing.Point(35, 461);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(545, 233);
            this.panel2.TabIndex = 77;
            // 
            // txtBabaMes
            // 
            this.txtBabaMes.Location = new System.Drawing.Point(381, 59);
            this.txtBabaMes.Name = "txtBabaMes";
            this.txtBabaMes.Size = new System.Drawing.Size(152, 20);
            this.txtBabaMes.TabIndex = 66;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(273, 59);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(104, 16);
            this.label34.TabIndex = 65;
            this.label34.Text = "Baba Mesleği";
            // 
            // txtAnneMes
            // 
            this.txtAnneMes.Location = new System.Drawing.Point(381, 33);
            this.txtAnneMes.Name = "txtAnneMes";
            this.txtAnneMes.Size = new System.Drawing.Size(152, 20);
            this.txtAnneMes.TabIndex = 64;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(273, 33);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(102, 16);
            this.label33.TabIndex = 63;
            this.label33.Text = "Anne Mesleği";
            // 
            // txtAnneAd
            // 
            this.txtAnneAd.Location = new System.Drawing.Point(107, 58);
            this.txtAnneAd.Name = "txtAnneAd";
            this.txtAnneAd.Size = new System.Drawing.Size(160, 20);
            this.txtAnneAd.TabIndex = 62;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(3, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 24);
            this.label5.TabIndex = 61;
            this.label5.Text = "AİLE BİLGİLERİ";
            // 
            // txtAileAdres
            // 
            this.txtAileAdres.Location = new System.Drawing.Point(107, 158);
            this.txtAileAdres.Name = "txtAileAdres";
            this.txtAileAdres.Size = new System.Drawing.Size(160, 56);
            this.txtAileAdres.TabIndex = 60;
            this.txtAileAdres.Text = "";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(7, 158);
            this.label18.Name = "label18";
            this.label18.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label18.Size = new System.Drawing.Size(49, 16);
            this.label18.TabIndex = 59;
            this.label18.Text = "Adres";
            // 
            // txtBabaAd
            // 
            this.txtBabaAd.Location = new System.Drawing.Point(107, 83);
            this.txtBabaAd.Name = "txtBabaAd";
            this.txtBabaAd.Size = new System.Drawing.Size(160, 20);
            this.txtBabaAd.TabIndex = 58;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(7, 82);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(72, 16);
            this.label23.TabIndex = 55;
            this.label23.Text = "Baba Adı";
            // 
            // txtAnneTel
            // 
            this.txtAnneTel.Location = new System.Drawing.Point(107, 108);
            this.txtAnneTel.Name = "txtAnneTel";
            this.txtAnneTel.Size = new System.Drawing.Size(160, 20);
            this.txtAnneTel.TabIndex = 57;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(7, 104);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(94, 16);
            this.label20.TabIndex = 54;
            this.label20.Text = "Anne Tel No";
            // 
            // txtBabaTel
            // 
            this.txtBabaTel.Location = new System.Drawing.Point(107, 133);
            this.txtBabaTel.Name = "txtBabaTel";
            this.txtBabaTel.Size = new System.Drawing.Size(160, 20);
            this.txtBabaTel.TabIndex = 56;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(7, 130);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 16);
            this.label6.TabIndex = 53;
            this.label6.Text = "Baba Tel No";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(7, 59);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(70, 16);
            this.label27.TabIndex = 52;
            this.label27.Text = "Anne Adı";
            // 
            // panel3
            // 
            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel3.Controls.Add(this.txtDogumYeri);
            this.panel3.Controls.Add(this.label36);
            this.panel3.Controls.Add(this.txtTel2);
            this.panel3.Controls.Add(this.label35);
            this.panel3.Controls.Add(this.txtUyruk);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.txtSınıf);
            this.panel3.Controls.Add(this.txtOkul);
            this.panel3.Controls.Add(this.txtAdres);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.txtBolum);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.txtDogumTarih);
            this.panel3.Controls.Add(this.txtOzelDurum);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.txtTel);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.txtTc);
            this.panel3.Controls.Add(this.txtSoyad);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.txtAd);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Location = new System.Drawing.Point(35, 44);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(545, 409);
            this.panel3.TabIndex = 76;
            // 
            // txtDogumYeri
            // 
            this.txtDogumYeri.Location = new System.Drawing.Point(114, 171);
            this.txtDogumYeri.Name = "txtDogumYeri";
            this.txtDogumYeri.Size = new System.Drawing.Size(172, 20);
            this.txtDogumYeri.TabIndex = 102;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(3, 176);
            this.label36.Name = "label36";
            this.label36.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label36.Size = new System.Drawing.Size(89, 16);
            this.label36.TabIndex = 101;
            this.label36.Text = "Doğum Yeri";
            // 
            // txtTel2
            // 
            this.txtTel2.Location = new System.Drawing.Point(113, 143);
            this.txtTel2.Name = "txtTel2";
            this.txtTel2.Size = new System.Drawing.Size(172, 20);
            this.txtTel2.TabIndex = 100;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(3, 147);
            this.label35.Name = "label35";
            this.label35.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label35.Size = new System.Drawing.Size(71, 16);
            this.label35.TabIndex = 99;
            this.label35.Text = "Tel No 2:";
            // 
            // txtUyruk
            // 
            this.txtUyruk.Location = new System.Drawing.Point(114, 227);
            this.txtUyruk.Name = "txtUyruk";
            this.txtUyruk.Size = new System.Drawing.Size(172, 20);
            this.txtUyruk.TabIndex = 98;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(5, 231);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 16);
            this.label15.TabIndex = 97;
            this.label15.Text = "Uyruk:";
            // 
            // txtSınıf
            // 
            this.txtSınıf.Location = new System.Drawing.Point(356, 122);
            this.txtSınıf.Name = "txtSınıf";
            this.txtSınıf.Size = new System.Drawing.Size(170, 20);
            this.txtSınıf.TabIndex = 96;
            // 
            // txtOkul
            // 
            this.txtOkul.Location = new System.Drawing.Point(356, 62);
            this.txtOkul.Name = "txtOkul";
            this.txtOkul.Size = new System.Drawing.Size(170, 20);
            this.txtOkul.TabIndex = 95;
            // 
            // txtAdres
            // 
            this.txtAdres.Location = new System.Drawing.Point(113, 255);
            this.txtAdres.Name = "txtAdres";
            this.txtAdres.Size = new System.Drawing.Size(173, 84);
            this.txtAdres.TabIndex = 94;
            this.txtAdres.Text = "";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(7, 275);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(53, 16);
            this.label10.TabIndex = 93;
            this.label10.Text = "Adres:";
            // 
            // txtBolum
            // 
            this.txtBolum.Location = new System.Drawing.Point(356, 91);
            this.txtBolum.Name = "txtBolum";
            this.txtBolum.Size = new System.Drawing.Size(170, 20);
            this.txtBolum.TabIndex = 91;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(292, 62);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 16);
            this.label13.TabIndex = 89;
            this.label13.Text = "Okulu:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(292, 92);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 16);
            this.label14.TabIndex = 90;
            this.label14.Text = "Bölümü:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(292, 121);
            this.label19.Name = "label19";
            this.label19.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label19.Size = new System.Drawing.Size(46, 16);
            this.label19.TabIndex = 88;
            this.label19.Text = "Sınıfı:";
            // 
            // txtDogumTarih
            // 
            this.txtDogumTarih.Location = new System.Drawing.Point(114, 199);
            this.txtDogumTarih.Name = "txtDogumTarih";
            this.txtDogumTarih.Size = new System.Drawing.Size(172, 20);
            this.txtDogumTarih.TabIndex = 87;
            // 
            // txtOzelDurum
            // 
            this.txtOzelDurum.Location = new System.Drawing.Point(114, 347);
            this.txtOzelDurum.Name = "txtOzelDurum";
            this.txtOzelDurum.Size = new System.Drawing.Size(172, 44);
            this.txtOzelDurum.TabIndex = 86;
            this.txtOzelDurum.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(5, 362);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(91, 16);
            this.label1.TabIndex = 85;
            this.label1.Text = "Özel Durum:";
            // 
            // txtTel
            // 
            this.txtTel.Location = new System.Drawing.Point(113, 115);
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(172, 20);
            this.txtTel.TabIndex = 83;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 119);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(59, 16);
            this.label2.TabIndex = 82;
            this.label2.Text = "Tel No:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(4, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 16);
            this.label3.TabIndex = 78;
            this.label3.Text = "Soyadı:";
            // 
            // txtTc
            // 
            this.txtTc.Location = new System.Drawing.Point(113, 87);
            this.txtTc.Name = "txtTc";
            this.txtTc.Size = new System.Drawing.Size(172, 20);
            this.txtTc.TabIndex = 80;
            // 
            // txtSoyad
            // 
            this.txtSoyad.Location = new System.Drawing.Point(113, 59);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(172, 20);
            this.txtSoyad.TabIndex = 81;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(3, 91);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 16);
            this.label11.TabIndex = 79;
            this.label11.Text = "TC No:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(3, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 16);
            this.label4.TabIndex = 77;
            this.label4.Text = "Doğum Tarihi:";
            // 
            // txtAd
            // 
            this.txtAd.Location = new System.Drawing.Point(113, 31);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(172, 20);
            this.txtAd.TabIndex = 76;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(7, 35);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 16);
            this.label17.TabIndex = 75;
            this.label17.Text = "Adı:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(4, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(178, 24);
            this.label8.TabIndex = 74;
            this.label8.Text = "KİŞİSEL BİLGİLER";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(-302, 43);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "Soyadı";
            // 
            // ogrenciödemeBindingSource
            // 
            this.ogrenciödemeBindingSource.DataMember = "ogrenciödeme";
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // apartYonetimSistemiDataSet10
            // 
            this.apartYonetimSistemiDataSet10.DataSetName = "ApartYonetimSistemiDataSet10";
            this.apartYonetimSistemiDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ayKiraBindingSource
            // 
            this.ayKiraBindingSource.DataMember = "AyKira";
            this.ayKiraBindingSource.DataSource = this.apartYonetimSistemiDataSet10;
            // 
            // ayKiraTableAdapter
            // 
            this.ayKiraTableAdapter.ClearBeforeFill = true;
            // 
            // apartAdi
            // 
            this.apartAdi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.apartAdi.AutoSize = true;
            this.apartAdi.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.apartAdi.Font = new System.Drawing.Font("Monotype Corsiva", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.apartAdi.ForeColor = System.Drawing.Color.SteelBlue;
            this.apartAdi.Location = new System.Drawing.Point(902, 0);
            this.apartAdi.Margin = new System.Windows.Forms.Padding(20);
            this.apartAdi.Name = "apartAdi";
            this.apartAdi.Size = new System.Drawing.Size(224, 43);
            this.apartAdi.TabIndex = 151;
            this.apartAdi.Text = "ARYA APART";
            // 
            // KisiBilgileri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1269, 749);
            this.Controls.Add(this.apartAdi);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "KisiBilgileri";
            this.Text = "KisiBilgileri";
            this.Load += new System.EventHandler(this.KisiBilgileri_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ogrenciödemeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ayKiraBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem yazOkuluKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtDogumTarih;
        private System.Windows.Forms.RichTextBox txtOzelDurum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTc;
        private System.Windows.Forms.TextBox txtSoyad;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtAnneAd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox txtAileAdres;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtBabaAd;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtAnneTel;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtBabaTel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtSınıf;
        private System.Windows.Forms.TextBox txtOkul;
        private System.Windows.Forms.RichTextBox txtAdres;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtBolum;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtBasTarih;
        private System.Windows.Forms.TextBox txtBitTarih;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtIban;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtDepozito;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtAylıkUcret;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label29;
       
        private System.Windows.Forms.BindingSource ogrenciödemeBindingSource;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.TextBox txtAnneMes;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtUyruk;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtBabaMes;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ToolStripMenuItem çalışanKaydıToolStripMenuItem;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.TextBox txtDogumYeri;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtTel2;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtKayıtBil;
        private System.Windows.Forms.Label label39;
        private ApartYonetimSistemiDataSet10 apartYonetimSistemiDataSet10;
        private System.Windows.Forms.BindingSource ayKiraBindingSource;
        private ApartYonetimSistemiDataSet10TableAdapters.AyKiraTableAdapter ayKiraTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label apartAdi;
    }
}