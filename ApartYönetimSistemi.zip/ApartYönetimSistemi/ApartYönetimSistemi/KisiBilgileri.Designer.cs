﻿namespace ApartYönetimSistemi
{
    partial class KisiBilgileri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KisiBilgileri));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.yazOkuluKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.çalışanKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button25 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label40 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.kalan12 = new System.Windows.Forms.Label();
            this.kalan11 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.ödenen12 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.kalan10 = new System.Windows.Forms.Label();
            this.button21 = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.kalan9 = new System.Windows.Forms.Label();
            this.button23 = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.button24 = new System.Windows.Forms.Button();
            this.kalan8 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.ödenen11 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.kalan7 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.label44 = new System.Windows.Forms.Label();
            this.button18 = new System.Windows.Forms.Button();
            this.ödenen10 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.ödenen9 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.ödenen2 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.ödenen4 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.kalan6 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.ödenen5 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.kalan5 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.ödenen3 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.kalan4 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.ödenen6 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.kalan3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.kalan1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.kalan2 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.ödenen8 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtBasTarih = new System.Windows.Forms.TextBox();
            this.txtSonTarih = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtIban = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtDepozito = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtAylıkUcret = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtAnneAd = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAileAdres = new System.Windows.Forms.RichTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtBabaAd = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtAnneTel = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtBabaTel = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtsınıf = new System.Windows.Forms.TextBox();
            this.txtOkul = new System.Windows.Forms.TextBox();
            this.txtadres = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtbolum = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtdogumtarih = new System.Windows.Forms.TextBox();
            this.txtozeldurum = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txttel = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txttc = new System.Windows.Forms.TextBox();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.ogrenciödemeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.toolStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ogrenciödemeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton5,
            this.toolStripSplitButton1,
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton6});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1269, 47);
            this.toolStrip1.TabIndex = 32;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.ForeColor = System.Drawing.Color.White;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(103, 44);
            this.toolStripButton5.Text = "Ana Sayfa";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yazOkuluKaydıToolStripMenuItem,
            this.normalKayıtToolStripMenuItem,
            this.çalışanKaydıToolStripMenuItem});
            this.toolStripSplitButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(114, 44);
            this.toolStripSplitButton1.Text = "Yeni Kayıt";
            // 
            // yazOkuluKaydıToolStripMenuItem
            // 
            this.yazOkuluKaydıToolStripMenuItem.Name = "yazOkuluKaydıToolStripMenuItem";
            this.yazOkuluKaydıToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.yazOkuluKaydıToolStripMenuItem.Text = "Yaz Okulu Kaydı";
            this.yazOkuluKaydıToolStripMenuItem.Click += new System.EventHandler(this.yazOkuluKaydıToolStripMenuItem_Click);
            // 
            // normalKayıtToolStripMenuItem
            // 
            this.normalKayıtToolStripMenuItem.Name = "normalKayıtToolStripMenuItem";
            this.normalKayıtToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.normalKayıtToolStripMenuItem.Text = "Normal Kayıt";
            // 
            // çalışanKaydıToolStripMenuItem
            // 
            this.çalışanKaydıToolStripMenuItem.Name = "çalışanKaydıToolStripMenuItem";
            this.çalışanKaydıToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.çalışanKaydıToolStripMenuItem.Text = "Çalışan Kaydı";
            this.çalışanKaydıToolStripMenuItem.Click += new System.EventHandler(this.çalışanKaydıToolStripMenuItem_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.ForeColor = System.Drawing.Color.White;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(109, 44);
            this.toolStripButton2.Text = "Kayıt Silme";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(102, 44);
            this.toolStripButton1.Text = "Çalışanlar";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.ForeColor = System.Drawing.Color.White;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(108, 44);
            this.toolStripButton3.Text = "Gelir-Gider";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.ForeColor = System.Drawing.Color.White;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(144, 44);
            this.toolStripButton4.Text = "Çamaşır Makinesi";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.ForeColor = System.Drawing.Color.White;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(107, 44);
            this.toolStripButton6.Text = "Kişi Arama";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.panel1.CausesValidation = false;
            this.panel1.Controls.Add(this.button25);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel1.Location = new System.Drawing.Point(19, 50);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1238, 724);
            this.panel1.TabIndex = 33;
            // 
            // button25
            // 
            this.button25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button25.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button25.ForeColor = System.Drawing.Color.White;
            this.button25.Location = new System.Drawing.Point(890, 615);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(145, 39);
            this.button25.TabIndex = 147;
            this.button25.Text = "Kaydet";
            this.button25.UseVisualStyleBackColor = false;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel6.Controls.Add(this.label40);
            this.panel6.Location = new System.Drawing.Point(601, 46);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(618, 30);
            this.panel6.TabIndex = 146;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(171, 6);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(208, 25);
            this.label40.TabIndex = 28;
            this.label40.Text = "ÖDEME BİLGİLERİ";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble;
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.08487F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.08487F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.08487F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.8282F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.63857F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.88756F));
            this.tableLayoutPanel1.Controls.Add(this.kalan12, 2, 12);
            this.tableLayoutPanel1.Controls.Add(this.kalan11, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.button19, 5, 12);
            this.tableLayoutPanel1.Controls.Add(this.ödenen12, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.button20, 5, 11);
            this.tableLayoutPanel1.Controls.Add(this.kalan10, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.button21, 5, 10);
            this.tableLayoutPanel1.Controls.Add(this.label41, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.button22, 5, 9);
            this.tableLayoutPanel1.Controls.Add(this.kalan9, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.button23, 5, 8);
            this.tableLayoutPanel1.Controls.Add(this.label42, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.button24, 5, 7);
            this.tableLayoutPanel1.Controls.Add(this.kalan8, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.button13, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.ödenen11, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.button14, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.kalan7, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.button15, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.button16, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.label43, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.button17, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.label44, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.button18, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.ödenen10, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.label25, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label16, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.ödenen9, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.label30, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label26, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label32, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.button11, 4, 12);
            this.tableLayoutPanel1.Controls.Add(this.label31, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.button12, 4, 11);
            this.tableLayoutPanel1.Controls.Add(this.ödenen2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.button9, 4, 10);
            this.tableLayoutPanel1.Controls.Add(this.ödenen4, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.button10, 4, 9);
            this.tableLayoutPanel1.Controls.Add(this.kalan6, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.button7, 4, 8);
            this.tableLayoutPanel1.Controls.Add(this.ödenen5, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.button8, 4, 7);
            this.tableLayoutPanel1.Controls.Add(this.kalan5, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.button5, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.ödenen3, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.button6, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.kalan4, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.button3, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.ödenen6, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.button4, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.kalan3, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.button2, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.kalan1, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.button1, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox11, 3, 12);
            this.tableLayoutPanel1.Controls.Add(this.kalan2, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox12, 3, 11);
            this.tableLayoutPanel1.Controls.Add(this.label51, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.textBox5, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.textBox9, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.textBox6, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.label50, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.textBox7, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.textBox10, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBox8, 3, 7);
            this.tableLayoutPanel1.Controls.Add(this.label49, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.label48, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.label47, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.label46, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.label56, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.textBox3, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.ödenen8, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.textBox4, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.label52, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.textBox2, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox1, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.label45, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label53, 5, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(599, 76);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 13;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.692308F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(620, 492);
            this.tableLayoutPanel1.TabIndex = 145;
            // 
            // kalan12
            // 
            this.kalan12.AutoSize = true;
            this.kalan12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kalan12.ForeColor = System.Drawing.Color.White;
            this.kalan12.Location = new System.Drawing.Point(192, 447);
            this.kalan12.Name = "kalan12";
            this.kalan12.Size = new System.Drawing.Size(48, 13);
            this.kalan12.TabIndex = 167;
            this.kalan12.Text = "label58";
            this.kalan12.Click += new System.EventHandler(this.kalan12_Click);
            // 
            // kalan11
            // 
            this.kalan11.AutoSize = true;
            this.kalan11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kalan11.ForeColor = System.Drawing.Color.White;
            this.kalan11.Location = new System.Drawing.Point(192, 410);
            this.kalan11.Name = "kalan11";
            this.kalan11.Size = new System.Drawing.Size(48, 13);
            this.kalan11.TabIndex = 165;
            this.kalan11.Text = "label60";
            this.kalan11.Click += new System.EventHandler(this.kalan11_Click);
            // 
            // button19
            // 
            this.button19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button19.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button19.ForeColor = System.Drawing.Color.White;
            this.button19.Location = new System.Drawing.Point(525, 457);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(74, 21);
            this.button19.TabIndex = 138;
            this.button19.Text = "Bankadan";
            this.button19.UseVisualStyleBackColor = false;
            // 
            // ödenen12
            // 
            this.ödenen12.AutoSize = true;
            this.ödenen12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ödenen12.ForeColor = System.Drawing.Color.White;
            this.ödenen12.Location = new System.Drawing.Point(99, 410);
            this.ödenen12.Name = "ödenen12";
            this.ödenen12.Size = new System.Drawing.Size(48, 13);
            this.ödenen12.TabIndex = 166;
            this.ödenen12.Text = "label59";
            this.ödenen12.Click += new System.EventHandler(this.ödenen12_Click);
            // 
            // button20
            // 
            this.button20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button20.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button20.ForeColor = System.Drawing.Color.White;
            this.button20.Location = new System.Drawing.Point(525, 417);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(74, 20);
            this.button20.TabIndex = 137;
            this.button20.Text = "Bankadan";
            this.button20.UseVisualStyleBackColor = false;
            // 
            // kalan10
            // 
            this.kalan10.AutoSize = true;
            this.kalan10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kalan10.ForeColor = System.Drawing.Color.White;
            this.kalan10.Location = new System.Drawing.Point(192, 373);
            this.kalan10.Name = "kalan10";
            this.kalan10.Size = new System.Drawing.Size(48, 13);
            this.kalan10.TabIndex = 163;
            this.kalan10.Text = "label62";
            this.kalan10.Click += new System.EventHandler(this.kalan10_Click);
            // 
            // button21
            // 
            this.button21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button21.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button21.ForeColor = System.Drawing.Color.White;
            this.button21.Location = new System.Drawing.Point(525, 380);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(74, 20);
            this.button21.TabIndex = 136;
            this.button21.Text = "Bankadan";
            this.button21.UseVisualStyleBackColor = false;
            // 
            // label41
            // 
            this.label41.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label41.ForeColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(25, 11);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(45, 18);
            this.label41.TabIndex = 29;
            this.label41.Text = "Aylar";
            // 
            // button22
            // 
            this.button22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button22.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button22.ForeColor = System.Drawing.Color.White;
            this.button22.Location = new System.Drawing.Point(525, 343);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(74, 20);
            this.button22.TabIndex = 135;
            this.button22.Text = "Bankadan";
            this.button22.UseVisualStyleBackColor = false;
            // 
            // kalan9
            // 
            this.kalan9.AutoSize = true;
            this.kalan9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kalan9.ForeColor = System.Drawing.Color.White;
            this.kalan9.Location = new System.Drawing.Point(192, 336);
            this.kalan9.Name = "kalan9";
            this.kalan9.Size = new System.Drawing.Size(48, 13);
            this.kalan9.TabIndex = 161;
            this.kalan9.Text = "label64";
            this.kalan9.Click += new System.EventHandler(this.kalan9_Click);
            // 
            // button23
            // 
            this.button23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button23.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button23.ForeColor = System.Drawing.Color.White;
            this.button23.Location = new System.Drawing.Point(525, 306);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(74, 20);
            this.button23.TabIndex = 134;
            this.button23.Text = "Bankadan";
            this.button23.UseVisualStyleBackColor = false;
            // 
            // label42
            // 
            this.label42.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label42.ForeColor = System.Drawing.Color.White;
            this.label42.Location = new System.Drawing.Point(108, 11);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(66, 18);
            this.label42.TabIndex = 31;
            this.label42.Text = "Ödenen";
            // 
            // button24
            // 
            this.button24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button24.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button24.ForeColor = System.Drawing.Color.White;
            this.button24.Location = new System.Drawing.Point(525, 269);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(74, 20);
            this.button24.TabIndex = 133;
            this.button24.Text = "Bankadan";
            this.button24.UseVisualStyleBackColor = false;
            // 
            // kalan8
            // 
            this.kalan8.AutoSize = true;
            this.kalan8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kalan8.ForeColor = System.Drawing.Color.White;
            this.kalan8.Location = new System.Drawing.Point(192, 299);
            this.kalan8.Name = "kalan8";
            this.kalan8.Size = new System.Drawing.Size(48, 13);
            this.kalan8.TabIndex = 159;
            this.kalan8.Text = "label66";
            this.kalan8.Click += new System.EventHandler(this.kalan8_Click);
            // 
            // button13
            // 
            this.button13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button13.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(525, 232);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(74, 20);
            this.button13.TabIndex = 132;
            this.button13.Text = "Bankadan";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // ödenen11
            // 
            this.ödenen11.AutoSize = true;
            this.ödenen11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ödenen11.ForeColor = System.Drawing.Color.White;
            this.ödenen11.Location = new System.Drawing.Point(99, 373);
            this.ödenen11.Name = "ödenen11";
            this.ödenen11.Size = new System.Drawing.Size(48, 13);
            this.ödenen11.TabIndex = 164;
            this.ödenen11.Text = "label61";
            this.ödenen11.Click += new System.EventHandler(this.ödenen11_Click);
            // 
            // button14
            // 
            this.button14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button14.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(525, 195);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(74, 20);
            this.button14.TabIndex = 131;
            this.button14.Text = "Bankadan";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // kalan7
            // 
            this.kalan7.AutoSize = true;
            this.kalan7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kalan7.ForeColor = System.Drawing.Color.White;
            this.kalan7.Location = new System.Drawing.Point(192, 262);
            this.kalan7.Name = "kalan7";
            this.kalan7.Size = new System.Drawing.Size(48, 13);
            this.kalan7.TabIndex = 157;
            this.kalan7.Text = "label68";
            this.kalan7.Click += new System.EventHandler(this.kalan7_Click);
            // 
            // button15
            // 
            this.button15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button15.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button15.ForeColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(525, 158);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(74, 20);
            this.button15.TabIndex = 130;
            this.button15.Text = "Bankadan";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button16.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button16.ForeColor = System.Drawing.Color.White;
            this.button16.Location = new System.Drawing.Point(525, 121);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(74, 20);
            this.button16.TabIndex = 129;
            this.button16.Text = "Bankadan";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // label43
            // 
            this.label43.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(209, 11);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(50, 18);
            this.label43.TabIndex = 30;
            this.label43.Text = "Kalan";
            // 
            // button17
            // 
            this.button17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button17.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button17.ForeColor = System.Drawing.Color.White;
            this.button17.Location = new System.Drawing.Point(525, 84);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(74, 20);
            this.button17.TabIndex = 128;
            this.button17.Text = "Bankadan";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // label44
            // 
            this.label44.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(312, 11);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(47, 18);
            this.label44.TabIndex = 32;
            this.label44.Text = "Tutar";
            this.label44.Click += new System.EventHandler(this.label44_Click);
            // 
            // button18
            // 
            this.button18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button18.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button18.ForeColor = System.Drawing.Color.White;
            this.button18.Location = new System.Drawing.Point(525, 47);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(74, 20);
            this.button18.TabIndex = 127;
            this.button18.Text = "Bankadan";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // ödenen10
            // 
            this.ödenen10.AutoSize = true;
            this.ödenen10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ödenen10.ForeColor = System.Drawing.Color.White;
            this.ödenen10.Location = new System.Drawing.Point(99, 336);
            this.ödenen10.Name = "ödenen10";
            this.ödenen10.Size = new System.Drawing.Size(48, 13);
            this.ödenen10.TabIndex = 162;
            this.ödenen10.Text = "label63";
            // 
            // label25
            // 
            this.label25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(26, 49);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(44, 16);
            this.label25.TabIndex = 63;
            this.label25.Text = "Ocak";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(24, 86);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 16);
            this.label16.TabIndex = 68;
            this.label16.Text = "Şubat";
            // 
            // ödenen9
            // 
            this.ödenen9.AutoSize = true;
            this.ödenen9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ödenen9.ForeColor = System.Drawing.Color.White;
            this.ödenen9.Location = new System.Drawing.Point(99, 299);
            this.ödenen9.Name = "ödenen9";
            this.ödenen9.Size = new System.Drawing.Size(48, 13);
            this.ödenen9.TabIndex = 160;
            this.ödenen9.Text = "label65";
            // 
            // label30
            // 
            this.label30.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(29, 123);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(38, 16);
            this.label30.TabIndex = 69;
            this.label30.Text = "Mart";
            // 
            // label26
            // 
            this.label26.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(24, 160);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(48, 16);
            this.label26.TabIndex = 70;
            this.label26.Text = "Nisan";
            // 
            // label32
            // 
            this.label32.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(23, 197);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(49, 16);
            this.label32.TabIndex = 71;
            this.label32.Text = "Mayıs";
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // button11
            // 
            this.button11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button11.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(422, 456);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(51, 23);
            this.button11.TabIndex = 126;
            this.button11.Text = "Elden";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // label31
            // 
            this.label31.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(17, 234);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(61, 16);
            this.label31.TabIndex = 72;
            this.label31.Text = "Haziran";
            // 
            // button12
            // 
            this.button12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(422, 417);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(51, 20);
            this.button12.TabIndex = 125;
            this.button12.Text = "Elden";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // ödenen2
            // 
            this.ödenen2.AutoSize = true;
            this.ödenen2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ödenen2.ForeColor = System.Drawing.Color.White;
            this.ödenen2.Location = new System.Drawing.Point(99, 40);
            this.ödenen2.Name = "ödenen2";
            this.ödenen2.Size = new System.Drawing.Size(48, 13);
            this.ödenen2.TabIndex = 146;
            this.ödenen2.Text = "label43";
            this.ödenen2.Click += new System.EventHandler(this.ödenen2_Click);
            // 
            // button9
            // 
            this.button9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(422, 380);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(51, 20);
            this.button9.TabIndex = 124;
            this.button9.Text = "Elden";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // ödenen4
            // 
            this.ödenen4.AutoSize = true;
            this.ödenen4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ödenen4.ForeColor = System.Drawing.Color.White;
            this.ödenen4.Location = new System.Drawing.Point(99, 77);
            this.ödenen4.Name = "ödenen4";
            this.ödenen4.Size = new System.Drawing.Size(48, 13);
            this.ödenen4.TabIndex = 150;
            this.ödenen4.Text = "label45";
            // 
            // button10
            // 
            this.button10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button10.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(422, 343);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(51, 20);
            this.button10.TabIndex = 123;
            this.button10.Text = "Elden";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // kalan6
            // 
            this.kalan6.AutoSize = true;
            this.kalan6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kalan6.ForeColor = System.Drawing.Color.White;
            this.kalan6.Location = new System.Drawing.Point(192, 225);
            this.kalan6.Name = "kalan6";
            this.kalan6.Size = new System.Drawing.Size(48, 13);
            this.kalan6.TabIndex = 155;
            this.kalan6.Text = "label54";
            this.kalan6.Click += new System.EventHandler(this.kalan6_Click);
            // 
            // button7
            // 
            this.button7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(422, 306);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(51, 20);
            this.button7.TabIndex = 122;
            this.button7.Text = "Elden";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // ödenen5
            // 
            this.ödenen5.AutoSize = true;
            this.ödenen5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ödenen5.ForeColor = System.Drawing.Color.White;
            this.ödenen5.Location = new System.Drawing.Point(99, 114);
            this.ödenen5.Name = "ödenen5";
            this.ödenen5.Size = new System.Drawing.Size(48, 13);
            this.ödenen5.TabIndex = 152;
            this.ödenen5.Text = "label57";
            // 
            // button8
            // 
            this.button8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(422, 269);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(51, 20);
            this.button8.TabIndex = 121;
            this.button8.Text = "Elden";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // kalan5
            // 
            this.kalan5.AutoSize = true;
            this.kalan5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kalan5.ForeColor = System.Drawing.Color.White;
            this.kalan5.Location = new System.Drawing.Point(192, 188);
            this.kalan5.Name = "kalan5";
            this.kalan5.Size = new System.Drawing.Size(48, 13);
            this.kalan5.TabIndex = 153;
            this.kalan5.Text = "label56";
            // 
            // button5
            // 
            this.button5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(421, 232);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(53, 20);
            this.button5.TabIndex = 120;
            this.button5.Text = "Elden";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // ödenen3
            // 
            this.ödenen3.AutoSize = true;
            this.ödenen3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ödenen3.ForeColor = System.Drawing.Color.White;
            this.ödenen3.Location = new System.Drawing.Point(99, 151);
            this.ödenen3.Name = "ödenen3";
            this.ödenen3.Size = new System.Drawing.Size(48, 13);
            this.ödenen3.TabIndex = 148;
            this.ödenen3.Text = "label53";
            // 
            // button6
            // 
            this.button6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(421, 195);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(53, 20);
            this.button6.TabIndex = 119;
            this.button6.Text = "Elden";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // kalan4
            // 
            this.kalan4.AutoSize = true;
            this.kalan4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kalan4.ForeColor = System.Drawing.Color.White;
            this.kalan4.Location = new System.Drawing.Point(192, 151);
            this.kalan4.Name = "kalan4";
            this.kalan4.Size = new System.Drawing.Size(48, 13);
            this.kalan4.TabIndex = 151;
            this.kalan4.Text = "label44";
            // 
            // button3
            // 
            this.button3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(421, 158);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(53, 20);
            this.button3.TabIndex = 118;
            this.button3.Text = "Elden";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // ödenen6
            // 
            this.ödenen6.AutoSize = true;
            this.ödenen6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ödenen6.ForeColor = System.Drawing.Color.White;
            this.ödenen6.Location = new System.Drawing.Point(99, 188);
            this.ödenen6.Name = "ödenen6";
            this.ödenen6.Size = new System.Drawing.Size(48, 13);
            this.ödenen6.TabIndex = 154;
            this.ödenen6.Text = "label55";
            // 
            // button4
            // 
            this.button4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(421, 121);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(53, 20);
            this.button4.TabIndex = 117;
            this.button4.Text = "Elden";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // kalan3
            // 
            this.kalan3.AutoSize = true;
            this.kalan3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kalan3.ForeColor = System.Drawing.Color.White;
            this.kalan3.Location = new System.Drawing.Point(192, 114);
            this.kalan3.Name = "kalan3";
            this.kalan3.Size = new System.Drawing.Size(48, 13);
            this.kalan3.TabIndex = 149;
            this.kalan3.Text = "label52";
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(421, 84);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(53, 20);
            this.button2.TabIndex = 116;
            this.button2.Text = "Elden";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // kalan1
            // 
            this.kalan1.AutoSize = true;
            this.kalan1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kalan1.ForeColor = System.Drawing.Color.White;
            this.kalan1.Location = new System.Drawing.Point(192, 40);
            this.kalan1.Name = "kalan1";
            this.kalan1.Size = new System.Drawing.Size(45, 13);
            this.kalan1.TabIndex = 145;
            this.kalan1.Text = "kalan1";
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(421, 47);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(53, 20);
            this.button1.TabIndex = 115;
            this.button1.Text = "Elden";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // textBox11
            // 
            this.textBox11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox11.Location = new System.Drawing.Point(305, 458);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(60, 20);
            this.textBox11.TabIndex = 114;
            // 
            // kalan2
            // 
            this.kalan2.AutoSize = true;
            this.kalan2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.kalan2.ForeColor = System.Drawing.Color.White;
            this.kalan2.Location = new System.Drawing.Point(192, 77);
            this.kalan2.Name = "kalan2";
            this.kalan2.Size = new System.Drawing.Size(48, 13);
            this.kalan2.TabIndex = 147;
            this.kalan2.Text = "label42";
            // 
            // textBox12
            // 
            this.textBox12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox12.Location = new System.Drawing.Point(305, 417);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(60, 20);
            this.textBox12.TabIndex = 113;
            // 
            // label51
            // 
            this.label51.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label51.ForeColor = System.Drawing.Color.White;
            this.label51.Location = new System.Drawing.Point(15, 271);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(66, 16);
            this.label51.TabIndex = 156;
            this.label51.Text = "Temmuz";
            // 
            // textBox5
            // 
            this.textBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox5.Location = new System.Drawing.Point(305, 380);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(60, 20);
            this.textBox5.TabIndex = 110;
            // 
            // textBox9
            // 
            this.textBox9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox9.Location = new System.Drawing.Point(305, 232);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(60, 20);
            this.textBox9.TabIndex = 112;
            // 
            // textBox6
            // 
            this.textBox6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox6.Location = new System.Drawing.Point(305, 343);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(60, 20);
            this.textBox6.TabIndex = 109;
            // 
            // label50
            // 
            this.label50.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label50.ForeColor = System.Drawing.Color.White;
            this.label50.Location = new System.Drawing.Point(16, 308);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(64, 16);
            this.label50.TabIndex = 157;
            this.label50.Text = "Ağustos";
            // 
            // textBox7
            // 
            this.textBox7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox7.Location = new System.Drawing.Point(305, 306);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(60, 20);
            this.textBox7.TabIndex = 108;
            // 
            // textBox10
            // 
            this.textBox10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox10.Location = new System.Drawing.Point(305, 195);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(60, 20);
            this.textBox10.TabIndex = 111;
            // 
            // textBox8
            // 
            this.textBox8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox8.Location = new System.Drawing.Point(305, 269);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(60, 20);
            this.textBox8.TabIndex = 107;
            // 
            // label49
            // 
            this.label49.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label49.ForeColor = System.Drawing.Color.White;
            this.label49.Location = new System.Drawing.Point(27, 345);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(42, 16);
            this.label49.TabIndex = 158;
            this.label49.Text = "Eylül";
            // 
            // label48
            // 
            this.label48.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label48.ForeColor = System.Drawing.Color.White;
            this.label48.Location = new System.Drawing.Point(27, 382);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(42, 16);
            this.label48.TabIndex = 159;
            this.label48.Text = "Ekim";
            // 
            // label47
            // 
            this.label47.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label47.ForeColor = System.Drawing.Color.White;
            this.label47.Location = new System.Drawing.Point(23, 419);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(50, 16);
            this.label47.TabIndex = 160;
            this.label47.Text = "Kasım";
            // 
            // label46
            // 
            this.label46.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label46.ForeColor = System.Drawing.Color.White;
            this.label46.Location = new System.Drawing.Point(24, 460);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(48, 16);
            this.label46.TabIndex = 161;
            this.label46.Text = "Aralık";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label56.ForeColor = System.Drawing.Color.White;
            this.label56.Location = new System.Drawing.Point(99, 225);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(48, 13);
            this.label56.TabIndex = 167;
            this.label56.Text = "label69";
            // 
            // textBox3
            // 
            this.textBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox3.Location = new System.Drawing.Point(305, 158);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(60, 20);
            this.textBox3.TabIndex = 106;
            // 
            // ödenen8
            // 
            this.ödenen8.AutoSize = true;
            this.ödenen8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.ödenen8.ForeColor = System.Drawing.Color.White;
            this.ödenen8.Location = new System.Drawing.Point(99, 262);
            this.ödenen8.Name = "ödenen8";
            this.ödenen8.Size = new System.Drawing.Size(48, 13);
            this.ödenen8.TabIndex = 158;
            this.ödenen8.Text = "label67";
            // 
            // textBox4
            // 
            this.textBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox4.Location = new System.Drawing.Point(305, 121);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(60, 20);
            this.textBox4.TabIndex = 105;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label52.ForeColor = System.Drawing.Color.White;
            this.label52.Location = new System.Drawing.Point(99, 447);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(48, 13);
            this.label52.TabIndex = 169;
            this.label52.Text = "label59";
            this.label52.Click += new System.EventHandler(this.label52_Click);
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox2.Location = new System.Drawing.Point(305, 84);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(60, 20);
            this.textBox2.TabIndex = 104;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox1.Location = new System.Drawing.Point(305, 47);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(60, 20);
            this.textBox1.TabIndex = 103;
            // 
            // label45
            // 
            this.label45.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label45.ForeColor = System.Drawing.Color.White;
            this.label45.Location = new System.Drawing.Point(395, 11);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(102, 18);
            this.label45.TabIndex = 170;
            this.label45.Text = "Ödeme şekli";
            // 
            // label53
            // 
            this.label53.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label53.ForeColor = System.Drawing.Color.White;
            this.label53.Location = new System.Drawing.Point(510, 11);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(102, 18);
            this.label53.TabIndex = 171;
            this.label53.Text = "Ödeme şekli";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel7.Controls.Add(this.label7);
            this.panel7.Location = new System.Drawing.Point(2, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1247, 37);
            this.panel7.TabIndex = 82;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(496, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 25);
            this.label7.TabIndex = 28;
            this.label7.Text = "KİŞİ BİLGİLERİ";
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel4.Controls.Add(this.txtBasTarih);
            this.panel4.Controls.Add(this.txtSonTarih);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.txtIban);
            this.panel4.Controls.Add(this.label28);
            this.panel4.Controls.Add(this.txtDepozito);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.txtAylıkUcret);
            this.panel4.Controls.Add(this.label24);
            this.panel4.Controls.Add(this.label29);
            this.panel4.Location = new System.Drawing.Point(35, 525);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(545, 159);
            this.panel4.TabIndex = 77;
            // 
            // txtBasTarih
            // 
            this.txtBasTarih.Location = new System.Drawing.Point(130, 23);
            this.txtBasTarih.Name = "txtBasTarih";
            this.txtBasTarih.Size = new System.Drawing.Size(134, 20);
            this.txtBasTarih.TabIndex = 69;
            // 
            // txtSonTarih
            // 
            this.txtSonTarih.Location = new System.Drawing.Point(130, 49);
            this.txtSonTarih.Name = "txtSonTarih";
            this.txtSonTarih.Size = new System.Drawing.Size(134, 20);
            this.txtSonTarih.TabIndex = 68;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(1, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(178, 24);
            this.label9.TabIndex = 67;
            this.label9.Text = "SENET BİLGİLERİ";
            // 
            // txtIban
            // 
            this.txtIban.Location = new System.Drawing.Point(130, 75);
            this.txtIban.Name = "txtIban";
            this.txtIban.Size = new System.Drawing.Size(134, 20);
            this.txtIban.TabIndex = 66;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(2, 70);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(108, 16);
            this.label28.TabIndex = 65;
            this.label28.Text = "Iban Numarası";
            // 
            // txtDepozito
            // 
            this.txtDepozito.Location = new System.Drawing.Point(130, 127);
            this.txtDepozito.Name = "txtDepozito";
            this.txtDepozito.Size = new System.Drawing.Size(134, 20);
            this.txtDepozito.TabIndex = 64;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(3, 121);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(115, 16);
            this.label21.TabIndex = 63;
            this.label21.Text = "Depozito Ücreti";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(3, 46);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(82, 16);
            this.label22.TabIndex = 59;
            this.label22.Text = "Bitiş Tarihi";
            // 
            // txtAylıkUcret
            // 
            this.txtAylıkUcret.Location = new System.Drawing.Point(130, 101);
            this.txtAylıkUcret.Name = "txtAylıkUcret";
            this.txtAylıkUcret.Size = new System.Drawing.Size(134, 20);
            this.txtAylıkUcret.TabIndex = 60;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(3, 101);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(83, 16);
            this.label24.TabIndex = 58;
            this.label24.Text = "Aylık Ücret";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(3, 24);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(121, 16);
            this.label29.TabIndex = 57;
            this.label29.Text = "Başlangıç Tarihi";
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.Controls.Add(this.textBox15);
            this.panel2.Controls.Add(this.label34);
            this.panel2.Controls.Add(this.textBox14);
            this.panel2.Controls.Add(this.label33);
            this.panel2.Controls.Add(this.txtAnneAd);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.txtAileAdres);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.txtBabaAd);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.txtAnneTel);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.txtBabaTel);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Location = new System.Drawing.Point(35, 314);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(545, 202);
            this.panel2.TabIndex = 77;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(373, 59);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(160, 20);
            this.textBox15.TabIndex = 66;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(273, 59);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(70, 16);
            this.label34.TabIndex = 65;
            this.label34.Text = "Anne Adı";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(373, 33);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(160, 20);
            this.textBox14.TabIndex = 64;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(273, 33);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(70, 16);
            this.label33.TabIndex = 63;
            this.label33.Text = "Anne Adı";
            // 
            // txtAnneAd
            // 
            this.txtAnneAd.Location = new System.Drawing.Point(107, 33);
            this.txtAnneAd.Name = "txtAnneAd";
            this.txtAnneAd.Size = new System.Drawing.Size(160, 20);
            this.txtAnneAd.TabIndex = 62;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(3, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 24);
            this.label5.TabIndex = 61;
            this.label5.Text = "AİLE BİLGİLERİ";
            // 
            // txtAileAdres
            // 
            this.txtAileAdres.Location = new System.Drawing.Point(107, 133);
            this.txtAileAdres.Name = "txtAileAdres";
            this.txtAileAdres.Size = new System.Drawing.Size(160, 56);
            this.txtAileAdres.TabIndex = 60;
            this.txtAileAdres.Text = "";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(7, 132);
            this.label18.Name = "label18";
            this.label18.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label18.Size = new System.Drawing.Size(49, 16);
            this.label18.TabIndex = 59;
            this.label18.Text = "Adres";
            // 
            // txtBabaAd
            // 
            this.txtBabaAd.Location = new System.Drawing.Point(107, 59);
            this.txtBabaAd.Name = "txtBabaAd";
            this.txtBabaAd.Size = new System.Drawing.Size(160, 20);
            this.txtBabaAd.TabIndex = 58;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(7, 56);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(72, 16);
            this.label23.TabIndex = 55;
            this.label23.Text = "Baba Adı";
            // 
            // txtAnneTel
            // 
            this.txtAnneTel.Location = new System.Drawing.Point(107, 81);
            this.txtAnneTel.Name = "txtAnneTel";
            this.txtAnneTel.Size = new System.Drawing.Size(160, 20);
            this.txtAnneTel.TabIndex = 57;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(7, 78);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(94, 16);
            this.label20.TabIndex = 54;
            this.label20.Text = "Anne Tel No";
            // 
            // txtBabaTel
            // 
            this.txtBabaTel.Location = new System.Drawing.Point(107, 107);
            this.txtBabaTel.Name = "txtBabaTel";
            this.txtBabaTel.Size = new System.Drawing.Size(160, 20);
            this.txtBabaTel.TabIndex = 56;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(7, 104);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 16);
            this.label6.TabIndex = 53;
            this.label6.Text = "Baba Tel No";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(7, 33);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(70, 16);
            this.label27.TabIndex = 52;
            this.label27.Text = "Anne Adı";
            // 
            // panel3
            // 
            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel3.Controls.Add(this.textBox13);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.txtsınıf);
            this.panel3.Controls.Add(this.txtOkul);
            this.panel3.Controls.Add(this.txtadres);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.txtbolum);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.txtdogumtarih);
            this.panel3.Controls.Add(this.txtozeldurum);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.txttel);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.txttc);
            this.panel3.Controls.Add(this.txtSoyad);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.txtAd);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Location = new System.Drawing.Point(35, 46);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(545, 260);
            this.panel3.TabIndex = 76;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(114, 85);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(172, 20);
            this.textBox13.TabIndex = 98;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(3, 91);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 16);
            this.label15.TabIndex = 97;
            this.label15.Text = "Uyruk:";
            // 
            // txtsınıf
            // 
            this.txtsınıf.Location = new System.Drawing.Point(355, 91);
            this.txtsınıf.Name = "txtsınıf";
            this.txtsınıf.Size = new System.Drawing.Size(170, 20);
            this.txtsınıf.TabIndex = 96;
            // 
            // txtOkul
            // 
            this.txtOkul.Location = new System.Drawing.Point(355, 31);
            this.txtOkul.Name = "txtOkul";
            this.txtOkul.Size = new System.Drawing.Size(170, 20);
            this.txtOkul.TabIndex = 95;
            // 
            // txtadres
            // 
            this.txtadres.Location = new System.Drawing.Point(355, 117);
            this.txtadres.Name = "txtadres";
            this.txtadres.Size = new System.Drawing.Size(170, 84);
            this.txtadres.TabIndex = 94;
            this.txtadres.Text = "";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(289, 117);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(53, 16);
            this.label10.TabIndex = 93;
            this.label10.Text = "Adres:";
            // 
            // txtbolum
            // 
            this.txtbolum.Location = new System.Drawing.Point(355, 60);
            this.txtbolum.Name = "txtbolum";
            this.txtbolum.Size = new System.Drawing.Size(170, 20);
            this.txtbolum.TabIndex = 91;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(291, 31);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 16);
            this.label13.TabIndex = 89;
            this.label13.Text = "Okulu:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(291, 61);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 16);
            this.label14.TabIndex = 90;
            this.label14.Text = "Bölümü:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(291, 90);
            this.label19.Name = "label19";
            this.label19.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label19.Size = new System.Drawing.Size(46, 16);
            this.label19.TabIndex = 88;
            this.label19.Text = "Sınıfı:";
            // 
            // txtdogumtarih
            // 
            this.txtdogumtarih.Location = new System.Drawing.Point(114, 139);
            this.txtdogumtarih.Name = "txtdogumtarih";
            this.txtdogumtarih.Size = new System.Drawing.Size(172, 20);
            this.txtdogumtarih.TabIndex = 87;
            // 
            // txtozeldurum
            // 
            this.txtozeldurum.Location = new System.Drawing.Point(114, 193);
            this.txtozeldurum.Name = "txtozeldurum";
            this.txtozeldurum.Size = new System.Drawing.Size(172, 44);
            this.txtozeldurum.TabIndex = 86;
            this.txtozeldurum.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(4, 195);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(91, 16);
            this.label1.TabIndex = 85;
            this.label1.Text = "Özel Durum:";
            // 
            // txttel
            // 
            this.txttel.Location = new System.Drawing.Point(114, 166);
            this.txttel.Name = "txttel";
            this.txttel.Size = new System.Drawing.Size(172, 20);
            this.txttel.TabIndex = 83;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(4, 169);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(89, 16);
            this.label2.TabIndex = 82;
            this.label2.Text = "Telefon No:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(4, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 16);
            this.label3.TabIndex = 78;
            this.label3.Text = "Soyadı:";
            // 
            // txttc
            // 
            this.txttc.Location = new System.Drawing.Point(114, 112);
            this.txttc.Name = "txttc";
            this.txttc.Size = new System.Drawing.Size(172, 20);
            this.txttc.TabIndex = 80;
            // 
            // txtSoyad
            // 
            this.txtSoyad.Location = new System.Drawing.Point(113, 58);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(172, 20);
            this.txtSoyad.TabIndex = 81;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(3, 117);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 16);
            this.label11.TabIndex = 79;
            this.label11.Text = "TC No:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(3, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 16);
            this.label4.TabIndex = 77;
            this.label4.Text = "Doğum Tarihi:";
            // 
            // txtAd
            // 
            this.txtAd.Location = new System.Drawing.Point(113, 31);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(172, 20);
            this.txtAd.TabIndex = 76;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(7, 41);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 16);
            this.label17.TabIndex = 75;
            this.label17.Text = "Adı:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(4, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(178, 24);
            this.label8.TabIndex = 74;
            this.label8.Text = "KİŞİSEL BİLGİLER";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(-302, 43);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "Soyadı";
            // 
            // ogrenciödemeBindingSource
            // 
            this.ogrenciödemeBindingSource.DataMember = "ogrenciödeme";
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // KisiBilgileri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1269, 749);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "KisiBilgileri";
            this.Text = "KisiBilgileri";
            this.Load += new System.EventHandler(this.KisiBilgileri_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ogrenciödemeBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem yazOkuluKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtdogumtarih;
        private System.Windows.Forms.RichTextBox txtozeldurum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txttel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txttc;
        private System.Windows.Forms.TextBox txtSoyad;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtAnneAd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox txtAileAdres;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtBabaAd;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtAnneTel;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtBabaTel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtsınıf;
        private System.Windows.Forms.TextBox txtOkul;
        private System.Windows.Forms.RichTextBox txtadres;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtbolum;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtBasTarih;
        private System.Windows.Forms.TextBox txtSonTarih;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtIban;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtDepozito;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtAylıkUcret;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label ödenen12;
        private System.Windows.Forms.Label kalan11;
        private System.Windows.Forms.Label ödenen11;
        private System.Windows.Forms.Label kalan10;
        private System.Windows.Forms.Label ödenen10;
        private System.Windows.Forms.Label kalan9;
        private System.Windows.Forms.Label ödenen9;
        private System.Windows.Forms.Label kalan8;
        private System.Windows.Forms.Label ödenen8;
        private System.Windows.Forms.Label kalan7;
        private System.Windows.Forms.Label kalan6;
        private System.Windows.Forms.Label ödenen6;
        private System.Windows.Forms.Label kalan5;
        private System.Windows.Forms.Label ödenen5;
        private System.Windows.Forms.Label kalan4;
        private System.Windows.Forms.Label ödenen4;
        private System.Windows.Forms.Label kalan3;
        private System.Windows.Forms.Label ödenen3;
        private System.Windows.Forms.Label kalan2;
        private System.Windows.Forms.Label ödenen2;
        private System.Windows.Forms.Label kalan1;
       
        private System.Windows.Forms.BindingSource ogrenciödemeBindingSource;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label kalan12;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.ToolStripMenuItem çalışanKaydıToolStripMenuItem;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
    }
}