﻿namespace ApartYönetimSistemi
{
    partial class KisiBilgileri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KisiBilgileri));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.yazOkuluKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.kalan12 = new System.Windows.Forms.Label();
            this.ödenen12 = new System.Windows.Forms.Label();
            this.kalan11 = new System.Windows.Forms.Label();
            this.ödenen11 = new System.Windows.Forms.Label();
            this.kalan10 = new System.Windows.Forms.Label();
            this.ödenen10 = new System.Windows.Forms.Label();
            this.kalan9 = new System.Windows.Forms.Label();
            this.ödenen9 = new System.Windows.Forms.Label();
            this.kalan8 = new System.Windows.Forms.Label();
            this.ödenen8 = new System.Windows.Forms.Label();
            this.kalan7 = new System.Windows.Forms.Label();
            this.ödenen7 = new System.Windows.Forms.Label();
            this.kalan6 = new System.Windows.Forms.Label();
            this.ödenen6 = new System.Windows.Forms.Label();
            this.kalan5 = new System.Windows.Forms.Label();
            this.ödenen5 = new System.Windows.Forms.Label();
            this.kalan4 = new System.Windows.Forms.Label();
            this.ödenen4 = new System.Windows.Forms.Label();
            this.kalan3 = new System.Windows.Forms.Label();
            this.ödenen3 = new System.Windows.Forms.Label();
            this.kalan2 = new System.Windows.Forms.Label();
            this.ödenen2 = new System.Windows.Forms.Label();
            this.kalan1 = new System.Windows.Forms.Label();
            this.ödenen1 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtBasTarih = new System.Windows.Forms.TextBox();
            this.txtSonTarih = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtIban = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtDepozito = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtAylıkUcret = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtAnneAd = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAileAdres = new System.Windows.Forms.RichTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtBabaAd = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtAnneTel = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtBabaTel = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtsınıf = new System.Windows.Forms.TextBox();
            this.txtOkul = new System.Windows.Forms.TextBox();
            this.txtadres = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtbolum = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtdogumtarih = new System.Windows.Forms.TextBox();
            this.txtozeldurum = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txttel = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txttc = new System.Windows.Forms.TextBox();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.ogrenciödemeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.apartYonetimSistemiDataSet = new ApartYönetimSistemi.ApartYonetimSistemiDataSet();
            this.ogrenciödemeTableAdapter = new ApartYönetimSistemi.ApartYonetimSistemiDataSetTableAdapters.ogrenciödemeTableAdapter();
            this.toolStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ogrenciödemeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(191)))), ((int)(((byte)(228)))));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton5,
            this.toolStripSplitButton1,
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripButton3,
            this.toolStripButton4});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1269, 25);
            this.toolStrip1.TabIndex = 32;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.ForeColor = System.Drawing.Color.White;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(79, 22);
            this.toolStripButton5.Text = "Ana Sayfa";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yazOkuluKaydıToolStripMenuItem,
            this.normalKayıtToolStripMenuItem});
            this.toolStripSplitButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(90, 22);
            this.toolStripSplitButton1.Text = "Yeni Kayıt";
            // 
            // yazOkuluKaydıToolStripMenuItem
            // 
            this.yazOkuluKaydıToolStripMenuItem.Name = "yazOkuluKaydıToolStripMenuItem";
            this.yazOkuluKaydıToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.yazOkuluKaydıToolStripMenuItem.Text = "Yaz Okulu Kaydı";
            this.yazOkuluKaydıToolStripMenuItem.Click += new System.EventHandler(this.yazOkuluKaydıToolStripMenuItem_Click);
            // 
            // normalKayıtToolStripMenuItem
            // 
            this.normalKayıtToolStripMenuItem.Name = "normalKayıtToolStripMenuItem";
            this.normalKayıtToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.normalKayıtToolStripMenuItem.Text = "Normal Kayıt";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.ForeColor = System.Drawing.Color.White;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(85, 22);
            this.toolStripButton2.Text = "Kayıt Silme";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(78, 22);
            this.toolStripButton1.Text = "Çalışanlar";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.ForeColor = System.Drawing.Color.White;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(84, 22);
            this.toolStripButton3.Text = "Gelir-Gider";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.ForeColor = System.Drawing.Color.White;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(120, 22);
            this.toolStripButton4.Text = "Çamaşır Makinesi";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.panel1.CausesValidation = false;
            this.panel1.Controls.Add(this.label39);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Location = new System.Drawing.Point(33, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1238, 724);
            this.panel1.TabIndex = 33;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label39.Location = new System.Drawing.Point(556, 592);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(597, 25);
            this.label39.TabIndex = 144;
            this.label39.Text = "Kişibilgilerine anne -baba meslek veuyruk ve dogumtarihi eklenecek";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel7.Controls.Add(this.label7);
            this.panel7.Location = new System.Drawing.Point(17, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1201, 37);
            this.panel7.TabIndex = 82;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(496, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 25);
            this.label7.TabIndex = 28;
            this.label7.Text = "KİŞİ BİLGİLERİ";
            // 
            // panel5
            // 
            this.panel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel5.Controls.Add(this.kalan12);
            this.panel5.Controls.Add(this.ödenen12);
            this.panel5.Controls.Add(this.kalan11);
            this.panel5.Controls.Add(this.ödenen11);
            this.panel5.Controls.Add(this.kalan10);
            this.panel5.Controls.Add(this.ödenen10);
            this.panel5.Controls.Add(this.kalan9);
            this.panel5.Controls.Add(this.ödenen9);
            this.panel5.Controls.Add(this.kalan8);
            this.panel5.Controls.Add(this.ödenen8);
            this.panel5.Controls.Add(this.kalan7);
            this.panel5.Controls.Add(this.ödenen7);
            this.panel5.Controls.Add(this.kalan6);
            this.panel5.Controls.Add(this.ödenen6);
            this.panel5.Controls.Add(this.kalan5);
            this.panel5.Controls.Add(this.ödenen5);
            this.panel5.Controls.Add(this.kalan4);
            this.panel5.Controls.Add(this.ödenen4);
            this.panel5.Controls.Add(this.kalan3);
            this.panel5.Controls.Add(this.ödenen3);
            this.panel5.Controls.Add(this.kalan2);
            this.panel5.Controls.Add(this.ödenen2);
            this.panel5.Controls.Add(this.kalan1);
            this.panel5.Controls.Add(this.ödenen1);
            this.panel5.Controls.Add(this.label38);
            this.panel5.Controls.Add(this.label37);
            this.panel5.Controls.Add(this.label36);
            this.panel5.Controls.Add(this.label35);
            this.panel5.Controls.Add(this.label34);
            this.panel5.Controls.Add(this.label33);
            this.panel5.Controls.Add(this.button19);
            this.panel5.Controls.Add(this.button20);
            this.panel5.Controls.Add(this.button21);
            this.panel5.Controls.Add(this.button22);
            this.panel5.Controls.Add(this.button23);
            this.panel5.Controls.Add(this.button24);
            this.panel5.Controls.Add(this.button13);
            this.panel5.Controls.Add(this.button14);
            this.panel5.Controls.Add(this.button15);
            this.panel5.Controls.Add(this.button16);
            this.panel5.Controls.Add(this.button17);
            this.panel5.Controls.Add(this.button18);
            this.panel5.Controls.Add(this.button11);
            this.panel5.Controls.Add(this.button12);
            this.panel5.Controls.Add(this.button9);
            this.panel5.Controls.Add(this.button10);
            this.panel5.Controls.Add(this.button7);
            this.panel5.Controls.Add(this.button8);
            this.panel5.Controls.Add(this.button5);
            this.panel5.Controls.Add(this.button6);
            this.panel5.Controls.Add(this.button3);
            this.panel5.Controls.Add(this.button4);
            this.panel5.Controls.Add(this.button2);
            this.panel5.Controls.Add(this.button1);
            this.panel5.Controls.Add(this.textBox11);
            this.panel5.Controls.Add(this.textBox12);
            this.panel5.Controls.Add(this.textBox9);
            this.panel5.Controls.Add(this.textBox10);
            this.panel5.Controls.Add(this.textBox5);
            this.panel5.Controls.Add(this.textBox6);
            this.panel5.Controls.Add(this.textBox7);
            this.panel5.Controls.Add(this.textBox8);
            this.panel5.Controls.Add(this.textBox3);
            this.panel5.Controls.Add(this.textBox4);
            this.panel5.Controls.Add(this.textBox2);
            this.panel5.Controls.Add(this.textBox1);
            this.panel5.Controls.Add(this.label46);
            this.panel5.Controls.Add(this.label47);
            this.panel5.Controls.Add(this.label48);
            this.panel5.Controls.Add(this.label49);
            this.panel5.Controls.Add(this.label50);
            this.panel5.Controls.Add(this.label51);
            this.panel5.Controls.Add(this.label31);
            this.panel5.Controls.Add(this.label32);
            this.panel5.Controls.Add(this.label26);
            this.panel5.Controls.Add(this.label30);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.label15);
            this.panel5.Controls.Add(this.label25);
            this.panel5.Location = new System.Drawing.Point(650, 46);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(528, 494);
            this.panel5.TabIndex = 78;
            // 
            // kalan12
            // 
            this.kalan12.AutoSize = true;
            this.kalan12.Location = new System.Drawing.Point(138, 396);
            this.kalan12.Name = "kalan12";
            this.kalan12.Size = new System.Drawing.Size(41, 13);
            this.kalan12.TabIndex = 167;
            this.kalan12.Text = "label58";
            // 
            // ödenen12
            // 
            this.ödenen12.AutoSize = true;
            this.ödenen12.Location = new System.Drawing.Point(64, 395);
            this.ödenen12.Name = "ödenen12";
            this.ödenen12.Size = new System.Drawing.Size(41, 13);
            this.ödenen12.TabIndex = 166;
            this.ödenen12.Text = "label59";
            // 
            // kalan11
            // 
            this.kalan11.AutoSize = true;
            this.kalan11.Location = new System.Drawing.Point(138, 368);
            this.kalan11.Name = "kalan11";
            this.kalan11.Size = new System.Drawing.Size(41, 13);
            this.kalan11.TabIndex = 165;
            this.kalan11.Text = "label60";
            // 
            // ödenen11
            // 
            this.ödenen11.AutoSize = true;
            this.ödenen11.Location = new System.Drawing.Point(64, 367);
            this.ödenen11.Name = "ödenen11";
            this.ödenen11.Size = new System.Drawing.Size(41, 13);
            this.ödenen11.TabIndex = 164;
            this.ödenen11.Text = "label61";
            // 
            // kalan10
            // 
            this.kalan10.AutoSize = true;
            this.kalan10.Location = new System.Drawing.Point(138, 342);
            this.kalan10.Name = "kalan10";
            this.kalan10.Size = new System.Drawing.Size(41, 13);
            this.kalan10.TabIndex = 163;
            this.kalan10.Text = "label62";
            // 
            // ödenen10
            // 
            this.ödenen10.AutoSize = true;
            this.ödenen10.Location = new System.Drawing.Point(64, 341);
            this.ödenen10.Name = "ödenen10";
            this.ödenen10.Size = new System.Drawing.Size(41, 13);
            this.ödenen10.TabIndex = 162;
            this.ödenen10.Text = "label63";
            // 
            // kalan9
            // 
            this.kalan9.AutoSize = true;
            this.kalan9.Location = new System.Drawing.Point(138, 314);
            this.kalan9.Name = "kalan9";
            this.kalan9.Size = new System.Drawing.Size(41, 13);
            this.kalan9.TabIndex = 161;
            this.kalan9.Text = "label64";
            // 
            // ödenen9
            // 
            this.ödenen9.AutoSize = true;
            this.ödenen9.Location = new System.Drawing.Point(64, 313);
            this.ödenen9.Name = "ödenen9";
            this.ödenen9.Size = new System.Drawing.Size(41, 13);
            this.ödenen9.TabIndex = 160;
            this.ödenen9.Text = "label65";
            // 
            // kalan8
            // 
            this.kalan8.AutoSize = true;
            this.kalan8.Location = new System.Drawing.Point(138, 283);
            this.kalan8.Name = "kalan8";
            this.kalan8.Size = new System.Drawing.Size(41, 13);
            this.kalan8.TabIndex = 159;
            this.kalan8.Text = "label66";
            // 
            // ödenen8
            // 
            this.ödenen8.AutoSize = true;
            this.ödenen8.Location = new System.Drawing.Point(64, 282);
            this.ödenen8.Name = "ödenen8";
            this.ödenen8.Size = new System.Drawing.Size(41, 13);
            this.ödenen8.TabIndex = 158;
            this.ödenen8.Text = "label67";
            // 
            // kalan7
            // 
            this.kalan7.AutoSize = true;
            this.kalan7.Location = new System.Drawing.Point(138, 255);
            this.kalan7.Name = "kalan7";
            this.kalan7.Size = new System.Drawing.Size(41, 13);
            this.kalan7.TabIndex = 157;
            this.kalan7.Text = "label68";
            // 
            // ödenen7
            // 
            this.ödenen7.AutoSize = true;
            this.ödenen7.Location = new System.Drawing.Point(64, 254);
            this.ödenen7.Name = "ödenen7";
            this.ödenen7.Size = new System.Drawing.Size(41, 13);
            this.ödenen7.TabIndex = 156;
            this.ödenen7.Text = "label69";
            // 
            // kalan6
            // 
            this.kalan6.AutoSize = true;
            this.kalan6.Location = new System.Drawing.Point(138, 226);
            this.kalan6.Name = "kalan6";
            this.kalan6.Size = new System.Drawing.Size(41, 13);
            this.kalan6.TabIndex = 155;
            this.kalan6.Text = "label54";
            // 
            // ödenen6
            // 
            this.ödenen6.AutoSize = true;
            this.ödenen6.Location = new System.Drawing.Point(64, 225);
            this.ödenen6.Name = "ödenen6";
            this.ödenen6.Size = new System.Drawing.Size(41, 13);
            this.ödenen6.TabIndex = 154;
            this.ödenen6.Text = "label55";
            // 
            // kalan5
            // 
            this.kalan5.AutoSize = true;
            this.kalan5.Location = new System.Drawing.Point(138, 198);
            this.kalan5.Name = "kalan5";
            this.kalan5.Size = new System.Drawing.Size(41, 13);
            this.kalan5.TabIndex = 153;
            this.kalan5.Text = "label56";
            // 
            // ödenen5
            // 
            this.ödenen5.AutoSize = true;
            this.ödenen5.Location = new System.Drawing.Point(64, 197);
            this.ödenen5.Name = "ödenen5";
            this.ödenen5.Size = new System.Drawing.Size(41, 13);
            this.ödenen5.TabIndex = 152;
            this.ödenen5.Text = "label57";
            // 
            // kalan4
            // 
            this.kalan4.AutoSize = true;
            this.kalan4.Location = new System.Drawing.Point(138, 172);
            this.kalan4.Name = "kalan4";
            this.kalan4.Size = new System.Drawing.Size(41, 13);
            this.kalan4.TabIndex = 151;
            this.kalan4.Text = "label44";
            // 
            // ödenen4
            // 
            this.ödenen4.AutoSize = true;
            this.ödenen4.Location = new System.Drawing.Point(64, 171);
            this.ödenen4.Name = "ödenen4";
            this.ödenen4.Size = new System.Drawing.Size(41, 13);
            this.ödenen4.TabIndex = 150;
            this.ödenen4.Text = "label45";
            // 
            // kalan3
            // 
            this.kalan3.AutoSize = true;
            this.kalan3.Location = new System.Drawing.Point(138, 144);
            this.kalan3.Name = "kalan3";
            this.kalan3.Size = new System.Drawing.Size(41, 13);
            this.kalan3.TabIndex = 149;
            this.kalan3.Text = "label52";
            // 
            // ödenen3
            // 
            this.ödenen3.AutoSize = true;
            this.ödenen3.Location = new System.Drawing.Point(64, 143);
            this.ödenen3.Name = "ödenen3";
            this.ödenen3.Size = new System.Drawing.Size(41, 13);
            this.ödenen3.TabIndex = 148;
            this.ödenen3.Text = "label53";
            // 
            // kalan2
            // 
            this.kalan2.AutoSize = true;
            this.kalan2.Location = new System.Drawing.Point(138, 113);
            this.kalan2.Name = "kalan2";
            this.kalan2.Size = new System.Drawing.Size(41, 13);
            this.kalan2.TabIndex = 147;
            this.kalan2.Text = "label42";
            // 
            // ödenen2
            // 
            this.ödenen2.AutoSize = true;
            this.ödenen2.Location = new System.Drawing.Point(64, 112);
            this.ödenen2.Name = "ödenen2";
            this.ödenen2.Size = new System.Drawing.Size(41, 13);
            this.ödenen2.TabIndex = 146;
            this.ödenen2.Text = "label43";
            // 
            // kalan1
            // 
            this.kalan1.AutoSize = true;
            this.kalan1.Location = new System.Drawing.Point(138, 85);
            this.kalan1.Name = "kalan1";
            this.kalan1.Size = new System.Drawing.Size(39, 13);
            this.kalan1.TabIndex = 145;
            this.kalan1.Text = "kalan1";
            // 
            // ödenen1
            // 
            this.ödenen1.AutoSize = true;
            this.ödenen1.Location = new System.Drawing.Point(64, 84);
            this.ödenen1.Name = "ödenen1";
            this.ödenen1.Size = new System.Drawing.Size(0, 13);
            this.ödenen1.TabIndex = 144;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(270, 35);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(97, 16);
            this.label38.TabIndex = 143;
            this.label38.Text = "Ödeme Şekli";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label37.Location = new System.Drawing.Point(136, 453);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(319, 25);
            this.label37.TabIndex = 83;
            this.label37.Text = "Kanki Burayı tablo gibi yapar mısın?";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(200, 35);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(44, 16);
            this.label36.TabIndex = 142;
            this.label36.Text = "Tutar";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(138, 35);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(47, 16);
            this.label35.TabIndex = 141;
            this.label35.Text = "Kalan";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(64, 35);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(62, 16);
            this.label34.TabIndex = 140;
            this.label34.Text = "Ödenen";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label33.ForeColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(8, 35);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(44, 16);
            this.label33.TabIndex = 139;
            this.label33.Text = "Aylar";
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(331, 388);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(68, 21);
            this.button19.TabIndex = 138;
            this.button19.Text = "Bankadan";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(331, 359);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(68, 21);
            this.button20.TabIndex = 137;
            this.button20.Text = "Bankadan";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(331, 330);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(68, 21);
            this.button21.TabIndex = 136;
            this.button21.Text = "Bankadan";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(331, 303);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(68, 21);
            this.button22.TabIndex = 135;
            this.button22.Text = "Bankadan";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(331, 271);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(68, 21);
            this.button23.TabIndex = 134;
            this.button23.Text = "Bankadan";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(331, 244);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(68, 21);
            this.button24.TabIndex = 133;
            this.button24.Text = "Bankadan";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(320, 218);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(68, 21);
            this.button13.TabIndex = 132;
            this.button13.Text = "Bankadan";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(320, 189);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(68, 21);
            this.button14.TabIndex = 131;
            this.button14.Text = "Bankadan";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(320, 160);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(68, 21);
            this.button15.TabIndex = 130;
            this.button15.Text = "Bankadan";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(320, 133);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(68, 21);
            this.button16.TabIndex = 129;
            this.button16.Text = "Bankadan";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(320, 101);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(68, 21);
            this.button17.TabIndex = 128;
            this.button17.Text = "Bankadan";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(320, 74);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(68, 21);
            this.button18.TabIndex = 127;
            this.button18.Text = "Bankadan";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(273, 384);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(43, 23);
            this.button11.TabIndex = 126;
            this.button11.Text = "Elden";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(273, 357);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(43, 23);
            this.button12.TabIndex = 125;
            this.button12.Text = "Elden";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(273, 328);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(43, 23);
            this.button9.TabIndex = 124;
            this.button9.Text = "Elden";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(273, 301);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(43, 23);
            this.button10.TabIndex = 123;
            this.button10.Text = "Elden";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(273, 272);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(43, 23);
            this.button7.TabIndex = 122;
            this.button7.Text = "Elden";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(273, 245);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(43, 23);
            this.button8.TabIndex = 121;
            this.button8.Text = "Elden";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(269, 218);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(45, 21);
            this.button5.TabIndex = 120;
            this.button5.Text = "Elden";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(269, 189);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(45, 21);
            this.button6.TabIndex = 119;
            this.button6.Text = "Elden";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(269, 160);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(45, 21);
            this.button3.TabIndex = 118;
            this.button3.Text = "Elden";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(269, 133);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(45, 21);
            this.button4.TabIndex = 117;
            this.button4.Text = "Elden";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(269, 101);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(45, 21);
            this.button2.TabIndex = 116;
            this.button2.Text = "Elden";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(269, 74);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(45, 21);
            this.button1.TabIndex = 115;
            this.button1.Text = "Elden";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(199, 380);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(45, 20);
            this.textBox11.TabIndex = 114;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(199, 352);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(45, 20);
            this.textBox12.TabIndex = 113;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(199, 215);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(45, 20);
            this.textBox9.TabIndex = 112;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(199, 187);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(45, 20);
            this.textBox10.TabIndex = 111;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(199, 323);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(45, 20);
            this.textBox5.TabIndex = 110;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(199, 295);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(45, 20);
            this.textBox6.TabIndex = 109;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(199, 268);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(45, 20);
            this.textBox7.TabIndex = 108;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(199, 240);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(45, 20);
            this.textBox8.TabIndex = 107;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(199, 157);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(45, 20);
            this.textBox3.TabIndex = 106;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(199, 129);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(45, 20);
            this.textBox4.TabIndex = 105;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(199, 102);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(45, 20);
            this.textBox2.TabIndex = 104;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(199, 74);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(45, 20);
            this.textBox1.TabIndex = 103;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label46.ForeColor = System.Drawing.Color.White;
            this.label46.Location = new System.Drawing.Point(3, 393);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(48, 16);
            this.label46.TabIndex = 90;
            this.label46.Text = "Aralık";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label47.ForeColor = System.Drawing.Color.White;
            this.label47.Location = new System.Drawing.Point(3, 364);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(50, 16);
            this.label47.TabIndex = 89;
            this.label47.Text = "Kasım";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label48.ForeColor = System.Drawing.Color.White;
            this.label48.Location = new System.Drawing.Point(3, 338);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(42, 16);
            this.label48.TabIndex = 88;
            this.label48.Text = "Ekim";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label49.ForeColor = System.Drawing.Color.White;
            this.label49.Location = new System.Drawing.Point(3, 309);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(42, 16);
            this.label49.TabIndex = 87;
            this.label49.Text = "Eylül";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label50.ForeColor = System.Drawing.Color.White;
            this.label50.Location = new System.Drawing.Point(3, 280);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(64, 16);
            this.label50.TabIndex = 86;
            this.label50.Text = "Ağustos";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label51.ForeColor = System.Drawing.Color.White;
            this.label51.Location = new System.Drawing.Point(3, 251);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(66, 16);
            this.label51.TabIndex = 85;
            this.label51.Text = "Temmuz";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(3, 224);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(61, 16);
            this.label31.TabIndex = 72;
            this.label31.Text = "Haziran";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(3, 195);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(49, 16);
            this.label32.TabIndex = 71;
            this.label32.Text = "Mayıs";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(3, 169);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(48, 16);
            this.label26.TabIndex = 70;
            this.label26.Text = "Nisan";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(3, 140);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(38, 16);
            this.label30.TabIndex = 69;
            this.label30.Text = "Mart";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(3, 111);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 16);
            this.label16.TabIndex = 68;
            this.label16.Text = "Şubat";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(26, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(184, 24);
            this.label15.TabIndex = 67;
            this.label15.Text = "ÖDEME BİLGİLERİ";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(3, 82);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(44, 16);
            this.label25.TabIndex = 63;
            this.label25.Text = "Ocak";
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel4.Controls.Add(this.txtBasTarih);
            this.panel4.Controls.Add(this.txtSonTarih);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.txtIban);
            this.panel4.Controls.Add(this.label28);
            this.panel4.Controls.Add(this.txtDepozito);
            this.panel4.Controls.Add(this.label21);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.txtAylıkUcret);
            this.panel4.Controls.Add(this.label24);
            this.panel4.Controls.Add(this.label29);
            this.panel4.Location = new System.Drawing.Point(32, 500);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(284, 156);
            this.panel4.TabIndex = 77;
            // 
            // txtBasTarih
            // 
            this.txtBasTarih.Location = new System.Drawing.Point(130, 23);
            this.txtBasTarih.Name = "txtBasTarih";
            this.txtBasTarih.Size = new System.Drawing.Size(134, 20);
            this.txtBasTarih.TabIndex = 69;
            // 
            // txtSonTarih
            // 
            this.txtSonTarih.Location = new System.Drawing.Point(130, 49);
            this.txtSonTarih.Name = "txtSonTarih";
            this.txtSonTarih.Size = new System.Drawing.Size(134, 20);
            this.txtSonTarih.TabIndex = 68;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(1, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(178, 24);
            this.label9.TabIndex = 67;
            this.label9.Text = "SENET BİLGİLERİ";
            // 
            // txtIban
            // 
            this.txtIban.Location = new System.Drawing.Point(130, 75);
            this.txtIban.Name = "txtIban";
            this.txtIban.Size = new System.Drawing.Size(134, 20);
            this.txtIban.TabIndex = 66;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(2, 70);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(108, 16);
            this.label28.TabIndex = 65;
            this.label28.Text = "Iban Numarası";
            // 
            // txtDepozito
            // 
            this.txtDepozito.Location = new System.Drawing.Point(130, 127);
            this.txtDepozito.Name = "txtDepozito";
            this.txtDepozito.Size = new System.Drawing.Size(134, 20);
            this.txtDepozito.TabIndex = 64;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(3, 121);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(115, 16);
            this.label21.TabIndex = 63;
            this.label21.Text = "Depozito Ücreti";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(3, 46);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(82, 16);
            this.label22.TabIndex = 59;
            this.label22.Text = "Bitiş Tarihi";
            // 
            // txtAylıkUcret
            // 
            this.txtAylıkUcret.Location = new System.Drawing.Point(130, 101);
            this.txtAylıkUcret.Name = "txtAylıkUcret";
            this.txtAylıkUcret.Size = new System.Drawing.Size(134, 20);
            this.txtAylıkUcret.TabIndex = 60;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(3, 101);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(83, 16);
            this.label24.TabIndex = 58;
            this.label24.Text = "Aylık Ücret";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(3, 24);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(121, 16);
            this.label29.TabIndex = 57;
            this.label29.Text = "Başlangıç Tarihi";
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.Controls.Add(this.txtAnneAd);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.txtAileAdres);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.txtBabaAd);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.txtAnneTel);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.txtBabaTel);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Location = new System.Drawing.Point(32, 277);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(279, 202);
            this.panel2.TabIndex = 77;
            // 
            // txtAnneAd
            // 
            this.txtAnneAd.Location = new System.Drawing.Point(107, 33);
            this.txtAnneAd.Name = "txtAnneAd";
            this.txtAnneAd.Size = new System.Drawing.Size(160, 20);
            this.txtAnneAd.TabIndex = 62;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(3, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 24);
            this.label5.TabIndex = 61;
            this.label5.Text = "AİLE BİLGİLERİ";
            // 
            // txtAileAdres
            // 
            this.txtAileAdres.Location = new System.Drawing.Point(107, 133);
            this.txtAileAdres.Name = "txtAileAdres";
            this.txtAileAdres.Size = new System.Drawing.Size(160, 56);
            this.txtAileAdres.TabIndex = 60;
            this.txtAileAdres.Text = "";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(7, 132);
            this.label18.Name = "label18";
            this.label18.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label18.Size = new System.Drawing.Size(49, 16);
            this.label18.TabIndex = 59;
            this.label18.Text = "Adres";
            // 
            // txtBabaAd
            // 
            this.txtBabaAd.Location = new System.Drawing.Point(107, 59);
            this.txtBabaAd.Name = "txtBabaAd";
            this.txtBabaAd.Size = new System.Drawing.Size(160, 20);
            this.txtBabaAd.TabIndex = 58;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(7, 56);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(72, 16);
            this.label23.TabIndex = 55;
            this.label23.Text = "Baba Adı";
            // 
            // txtAnneTel
            // 
            this.txtAnneTel.Location = new System.Drawing.Point(107, 81);
            this.txtAnneTel.Name = "txtAnneTel";
            this.txtAnneTel.Size = new System.Drawing.Size(160, 20);
            this.txtAnneTel.TabIndex = 57;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(7, 78);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(94, 16);
            this.label20.TabIndex = 54;
            this.label20.Text = "Anne Tel No";
            // 
            // txtBabaTel
            // 
            this.txtBabaTel.Location = new System.Drawing.Point(107, 107);
            this.txtBabaTel.Name = "txtBabaTel";
            this.txtBabaTel.Size = new System.Drawing.Size(160, 20);
            this.txtBabaTel.TabIndex = 56;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(7, 104);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 16);
            this.label6.TabIndex = 53;
            this.label6.Text = "Baba Tel No";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(7, 33);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(70, 16);
            this.label27.TabIndex = 52;
            this.label27.Text = "Anne Adı";
            // 
            // panel3
            // 
            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel3.Controls.Add(this.txtsınıf);
            this.panel3.Controls.Add(this.txtOkul);
            this.panel3.Controls.Add(this.txtadres);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.txtbolum);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.txtdogumtarih);
            this.panel3.Controls.Add(this.txtozeldurum);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.txttel);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.txttc);
            this.panel3.Controls.Add(this.txtSoyad);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.txtAd);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Location = new System.Drawing.Point(35, 46);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(545, 225);
            this.panel3.TabIndex = 76;
            // 
            // txtsınıf
            // 
            this.txtsınıf.Location = new System.Drawing.Point(355, 91);
            this.txtsınıf.Name = "txtsınıf";
            this.txtsınıf.Size = new System.Drawing.Size(170, 20);
            this.txtsınıf.TabIndex = 96;
            // 
            // txtOkul
            // 
            this.txtOkul.Location = new System.Drawing.Point(355, 31);
            this.txtOkul.Name = "txtOkul";
            this.txtOkul.Size = new System.Drawing.Size(170, 20);
            this.txtOkul.TabIndex = 95;
            // 
            // txtadres
            // 
            this.txtadres.Location = new System.Drawing.Point(355, 117);
            this.txtadres.Name = "txtadres";
            this.txtadres.Size = new System.Drawing.Size(170, 83);
            this.txtadres.TabIndex = 94;
            this.txtadres.Text = "";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(289, 117);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(53, 16);
            this.label10.TabIndex = 93;
            this.label10.Text = "Adres:";
            // 
            // txtbolum
            // 
            this.txtbolum.Location = new System.Drawing.Point(355, 60);
            this.txtbolum.Name = "txtbolum";
            this.txtbolum.Size = new System.Drawing.Size(170, 20);
            this.txtbolum.TabIndex = 91;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(291, 31);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 16);
            this.label13.TabIndex = 89;
            this.label13.Text = "Okulu:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(291, 61);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 16);
            this.label14.TabIndex = 90;
            this.label14.Text = "Bölümü:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(291, 90);
            this.label19.Name = "label19";
            this.label19.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label19.Size = new System.Drawing.Size(46, 16);
            this.label19.TabIndex = 88;
            this.label19.Text = "Sınıfı:";
            // 
            // txtdogumtarih
            // 
            this.txtdogumtarih.Location = new System.Drawing.Point(113, 111);
            this.txtdogumtarih.Name = "txtdogumtarih";
            this.txtdogumtarih.Size = new System.Drawing.Size(172, 20);
            this.txtdogumtarih.TabIndex = 87;
            // 
            // txtozeldurum
            // 
            this.txtozeldurum.Location = new System.Drawing.Point(113, 169);
            this.txtozeldurum.Name = "txtozeldurum";
            this.txtozeldurum.Size = new System.Drawing.Size(172, 44);
            this.txtozeldurum.TabIndex = 86;
            this.txtozeldurum.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 169);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(91, 16);
            this.label1.TabIndex = 85;
            this.label1.Text = "Özel Durum:";
            // 
            // txttel
            // 
            this.txttel.Location = new System.Drawing.Point(113, 140);
            this.txttel.Name = "txttel";
            this.txttel.Size = new System.Drawing.Size(172, 20);
            this.txttel.TabIndex = 83;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 144);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(89, 16);
            this.label2.TabIndex = 82;
            this.label2.Text = "Telefon No:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(0, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 16);
            this.label3.TabIndex = 78;
            this.label3.Text = "Soyadı:";
            // 
            // txttc
            // 
            this.txttc.Location = new System.Drawing.Point(113, 85);
            this.txttc.Name = "txttc";
            this.txttc.Size = new System.Drawing.Size(172, 20);
            this.txttc.TabIndex = 80;
            // 
            // txtSoyad
            // 
            this.txtSoyad.Location = new System.Drawing.Point(113, 59);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(172, 20);
            this.txtSoyad.TabIndex = 81;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(2, 89);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 16);
            this.label11.TabIndex = 79;
            this.label11.Text = "TC No:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(2, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 16);
            this.label4.TabIndex = 77;
            this.label4.Text = "Doğum Tarihi:";
            // 
            // txtAd
            // 
            this.txtAd.Location = new System.Drawing.Point(113, 31);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(172, 20);
            this.txtAd.TabIndex = 76;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(5, 39);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 16);
            this.label17.TabIndex = 75;
            this.label17.Text = "Adı:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(4, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(178, 24);
            this.label8.TabIndex = 74;
            this.label8.Text = "KİŞİSEL BİLGİLER";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(-302, 43);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "Soyadı";
            // 
            // ogrenciödemeBindingSource
            // 
            this.ogrenciödemeBindingSource.DataMember = "ogrenciödeme";
            this.ogrenciödemeBindingSource.DataSource = this.apartYonetimSistemiDataSet;
            // 
            // apartYonetimSistemiDataSet
            // 
            this.apartYonetimSistemiDataSet.DataSetName = "ApartYonetimSistemiDataSet";
            this.apartYonetimSistemiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ogrenciödemeTableAdapter
            // 
            this.ogrenciödemeTableAdapter.ClearBeforeFill = true;
            // 
            // KisiBilgileri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1269, 754);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.toolStrip1);
            this.Name = "KisiBilgileri";
            this.Text = "KisiBilgileri";
            this.Load += new System.EventHandler(this.KisiBilgileri_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ogrenciödemeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apartYonetimSistemiDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem yazOkuluKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtdogumtarih;
        private System.Windows.Forms.RichTextBox txtozeldurum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txttel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txttc;
        private System.Windows.Forms.TextBox txtSoyad;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtAnneAd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox txtAileAdres;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtBabaAd;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtAnneTel;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtBabaTel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtsınıf;
        private System.Windows.Forms.TextBox txtOkul;
        private System.Windows.Forms.RichTextBox txtadres;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtbolum;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtBasTarih;
        private System.Windows.Forms.TextBox txtSonTarih;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtIban;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtDepozito;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtAylıkUcret;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label kalan12;
        private System.Windows.Forms.Label ödenen12;
        private System.Windows.Forms.Label kalan11;
        private System.Windows.Forms.Label ödenen11;
        private System.Windows.Forms.Label kalan10;
        private System.Windows.Forms.Label ödenen10;
        private System.Windows.Forms.Label kalan9;
        private System.Windows.Forms.Label ödenen9;
        private System.Windows.Forms.Label kalan8;
        private System.Windows.Forms.Label ödenen8;
        private System.Windows.Forms.Label kalan7;
        private System.Windows.Forms.Label ödenen7;
        private System.Windows.Forms.Label kalan6;
        private System.Windows.Forms.Label ödenen6;
        private System.Windows.Forms.Label kalan5;
        private System.Windows.Forms.Label ödenen5;
        private System.Windows.Forms.Label kalan4;
        private System.Windows.Forms.Label ödenen4;
        private System.Windows.Forms.Label kalan3;
        private System.Windows.Forms.Label ödenen3;
        private System.Windows.Forms.Label kalan2;
        private System.Windows.Forms.Label ödenen2;
        private System.Windows.Forms.Label kalan1;
        private System.Windows.Forms.Label ödenen1;
        private ApartYonetimSistemiDataSet apartYonetimSistemiDataSet;
        private System.Windows.Forms.BindingSource ogrenciödemeBindingSource;
        private ApartYonetimSistemiDataSetTableAdapters.ogrenciödemeTableAdapter ogrenciödemeTableAdapter;
    }
}