﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class KisiBilgileri : Form
    {
        public KisiBilgileri()
        {
            InitializeComponent();
        }
        List<string> aylar = new List<string>();
        public string kisiid { get; set; }
        public void kisigetir(int id)

        {
            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM tumBilgiler WHERE ID  = '" + id + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    txtAd.Text += dr4[1] as string;
                    txtSoyad.Text += dr4[2] as string;
                    txttc.Text += dr4[3].ToString();
                    txttel.Text += dr4[4].ToString();
                    //telno2
                    //dogumyeri
                    txtdogumtarih.Text += dr4[7].ToString();
                    //uyruk
                    txtadres.Text += dr4[9].ToString();
                    txtBasTarih.Text += dr4[10].ToString();
                    txtSonTarih.Text += dr4[11].ToString();
                    txtAylıkUcret.Text += dr4[12].ToString();
                    txtDepozito.Text += dr4[13].ToString();
                    //aileid
                    //okulid
                    //kayiybil
                    txtozeldurum.Text += dr4[17] as string;
                    txtIban.Text += dr4[18] as string;
                    //aile Id
                    txtAnneAd.Text += dr4[20] as string;
                    //annemeslek
                    txtAnneTel.Text += dr4[22].ToString();
                    txtBabaAd.Text += dr4[23] as string;
                    //baba meslek
                    txtBabaTel.Text += dr4[25].ToString();
                    txtAileAdres.Text += dr4[26] as string;
                    //okul ID
                    txtOkul.Text += dr4[28] as string;
                    txtbolum.Text += dr4[29] as string;
                    txtsınıf.Text += dr4[30] as string;

                }
                dr4.NextResult();
                dr4.Close();
            }
        }
        public void odemebilgilerigetir(int id)
        {
            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM ogrenciödeme WHERE ID  = '" + id + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    aylar.Add(dr4.GetString(3));                    

                }
                dr4.NextResult();
                dr4.Close();

            }
            for (int i =0; i<aylar.Count;i++) {
                using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM ogrenciödeme WHERE ID  = '" + id + "' AND Ay = '"+aylar[i]+"'", cnn))
                {
                    SqlDataReader dr4 = cmd4.ExecuteReader();
                    while (dr4.Read())
                    {
                        int kira = dr4.GetInt32(2);
                        int ödenen = dr4.GetInt32(4);
                        label43.Text += dr4[4].ToString();
                        kalan1.Text += kira - ödenen;

                       

                    }
                    dr4.NextResult();
                    dr4.Close();
                    
                }
            }
        }
        private void KisiBilgileri_Load(object sender, EventArgs e)
        {

            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
            int id = Convert.ToInt32(kisiid);
            kisigetir(id);
            //odemebilgilerigetir(id);
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.Show();
        }

        private void label32_Click(object sender, EventArgs e)
        {

        }

        private void ödenen2_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.Show();
        }

        private void kalan6_Click(object sender, EventArgs e)
        {

        }

        private void kalan12_Click(object sender, EventArgs e)
        {

        }

        private void kalan11_Click(object sender, EventArgs e)
        {

        }

        private void kalan10_Click(object sender, EventArgs e)
        {

        }

        private void kalan9_Click(object sender, EventArgs e)
        {

        }

        private void kalan8_Click(object sender, EventArgs e)
        {

        }

        private void kalan7_Click(object sender, EventArgs e)
        {

        }

        private void label52_Click(object sender, EventArgs e)
        {

        }

        private void ödenen12_Click(object sender, EventArgs e)
        {

        }

        private void ödenen11_Click(object sender, EventArgs e)
        {

        }

        private void label44_Click(object sender, EventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.Show();
        }
    }
}
