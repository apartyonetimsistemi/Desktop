﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class KisiBilgileri : Form
    {
        public KisiBilgileri()
        {
            InitializeComponent();
        }
        List<string> aylar = new List<string>();
        public string kisiid { get; set; }
        public string apartid { get; set; }
        public void getapart()

        {

            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Apartlar where ID  = '" + apartid + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    //apartAdi.Text += dr4[1] as string;

                }
                dr4.NextResult();
                dr4.Close();

            }
        }
        public void kisigetir(int id)

        {
            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM tumBilgiler WHERE ID  = '" + id + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    txtAd.Text += dr4[1] as string;
                    txtSoyad.Text += dr4[2] as string;
                    txtTc.Text += dr4[3].ToString();
                    txtTel.Text += dr4[4].ToString();
                    txtTel2.Text += dr4[5].ToString();
                    txtDogumYeri.Text += dr4[6] as string;
                    txtDogumTarih.Text += dr4[7].ToString();
                    txtUyruk.Text += dr4[8] as string;
                    txtAdres.Text += dr4[9].ToString();
                    txtBasTarih.Text += dr4[10].ToString();
                    txtBitTarih.Text += dr4[11].ToString();
                    txtAylıkUcret.Text += dr4[12].ToString();
                    txtDepozito.Text += dr4[13].ToString();
                    //aileid
                    //okulid
                    //kayiybil
                    txtOzelDurum.Text += dr4[17] as string;
                    txtIban.Text += dr4[18] as string;
                    //aile Id
                    txtAnneAd.Text += dr4[20] as string;
                    txtAnneMes.Text += dr4[4] as string;
                    txtAnneTel.Text += dr4[22].ToString();
                    txtBabaAd.Text += dr4[23] as string;
                    txtBabaMes.Text += dr4[4] as string;
                    txtBabaTel.Text += dr4[25].ToString();
                    txtAileAdres.Text += dr4[26] as string;
                    //okul ID
                    txtOkul.Text += dr4[28] as string;
                    txtBolum.Text += dr4[29] as string;
                    txtSınıf.Text += dr4[30] as string;

                }
                dr4.NextResult();
                dr4.Close();
            }
        }/*
        public void odemebilgilerigetir()
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();

                using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM AyKira WHERE KisiID  = '" + Int32.Parse(kisiid) + "' ", cnn))
                {

                    SqlDataReader dr4 = cmd4.ExecuteReader();

                    while (dr4.Read())
                    {
                        aylar.Add(dr4.GetString(4));

                    }
                    dr4.NextResult();
                    dr4.Close();

                }
                for (int i = 0; i < aylar.Count; i++)
                {
                    using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Aykira WHERE KisiID  = '" + kisiid + "' AND Ay = '" + aylar[i] + "'", cnn))
                    {
                        SqlDataReader dr4 = cmd4.ExecuteReader();
                        while (dr4.Read())
                        {
                            int kira = dr4.GetInt32(2);
                            int ödenen = dr4.GetInt32(7);
                            label43.Text += dr4[4].ToString();
                            lblKalan1.Text += kira - ödenen;



                        }
                        dr4.NextResult();
                        dr4.Close();

                    }
                }
            }
            catch(Exception ex) { MessageBox.Show(ex.ToString()); }
        }
        */

        /*yorum satırına aldım
        public void DisplayData()
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                int id = Int32.Parse(kisiid);
                SqlDataAdapter adpt = new SqlDataAdapter("select Ay,Miktar,OdemeSekli,YilID from Aykira where KisiID = '"+id+"'", cnn);
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch (Exception ex){ MessageBox.Show(ex.ToString()); }
        }*/
        private void KisiBilgileri_Load(object sender, EventArgs e)
        {
            try
            {
                int id = Int32.Parse(kisiid);
                kisigetir(id);
                //DisplayData();
            }

            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
          
            ///odemebilgilerigetir();
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.apartid = apartid;
            this.Hide();
            yenikayit.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.apartid = apartid;
            this.Hide();
            kayitsilme.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.apartid = apartid;
            this.Hide();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.apartid = apartid;
            this.Hide();
            gelirgider.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.apartid = apartid;
            this.Hide();
            camasirmakinesi.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.id = apartid;
            this.Hide();
            anasayfa.Show();
        }

  

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            kisiarama.apartid = apartid;
            this.Hide();
            kisiarama.Show();
        }

  

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            calisanlistesi.apartid = apartid;
            this.Hide();
            calisanlistesi.Show();
        }

       
        //public void odeme()
        //{
        //    SqlConnection cnn = database.getConnection();
        //    cnn.Open();

        //    using (SqlCommand cmd4 = new SqlCommand("SELECT Ay FROM AyKira WHERE ID  = '" + kisiid + "' ", cnn))
        //    {

        //        SqlDataReader dr4 = cmd4.ExecuteReader();

        //        while (dr4.Read())
        //        {
        //            aylar.Add(dr4.GetString(3));

        //        }
        //        dr4.NextResult();
        //        dr4.Close();

        //    }
        //}

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Odeme odeme = new Odeme();
            odeme.apartid = apartid;
            odeme.kisiid = kisiid;
            this.Hide();
            odeme.Show();
        }

        private void apartAdi_Click(object sender, EventArgs e)
        {

        }
    }
}
