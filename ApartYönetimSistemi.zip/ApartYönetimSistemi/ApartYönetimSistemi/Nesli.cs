﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class Nesli : Form
    {
        public Nesli()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            KulGirA kulgira = new KulGirA();
            kulgira.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            KulGirA kulgira = new KulGirA();
            kulgira.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            KulGirA kulgira = new KulGirA();
            kulgira.Show();
        }
    }
}
