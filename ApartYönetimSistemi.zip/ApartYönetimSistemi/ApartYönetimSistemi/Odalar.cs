﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class Odalar : Form
    {
        public Odalar()
        {
            InitializeComponent();
        }
        List<int> bosyatakid = new List<int>();
        List<int> bosodaid = new List<int>();
        List<int> bosdaireid = new List<int>();
        List<int> newbosdaireid = new List<int>();
        List<int> bosyatakdaireye = new List<int>();
        List<int> doluyatakdaireye = new List<int>();

        public int count;
        public int bosyatak;
        public void getyatak()
        {
            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd2 = new SqlCommand("SELECT DISTINCT ID FROM Yatak where KisiID Is Null", cnn))
            {

                SqlDataReader dr2 = cmd2.ExecuteReader();

                while (dr2.Read())
                {
                    bosyatakid.Add(dr2.GetInt32(0));
                }

                // move on to second select
                dr2.NextResult();
                dr2.Close();
            }

            for (int j = 0; j < bosyatakid.Count; j++)
            {
                yatak.Text += bosyatakid[j];

            }

        }
        public void getoda()
        {
            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd3 = new SqlCommand("SELECT DISTINCT OdaID FROM Yatak WHERE KisiID IS Null", cnn))
            {

                SqlDataReader dr3 = cmd3.ExecuteReader();

                while (dr3.Read())
                {
                    bosodaid.Add(dr3.GetInt32(0));
                }
                dr3.NextResult();
                dr3.Close();
            }

            for (int j = 0; j<bosodaid.Count; j++)
            {
                oda.Text += bosodaid[j];

            }
           // MessageBox.Show(bosodaid.Count.ToString());
        }
        public void getdaire()
        {
            SqlConnection cnn = database.getConnection();
            cnn.Open();

            for (int i = 0; i < bosodaid.Count; i++)
            {

                using (SqlCommand cmd4 = new SqlCommand("SELECT DaireID FROM Oda WHERE ID = '" + bosodaid[i] + "'", cnn))
                {

                    SqlDataReader dr4 = cmd4.ExecuteReader();

                    while (dr4.Read())
                    {
                        bosdaireid.Add(dr4.GetInt32(0));
                    }
                    dr4.NextResult();
                    dr4.Close();
                }

               
            }
            newbosdaireid = bosdaireid.Distinct().ToList();
            for (int j=0; j<newbosdaireid.Count; j++)
            {
                daire.Text += newbosdaireid[j];
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void Odalar_Load(object sender, EventArgs e)
        {

            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;

            SqlConnection cnn = database.getConnection();
            cnn.Open();

          

            //SqlCommand cmd = new SqlCommand("SELECT COUNT(ID) FROM Yatak WHERE KisiID IS NULL", cnn);
            //bosyatak = (int)cmd.ExecuteScalar();//9
            //MessageBox.Show(bosdaireid.Count.ToString());

            getyatak();
            getoda();
            getdaire();
            try
            {
                for (int i = 0; i < newbosdaireid.Count; i++)
                {
                    FlowLayoutPanel pnl = new FlowLayoutPanel();
                    pnl.Name = newbosdaireid[i].ToString();
                    pnl.Width = 165;
                    pnl.Height = 197;
                    pnl.BackColor = Color.AntiqueWhite;
                    flowLayoutPanel1.Controls.Add(pnl);
                    Label lbl = new Label();
                    lbl.Text = "Kaçıncı daire";
                    lbl.BackColor = Color.Green;
                    pnl.Controls.Add(lbl);

                    using (SqlCommand cmd4 = new SqlCommand("SELECT DISTINCT y.ID FROM Yatak as y FULL OUTER JOIN Oda as o On y.OdaID = o.ID where KisiID IS Null and DaireID = '" + newbosdaireid[i] + "' ", cnn))
                    {

                        SqlDataReader dr4 = cmd4.ExecuteReader();

                        while (dr4.Read())
                        {
                            bosyatakdaireye.Add(dr4.GetInt32(0));
                        }
                        dr4.NextResult();
                        dr4.Close();
                    }
                   

                    using (SqlCommand cmd5 = new SqlCommand("SELECT DISTINCT y.ID FROM Yatak as y FULL OUTER JOIN Oda as o On y.OdaID = o.ID where KisiID IS not Null and DaireID = '" + newbosdaireid[i] + "' ", cnn))
                    {

                        SqlDataReader dr5 = cmd5.ExecuteReader();

                        while (dr5.Read())
                        {
                            doluyatakdaireye.Add(dr5.GetInt32(0));
                        }
                        dr5.NextResult();
                        dr5.Close();
                    }

                    for (int j = 0; j < bosyatakdaireye.Count; j++)
                    {
                        Button btn = new Button();
                        btn.Name = bosyatakdaireye[j].ToString();
                       
                        btn.BackColor = Color.Blue;
                        btn.Text = bosyatakdaireye[j].ToString();
                        btn.Click += new EventHandler(btn_click);
                        pnl.Controls.Add(btn);

                }
                    for (int k = 0; k < doluyatakdaireye.Count; k++)
                    {
                        Button btn = new Button();
                        btn.Name = bosyatakdaireye[k].ToString();

                        btn.BackColor = Color.Gray;
                        btn.Text = bosyatakdaireye[k].ToString();
                        //btn.Click += new EventHandler(btn_click);
                        pnl.Controls.Add(btn);

                    }
                    bosyatakdaireye.Clear();
                    doluyatakdaireye.Clear();
                }
            }
            catch { MessageBox.Show("Hata var"); }

           
           
        }
        protected void btn_click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            btn.BackColor = Color.Red;
            //secilenyatak.Text = btn.Name;
            YeniKayıt yenikayit = new YeniKayıt();
            string yatakid = btn.Name;
            yenikayit.yatakidsi = yatakid;
            yenikayit.Show();
        }
        

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            kayitsilme.Show();
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            yenikayit.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            gelirgider.Show();
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            camasirmakinesi.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            anasayfa.Show();
        }
    }
}
