﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class Odalar : Form
    {
        public Odalar()
        {
            InitializeComponent();
        }
        List<int> bosyatakid = new List<int>();
        List<int> bosodaid = new List<int>();
        List<int> bosdaireid = new List<int>();
        List<int> newbosdaireid = new List<int>();
        List<int> bosyatakdaireye = new List<int>();
        List<int> doluyatakdaireye = new List<int>();
        List<int> tumodalar = new List<int>();
        List<int> tumyataklar = new List<int>();
        List<int> daireNum = new List<int>();
        string nameofdaire;
        public int count;
        public int bosyatak;
        int deneme;
        /*public void getapart()

        {

            SqlConnection cnn = database.getConnection();
            cnn.Open();

            using (SqlCommand cmd4 = new SqlCommand("SELECT * FROM Apartlar where ID  = '" + apartid + "' ", cnn))
            {

                SqlDataReader dr4 = cmd4.ExecuteReader();

                while (dr4.Read())
                {
                    apartAdi.Text += dr4[1] as string;

                }
                dr4.NextResult();
                dr4.Close();

            }
        }*/

        public void daireler(int apartid)
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();

                using (SqlCommand cmd4 = new SqlCommand("SELECT DISTINCT ID,DaireNum FROM Daire where ApartID  = '" + apartid + "' ", cnn))
                {

                    SqlDataReader dr4 = cmd4.ExecuteReader();

                    while (dr4.Read())
                    {
                        bosdaireid.Add(dr4.GetInt32(0));
                        daireNum.Add(dr4.GetInt32(1));
                    }
                    dr4.NextResult();
                    dr4.Close();
                }

                for (int i = 0; i < bosdaireid.Count; i++)
                {

                    FlowLayoutPanel pnl = new FlowLayoutPanel();
                    pnl.Name = i.ToString();
                    pnl.Width = 140;
                    pnl.Height = 160;
                    pnl.BackColor = Color.SlateGray;

                    LinkLabel lbl = new LinkLabel(); //dairenumrası               
                    lbl.LinkColor = System.Drawing.Color.White;
                    nameofdaire = bosdaireid[i].ToString();
                    lbl.Name = nameofdaire;                    
                    lbl.Width = 190;
                    lbl.Height = 13;
                    lbl.BackColor = Color.MediumOrchid;
                    lbl.Text = daireNum[i].ToString();
                    flowLayoutPanel1.Controls.Add(pnl);
                    pnl.Controls.Add(lbl);

                    using (SqlCommand cmd5 = new SqlCommand("SELECT DISTINCT ID FROM Oda where DaireID  = '" + bosdaireid[i] + "' ", cnn))
                    {

                        SqlDataReader dr5 = cmd5.ExecuteReader();

                        while (dr5.Read())
                        {
                            tumodalar.Add(dr5.GetInt32(0));
                        }
                        dr5.NextResult();
                        dr5.Close();
                    }
                    for (int j = 0; j < tumodalar.Count; j++)
                    {

                        FlowLayoutPanel pnl2 = new FlowLayoutPanel();
                        pnl2.BackColor = Color.LightSteelBlue;
                        pnl2.Width = 63;
                        pnl2.Height = 45;
                        pnl.Controls.Add(pnl2);


                        using (SqlCommand cmd7 = new SqlCommand("SELECT DISTINCT ID  FROM Yatak where OdaID  = '" + tumodalar[j] + "' ", cnn))
                        {

                            SqlDataReader dr7 = cmd7.ExecuteReader();

                            while (dr7.Read())
                            {
                                tumyataklar.Add(dr7.GetInt32(0));

                            }
                            dr7.NextResult();
                            dr7.Close();
                        }

                        for (int k = 0; k < tumyataklar.Count; k++)
                        {
                            Button btn = new Button();
                            btn.BackColor = Color.Plum;
                            btn.Width = 25;
                            btn.Height = 35;
                            btn.Click += new EventHandler(btn_click);


                            using (SqlCommand cmd6 = new SqlCommand("SELECT DISTINCT o.Adi,o.Soyadi,o.AylıkUcret,y.KisiID FROM Yatak AS y FULL OUTER JOIN OgrenciBilgileri AS o ON  y.KisiID = o.ID  where OdaID  = '" + tumyataklar[k] + "' and y.Durumu=1", cnn))
                            {

                                SqlDataReader dr6 = cmd6.ExecuteReader();

                                while (dr6.Read())
                                {
                                    
                                    deneme = dr6.GetInt32(3);
                                }
                                dr6.NextResult();
                                dr6.Close();
                                pnl2.Controls.Add(btn);
                                if (deneme == 0)
                                {
                                    btn.BackColor = Color.White;
                                }
                            }
                        }
                        tumyataklar.Clear();

                    }
                    tumodalar.Clear();
                }
                cnn.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }





        private void Odalar_Load(object sender, EventArgs e)
        {

            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
            
            int id = 1;
            daireler(id);
           
        }
        protected void btn_click(object sender, EventArgs e)
        {

            try
            {
                

                Button btn = (Button)sender;
                btn.BackColor = Color.Red;
                secilenyatak.Text = btn.Name;
                YeniKayıt yenikayit = new YeniKayıt();
                string yatakid = btn.Name;
                
                yenikayit.yatakidsi = yatakid ;
                yenikayit.Show();
            }
                
                  catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
}
        

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            KayitSilme kayitsilme = new KayitSilme();
            this.Hide();
            kayitsilme.Show();
        }

        private void yazOkuluKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            YeniKayıt yenikayit = new YeniKayıt();
            this.Hide();
            yenikayit.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Calisanlar calisanlar = new Calisanlar();
            this.Hide();
            calisanlar.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            GelirGider gelirgider = new GelirGider();
            this.Hide();
            gelirgider.Show();
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            CamasirMakinesi camasirmakinesi = new CamasirMakinesi();
            this.Hide();
            camasirmakinesi.Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            AnaSayfa anasayfa = new AnaSayfa();
            this.Hide();
            anasayfa.Show();
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            KisiArama kisiarama = new KisiArama();
            this.Hide();
            kisiarama.Show();
        }

        private void çalışanKaydıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CalisanKaydi calisanlistesi = new CalisanKaydi();
            this.Hide();
            calisanlistesi.Show();
        }
    }
}
