﻿namespace ApartYönetimSistemi
{
    partial class YeniKayıt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YeniKayıt));
            this.label38 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtdogumyeri = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtokul = new System.Windows.Forms.TextBox();
            this.txtozeldurum = new System.Windows.Forms.RichTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.dogumtarihi = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.txttelno = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtadres = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.sinif = new System.Windows.Forms.ComboBox();
            this.txtbolum = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txttc = new System.Windows.Forms.TextBox();
            this.txtsoyad = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtad = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtbabatelno = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtaannetelno = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtbabaadi = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtbabameslek = new System.Windows.Forms.TextBox();
            this.txtannemesle = new System.Windows.Forms.TextBox();
            this.txtanneadi = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtaileadres = new System.Windows.Forms.RichTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.txtiban = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtdepozito = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.bitistarih = new System.Windows.Forms.DateTimePicker();
            this.baslangictarih = new System.Windows.Forms.DateTimePicker();
            this.label22 = new System.Windows.Forms.Label();
            this.txtaylikucet = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.btnsave = new System.Windows.Forms.Button();
            this.panel21 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.yazOkuluKaydıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalKayıtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.secilenyatak = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel21.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label38
            // 
            this.label38.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Monotype Corsiva", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label38.ForeColor = System.Drawing.Color.Teal;
            this.label38.Location = new System.Drawing.Point(945, 118);
            this.label38.Margin = new System.Windows.Forms.Padding(20);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(215, 18);
            this.label38.TabIndex = 27;
            this.label38.Text = "Hoşgeldiniz Neslihan Demirtaş";
            // 
            // label40
            // 
            this.label40.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Monotype Corsiva", 26.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label40.ForeColor = System.Drawing.Color.Teal;
            this.label40.Location = new System.Drawing.Point(940, 64);
            this.label40.Margin = new System.Windows.Forms.Padding(20);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(224, 43);
            this.label40.TabIndex = 26;
            this.label40.Text = "ARYA APART";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(52, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(386, 25);
            this.label1.TabIndex = 28;
            this.label1.Text = "YAZ OKULU YENİ ÖĞRENCİ KAYDI";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.Controls.Add(this.txtdogumyeri);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.txtokul);
            this.panel1.Controls.Add(this.txtozeldurum);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.dogumtarihi);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.txttelno);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.txtadres);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.sinif);
            this.panel1.Controls.Add(this.txtbolum);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txttc);
            this.panel1.Controls.Add(this.txtsoyad);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtad);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(39, 153);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(803, 327);
            this.panel1.TabIndex = 29;
            // 
            // txtdogumyeri
            // 
            this.txtdogumyeri.Location = new System.Drawing.Point(144, 304);
            this.txtdogumyeri.Name = "txtdogumyeri";
            this.txtdogumyeri.Size = new System.Drawing.Size(203, 20);
            this.txtdogumyeri.TabIndex = 32;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(22, 298);
            this.label30.Name = "label30";
            this.label30.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label30.Size = new System.Drawing.Size(89, 16);
            this.label30.TabIndex = 31;
            this.label30.Text = "Doğum Yeri";
            // 
            // txtokul
            // 
            this.txtokul.Location = new System.Drawing.Point(533, 53);
            this.txtokul.Name = "txtokul";
            this.txtokul.Size = new System.Drawing.Size(203, 20);
            this.txtokul.TabIndex = 30;
            // 
            // txtozeldurum
            // 
            this.txtozeldurum.Location = new System.Drawing.Point(144, 258);
            this.txtozeldurum.Name = "txtozeldurum";
            this.txtozeldurum.Size = new System.Drawing.Size(203, 25);
            this.txtozeldurum.TabIndex = 29;
            this.txtozeldurum.Text = "";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(22, 267);
            this.label14.Name = "label14";
            this.label14.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label14.Size = new System.Drawing.Size(87, 16);
            this.label14.TabIndex = 28;
            this.label14.Text = "Özel Durum";
            // 
            // dogumtarihi
            // 
            this.dogumtarihi.Location = new System.Drawing.Point(144, 176);
            this.dogumtarihi.Name = "dogumtarihi";
            this.dogumtarihi.Size = new System.Drawing.Size(203, 20);
            this.dogumtarihi.TabIndex = 27;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(21, 15);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(178, 24);
            this.label15.TabIndex = 26;
            this.label15.Text = "KİŞİSEL BİLGİLER";
            // 
            // txttelno
            // 
            this.txttelno.Location = new System.Drawing.Point(144, 217);
            this.txttelno.Name = "txttelno";
            this.txttelno.Size = new System.Drawing.Size(203, 20);
            this.txttelno.TabIndex = 24;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(22, 225);
            this.label13.Name = "label13";
            this.label13.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label13.Size = new System.Drawing.Size(85, 16);
            this.label13.TabIndex = 23;
            this.label13.Text = "Telefon No";
            // 
            // txtadres
            // 
            this.txtadres.Location = new System.Drawing.Point(533, 186);
            this.txtadres.Name = "txtadres";
            this.txtadres.Size = new System.Drawing.Size(203, 83);
            this.txtadres.TabIndex = 22;
            this.txtadres.Text = "";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(414, 189);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(49, 16);
            this.label10.TabIndex = 21;
            this.label10.Text = "Adres";
            // 
            // sinif
            // 
            this.sinif.FormattingEnabled = true;
            this.sinif.Items.AddRange(new object[] {
            "Hazırlık",
            "1.Sınıf",
            "2.Sınıf",
            "3.Sınıf",
            "4.Sınıf",
            "5.Sınıf",
            "6.Sınıf"});
            this.sinif.Location = new System.Drawing.Point(533, 141);
            this.sinif.Name = "sinif";
            this.sinif.Size = new System.Drawing.Size(203, 21);
            this.sinif.TabIndex = 20;
            // 
            // txtbolum
            // 
            this.txtbolum.Location = new System.Drawing.Point(533, 97);
            this.txtbolum.Name = "txtbolum";
            this.txtbolum.Size = new System.Drawing.Size(203, 20);
            this.txtbolum.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(413, 51);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 16);
            this.label9.TabIndex = 16;
            this.label9.Text = "Okulu";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(412, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 16);
            this.label6.TabIndex = 17;
            this.label6.Text = "Bölümü";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(413, 143);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(42, 16);
            this.label5.TabIndex = 15;
            this.label5.Text = "Sınıfı";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(-302, 43);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "Soyadı";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(20, 99);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 16);
            this.label8.TabIndex = 8;
            this.label8.Text = "Soyadı";
            // 
            // txttc
            // 
            this.txttc.Location = new System.Drawing.Point(144, 135);
            this.txttc.Name = "txttc";
            this.txttc.Size = new System.Drawing.Size(203, 20);
            this.txttc.TabIndex = 9;
            // 
            // txtsoyad
            // 
            this.txtsoyad.Location = new System.Drawing.Point(144, 94);
            this.txtsoyad.Name = "txtsoyad";
            this.txtsoyad.Size = new System.Drawing.Size(203, 20);
            this.txtsoyad.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(22, 141);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 16);
            this.label11.TabIndex = 8;
            this.label11.Text = "TC No";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(22, 183);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Doğum Tarihi";
            // 
            // txtad
            // 
            this.txtad.Location = new System.Drawing.Point(144, 53);
            this.txtad.Name = "txtad";
            this.txtad.Size = new System.Drawing.Size(203, 20);
            this.txtad.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 54);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(22, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Adı";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(38, 60);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(70, 16);
            this.label27.TabIndex = 27;
            this.label27.Text = "Anne Adı";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(38, 198);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(96, 16);
            this.label17.TabIndex = 29;
            this.label17.Text = "Baba Tel No";
            // 
            // txtbabatelno
            // 
            this.txtbabatelno.Location = new System.Drawing.Point(155, 198);
            this.txtbabatelno.Name = "txtbabatelno";
            this.txtbabatelno.Size = new System.Drawing.Size(203, 20);
            this.txtbabatelno.TabIndex = 33;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(38, 151);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(94, 16);
            this.label20.TabIndex = 31;
            this.label20.Text = "Anne Tel No";
            // 
            // txtaannetelno
            // 
            this.txtaannetelno.Location = new System.Drawing.Point(155, 150);
            this.txtaannetelno.Name = "txtaannetelno";
            this.txtaannetelno.Size = new System.Drawing.Size(203, 20);
            this.txtaannetelno.TabIndex = 35;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(38, 107);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(72, 16);
            this.label23.TabIndex = 32;
            this.label23.Text = "Baba Adı";
            // 
            // txtbabaadi
            // 
            this.txtbabaadi.Location = new System.Drawing.Point(155, 105);
            this.txtbabaadi.Name = "txtbabaadi";
            this.txtbabaadi.Size = new System.Drawing.Size(203, 20);
            this.txtbabaadi.TabIndex = 36;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.label7);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(784, 82);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(8, 8);
            this.flowLayoutPanel1.TabIndex = 49;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(3, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 360);
            this.label7.TabIndex = 27;
            this.label7.Text = "KİŞİSEL BİLGİLER";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.txtbabameslek);
            this.panel2.Controls.Add(this.txtannemesle);
            this.panel2.Controls.Add(this.txtanneadi);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.flowLayoutPanel1);
            this.panel2.Controls.Add(this.txtaileadres);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.txtbabaadi);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.txtaannetelno);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.txtbabatelno);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Location = new System.Drawing.Point(858, 153);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(412, 420);
            this.panel2.TabIndex = 32;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(38, 374);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(99, 16);
            this.label26.TabIndex = 55;
            this.label26.Text = "Baba Meslek";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(37, 333);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(97, 16);
            this.label25.TabIndex = 54;
            this.label25.Text = "Anne Meslek";
            // 
            // txtbabameslek
            // 
            this.txtbabameslek.Location = new System.Drawing.Point(155, 374);
            this.txtbabameslek.Name = "txtbabameslek";
            this.txtbabameslek.Size = new System.Drawing.Size(203, 20);
            this.txtbabameslek.TabIndex = 53;
            // 
            // txtannemesle
            // 
            this.txtannemesle.Location = new System.Drawing.Point(155, 333);
            this.txtannemesle.Name = "txtannemesle";
            this.txtannemesle.Size = new System.Drawing.Size(203, 20);
            this.txtannemesle.TabIndex = 52;
            // 
            // txtanneadi
            // 
            this.txtanneadi.Location = new System.Drawing.Point(155, 57);
            this.txtanneadi.Name = "txtanneadi";
            this.txtanneadi.Size = new System.Drawing.Size(203, 20);
            this.txtanneadi.TabIndex = 51;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(36, 15);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(153, 24);
            this.label16.TabIndex = 50;
            this.label16.Text = "AİLE BİLGİLERİ";
            // 
            // txtaileadres
            // 
            this.txtaileadres.Location = new System.Drawing.Point(155, 246);
            this.txtaileadres.Name = "txtaileadres";
            this.txtaileadres.Size = new System.Drawing.Size(203, 56);
            this.txtaileadres.TabIndex = 44;
            this.txtaileadres.Text = "";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(38, 245);
            this.label18.Name = "label18";
            this.label18.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label18.Size = new System.Drawing.Size(49, 16);
            this.label18.TabIndex = 43;
            this.label18.Text = "Adres";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.txtiban);
            this.panel3.Controls.Add(this.label28);
            this.panel3.Controls.Add(this.txtdepozito);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.bitistarih);
            this.panel3.Controls.Add(this.baslangictarih);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.txtaylikucet);
            this.panel3.Controls.Add(this.label24);
            this.panel3.Controls.Add(this.label29);
            this.panel3.Location = new System.Drawing.Point(39, 486);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(803, 207);
            this.panel3.TabIndex = 33;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(21, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(178, 24);
            this.label19.TabIndex = 56;
            this.label19.Text = "SENET BİLGİLERİ";
            // 
            // txtiban
            // 
            this.txtiban.Location = new System.Drawing.Point(144, 161);
            this.txtiban.Name = "txtiban";
            this.txtiban.Size = new System.Drawing.Size(203, 20);
            this.txtiban.TabIndex = 55;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(20, 161);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(108, 16);
            this.label28.TabIndex = 54;
            this.label28.Text = "Iban Numarası";
            // 
            // txtdepozito
            // 
            this.txtdepozito.Location = new System.Drawing.Point(533, 109);
            this.txtdepozito.Name = "txtdepozito";
            this.txtdepozito.Size = new System.Drawing.Size(203, 20);
            this.txtdepozito.TabIndex = 53;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(414, 109);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(115, 16);
            this.label21.TabIndex = 52;
            this.label21.Text = "Depozito Ücreti";
            // 
            // bitistarih
            // 
            this.bitistarih.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.bitistarih.Location = new System.Drawing.Point(144, 116);
            this.bitistarih.Name = "bitistarih";
            this.bitistarih.Size = new System.Drawing.Size(203, 20);
            this.bitistarih.TabIndex = 51;
            // 
            // baslangictarih
            // 
            this.baslangictarih.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.baslangictarih.Location = new System.Drawing.Point(144, 71);
            this.baslangictarih.Name = "baslangictarih";
            this.baslangictarih.Size = new System.Drawing.Size(203, 20);
            this.baslangictarih.TabIndex = 50;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(22, 116);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(82, 16);
            this.label22.TabIndex = 32;
            this.label22.Text = "Bitiş Tarihi";
            // 
            // txtaylikucet
            // 
            this.txtaylikucet.Location = new System.Drawing.Point(533, 71);
            this.txtaylikucet.Name = "txtaylikucet";
            this.txtaylikucet.Size = new System.Drawing.Size(203, 20);
            this.txtaylikucet.TabIndex = 35;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(414, 71);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(83, 16);
            this.label24.TabIndex = 31;
            this.label24.Text = "Aylık Ücret";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(22, 71);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(121, 16);
            this.label29.TabIndex = 27;
            this.label29.Text = "Başlangıç Tarihi";
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnsave.ForeColor = System.Drawing.Color.White;
            this.btnsave.Location = new System.Drawing.Point(1049, 618);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(221, 110);
            this.btnsave.TabIndex = 35;
            this.btnsave.Text = "KAYDET";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel21.Controls.Add(this.label1);
            this.panel21.Location = new System.Drawing.Point(39, 112);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(485, 37);
            this.panel21.TabIndex = 37;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(530, 112);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(125, 37);
            this.button2.TabIndex = 38;
            this.button2.Text = "Oda Seç";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(191)))), ((int)(((byte)(228)))));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton5,
            this.toolStripSplitButton1,
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripButton3,
            this.toolStripButton4});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1370, 25);
            this.toolStrip1.TabIndex = 39;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.ForeColor = System.Drawing.Color.White;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(79, 22);
            this.toolStripButton5.Text = "Ana Sayfa";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yazOkuluKaydıToolStripMenuItem,
            this.normalKayıtToolStripMenuItem});
            this.toolStripSplitButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(90, 22);
            this.toolStripSplitButton1.Text = "Yeni Kayıt";
            // 
            // yazOkuluKaydıToolStripMenuItem
            // 
            this.yazOkuluKaydıToolStripMenuItem.Name = "yazOkuluKaydıToolStripMenuItem";
            this.yazOkuluKaydıToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.yazOkuluKaydıToolStripMenuItem.Text = "Yaz Okulu Kaydı";
            this.yazOkuluKaydıToolStripMenuItem.Click += new System.EventHandler(this.yazOkuluKaydıToolStripMenuItem_Click);
            // 
            // normalKayıtToolStripMenuItem
            // 
            this.normalKayıtToolStripMenuItem.Name = "normalKayıtToolStripMenuItem";
            this.normalKayıtToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.normalKayıtToolStripMenuItem.Text = "Normal Kayıt";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.ForeColor = System.Drawing.Color.White;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(85, 22);
            this.toolStripButton2.Text = "Kayıt Silme";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.ForeColor = System.Drawing.Color.White;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(78, 22);
            this.toolStripButton1.Text = "Çalışanlar";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.ForeColor = System.Drawing.Color.White;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(84, 22);
            this.toolStripButton3.Text = "Gelir-Gider";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.ForeColor = System.Drawing.Color.White;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(120, 22);
            this.toolStripButton4.Text = "Çamaşır Makinesi";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // secilenyatak
            // 
            this.secilenyatak.AutoSize = true;
            this.secilenyatak.Location = new System.Drawing.Point(686, 121);
            this.secilenyatak.Name = "secilenyatak";
            this.secilenyatak.Size = new System.Drawing.Size(0, 13);
            this.secilenyatak.TabIndex = 40;
            // 
            // YeniKayıt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.secilenyatak);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.panel21);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label40);
            this.Name = "YeniKayıt";
            this.Text = "YeniKayıt";
            this.Load += new System.EventHandler(this.YeniKayıt_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtad;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txttelno;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RichTextBox txtadres;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox sinif;
        private System.Windows.Forms.TextBox txtbolum;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtbabatelno;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtaannetelno;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtbabaadi;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RichTextBox txtaileadres;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DateTimePicker bitistarih;
        private System.Windows.Forms.DateTimePicker baslangictarih;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtaylikucet;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.RichTextBox txtozeldurum;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dogumtarihi;
        private System.Windows.Forms.TextBox txtiban;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtdepozito;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.TextBox txttc;
        private System.Windows.Forms.TextBox txtsoyad;
        private System.Windows.Forms.TextBox txtokul;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtanneadi;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem yazOkuluKaydıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalKayıtToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtbabameslek;
        private System.Windows.Forms.TextBox txtannemesle;
        private System.Windows.Forms.TextBox txtdogumyeri;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label secilenyatak;
    }
}