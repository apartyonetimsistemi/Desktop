﻿using ApartYönetimSistemi.data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApartYönetimSistemi
{
    public partial class odemeyenler : Form
    {
        public odemeyenler()
        {
            InitializeComponent();
        }
        string ay, yıl;
        private void odemeyenler_Load(object sender, EventArgs e)
        {
            this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
            this.WindowState = FormWindowState.Maximized;
            this.Bounds = Screen.PrimaryScreen.Bounds;
            ay = DateTime.Now.Month.ToString();
            string gün = DateTime.Now.Day.ToString();
            yıl= DateTime.Now.Year.ToString();
            label1.Text = gün + " / " + ay + " / " + yıl;
            DisplayData();
        }
        public void DisplayData()
        {
            try
            {
                SqlConnection cnn = database.getConnection();
                cnn.Open();
                SqlDataAdapter adpt = new SqlDataAdapter("select * from odemeyenbul where Ay='"+ay+"' AND YilID='"+Int32.Parse(yıl)+"' AND OdemeTarih IS NULL", cnn);
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                dataGridView1.DataSource = dt;
                cnn.Close();
            }
            catch { MessageBox.Show("Hata display data"); }
        }
    }
}
